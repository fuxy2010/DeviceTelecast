// DlgTab.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgTab.h"


// CDlgTab �Ի���

IMPLEMENT_DYNAMIC(CDlgTab, CDialog)

CDlgTab::CDlgTab(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTab::IDD, pParent)
{
	m_mapView.clear();
}

CDlgTab::~CDlgTab()
{
}

void CDlgTab::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB_FUN, m_tabCtrl);
}


BEGIN_MESSAGE_MAP(CDlgTab, CDialog)
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB_FUN, &CDlgTab::OnTcnSelchangeTabFun)
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CDlgTab ��Ϣ��������

void CDlgTab::OnTcnSelchangeTabFun(NMHDR *pNMHDR, LRESULT *pResult)
{
	*pResult = 0;
	OnTabSelChanged();
}

BOOL CDlgTab::OnInitDialog()
{
	CDialog::OnInitDialog();

	//Test();

	return TRUE;
}

void CDlgTab::Test()
{
	for(int i=0;i<5;i++)
		AppendItem(_T("��"));
}

void CDlgTab::AppendItem(CString strItemName)
{
	m_tabCtrl.InsertItem(m_tabCtrl.GetItemCount(),strItemName);
}

void CDlgTab::AppendItem(CString strItemName,IAbstractUI* pView)
{
	if(!pView)
	{
		return;
	}
	m_mapView.insert(std::make_pair(m_tabCtrl.GetItemCount(),pView));
	m_tabCtrl.InsertItem(m_tabCtrl.GetItemCount(),strItemName);
}

void CDlgTab::AppendItem(IAbstractUI* pView)
{
	if(!pView)
	{
		return;
	}
	AppendItem(_CS(pView->GetTestUIName()),pView);
}

void CDlgTab::SetCurSel(int nIndex)
{
	m_tabCtrl.SetCurSel(nIndex);
	OnTabSelChanged();
}

void CDlgTab::OnTabSelChanged()
{
	int nIndex = m_tabCtrl.GetCurSel();

	std::map<int,IAbstractUI*>::iterator it;
	for(it=m_mapView.begin();it!=m_mapView.end();it++)
	{
		if(nIndex == it->first)
		{
			it->second->ShowUI(TRUE);
		}else
		{
			it->second->ShowUI(FALSE);
		}
	}
}

void CDlgTab::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(m_tabCtrl.GetSafeHwnd())
	{
		CRect rt;
		GetClientRect(&rt);
		m_tabCtrl.SetWindowPos(NULL,0,0,rt.Width(),rt.Width(),SWP_NOZORDER);
	}
}
