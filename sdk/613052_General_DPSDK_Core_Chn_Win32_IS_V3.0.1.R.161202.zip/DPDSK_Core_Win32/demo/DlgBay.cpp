// DlgBay.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgBay.h"
#include "DPSDK_Core_Error.h"
#include "DPSDK_Core.h"

// CDlgBay �Ի���

IMPLEMENT_DYNAMIC(CDlgBay, CDialog)

CDlgBay::CDlgBay(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgBay::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_BAY)
{
	memset(m_szRecordId, 0, sizeof(m_szRecordId));
}

CDlgBay::~CDlgBay()
{
}

void CDlgBay::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgBay, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_PIC_WRITE, &CDlgBay::OnBnClickedButtonPicWrite)
	ON_BN_CLICKED(IDC_BUTTON_PIC_READ, &CDlgBay::OnBnClickedButtonPicRead)
	ON_BN_CLICKED(IDC_BUTTON_SUB_FLOW, &CDlgBay::OnBnClickedButtonSubFlow)
	ON_BN_CLICKED(IDC_BUTTON_DEL_SUB_FLOW, &CDlgBay::OnBnClickedButtonDelSubFlow)
	ON_BN_CLICKED(IDC_BUTTON_SUB_FLOW_BAY, &CDlgBay::OnBnClickedButtonSubFlowBay)
	ON_BN_CLICKED(IDC_BUTTON_DEL_SUB_FLOW_BAY, &CDlgBay::OnBnClickedButtonDelSubFlowBay)
	ON_BN_CLICKED(IDC_BUTTON_SUB_SPEED, &CDlgBay::OnBnClickedButtonSubSpeed)
	ON_BN_CLICKED(IDC_BUTTON_DEL_SUB_SPEED, &CDlgBay::OnBnClickedButtonDelSubSpeed)
	ON_BN_CLICKED(IDC_BUTTON_SUB_SPEED2, &CDlgBay::OnBnClickedButtonSubSpeed2)
	ON_BN_CLICKED(IDC_BUTTON_DEL_SUB_FLOW_BAY2, &CDlgBay::OnBnClickedButtonDelSubFlowBay2)
	ON_BN_CLICKED(IDC_BT_ADD_AREAINFO, &CDlgBay::OnBnClickedBtAddAreainfo)
	ON_BN_CLICKED(IDC_BUTTON_SWITCH_DECETION, &CDlgBay::OnBnClickedButtonSwitchDecetion)
END_MESSAGE_MAP()


// CDlgBay ��Ϣ��������

void CDlgBay::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgBay::OnBnClickedButtonPicWrite()
{
	Traffic_Violation_Info_t stuWriteTrafficViolationInfo;
	stuWriteTrafficViolationInfo.nCarColor = 255;
	stuWriteTrafficViolationInfo.nCardirect = 1;
	stuWriteTrafficViolationInfo.nCarLen = 198;
	stuWriteTrafficViolationInfo.nCarLogo = 10;
	stuWriteTrafficViolationInfo.nCarNumColor = 125;
	stuWriteTrafficViolationInfo.nCarNumType = 20;
	stuWriteTrafficViolationInfo.nWay = 10;
	stuWriteTrafficViolationInfo.nCarSpeed = 100;
	stuWriteTrafficViolationInfo.nCarType = 21;
	stuWriteTrafficViolationInfo.nChannel = 1;
	stuWriteTrafficViolationInfo.nDataSource = 19;
	stuWriteTrafficViolationInfo.nMaxSpeed = 120;
	stuWriteTrafficViolationInfo.nMinSpeed = 80;
	stuWriteTrafficViolationInfo.nPicNum = 6;
	stuWriteTrafficViolationInfo.ntype = DPSDK_CORE_ALARM_DRIVEROUT_DRIVERALLOW;
	for (int i = 0; i < 4; i++)
	{
		stuWriteTrafficViolationInfo.nRtPlate[i] = i+2;
	}

	strcpy_s(stuWriteTrafficViolationInfo.szCapturedate, sizeof(stuWriteTrafficViolationInfo.szCapturedate), "2013-09-29 12:04:08");
	strcpy_s(stuWriteTrafficViolationInfo.szCarNum, sizeof(stuWriteTrafficViolationInfo.szCarNum), "kfsdk");
	strcpy_s(stuWriteTrafficViolationInfo.szChannelId, sizeof(stuWriteTrafficViolationInfo.szChannelId), "1000001$1$0$1");
	strcpy_s(stuWriteTrafficViolationInfo.szDeviceId, sizeof(stuWriteTrafficViolationInfo.szDeviceId), "1000001");
	strcpy_s(stuWriteTrafficViolationInfo.szDeviceName, sizeof(stuWriteTrafficViolationInfo.szDeviceName), "kfsdk");
	strcpy_s(stuWriteTrafficViolationInfo.szDeviceChnName, sizeof(stuWriteTrafficViolationInfo.szDeviceChnName), "asldjflsdjfklj");
	strcpy_s(stuWriteTrafficViolationInfo.szOptNote, sizeof(stuWriteTrafficViolationInfo.szOptNote), "asldjfjfklj");

	for (int i = 0; i < 6; i++)
	{
		strcpy_s(stuWriteTrafficViolationInfo.szPicName[i], sizeof(stuWriteTrafficViolationInfo.szPicName[i]), "lsjdfjk");
	}


	/*Traffic_Violation_Info_t* pInfo = new Traffic_Violation_Info_t;
	memset(pInfo, 0, sizeof(Traffic_Violation_Info_t));
	strncpy(pInfo->szRecordId,"1001328", 128);
	strncpy(pInfo->szDeviceId,"1001328", 64);
	strncpy(pInfo->szChannelId, "1001328", 64);
	strncpy(pInfo->szDeviceName, "001", 256);
	strncpy(pInfo->szDeviceChnName, "0001", 256);
	strncpy(pInfo->szCarNum, "110", 32);
	strncpy(pInfo->szCapturedate, "2013-09-25 12:04:08", 128);
	strncpy(pInfo->szOptNote, "alsdkfls", 255);

	char szPicName[DPSDK_CORE_BAY_IMG_NUM][DPSDK_CORE_FILEPATH_LEN] = {"D://1.jpg","D://2.jpg","D://3.jpg","D://4.jpg","D://5.jpg","D://6.jpg"};
	for (int i = 0; i < 6; i++)
	{
		strncpy(pInfo->szPicName[i], szPicName[i], 256);
	}

	pInfo->nCarColor =  1;
	pInfo->nCardirect =  1;
	pInfo->nCarLen =  123;
	pInfo->nCarLogo =  3231;
	pInfo->nCarNumColor =  3213;
	pInfo->nCarNumType =  3213;
	pInfo->nCarSpeed =  312;
	pInfo->nCarType =  3213;
	pInfo->nChannel =  1323;
	pInfo->nDataSource =  32132;
	pInfo->nMaxSpeed =  3213;
	pInfo->nMinSpeed =  3213;
	pInfo->nPicNum =  6;
	pInfo->ntype =  4213;
	pInfo->nWay =  3213;

	int32_t 	nRtPlate[4] = {3213,54643,324,345435};
	for (int i = 0; i < 4; i++)
	{
		pInfo->nRtPlate[i] = nRtPlate[i];
	}*/

	int iRet = DPSDK_WriteTrafficViolationInfo(m_nDLLHandle, &stuWriteTrafficViolationInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Violation alarm info write in")));

	if (iRet == 0)
	{
		strcpy_s(m_szRecordId, sizeof(m_szRecordId), stuWriteTrafficViolationInfo.szRecordId);
	}

// 	delete pInfo;
// 	pInfo = NULL;
}

void CDlgBay::OnBnClickedButtonPicRead()
{
	Traffic_Violation_Info_t* pInfo = new Traffic_Violation_Info_t;

	strcpy_s(pInfo->szRecordId, DPSDK_CORE_TIME_LEN, m_szRecordId);

	int iRet = DPSDK_GetTrafficViolationInfo(m_nDLLHandle,pInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Violation alarm info get")));

	delete pInfo;
	pInfo = NULL;
}

void CDlgBay::OnBnClickedButtonSubFlow()
{
	Subscribe_Traffic_Flow_Info_t* pGetInfo = new Subscribe_Traffic_Flow_Info_t;
	pGetInfo->nChnlCount =3;
	pGetInfo->nInterval = 60;
	pGetInfo->pEncChannelnfo = new Enc_Channel_Info_t[3];
	(pGetInfo->pEncChannelnfo[0]).nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szId, DPSDK_CORE_ORG_GPS_LEN, "1000000$1$0$0");
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[1].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[1].szId, DPSDK_CORE_ORG_GPS_LEN, "1000001$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[1].szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[2].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[2].szId, DPSDK_CORE_ORG_GPS_LEN, "1000012$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[2].szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");
	pGetInfo->nSubscribeFlag = 1;
	
	int iRet = DPSDK_SubscribeTrafficFlow(m_nDLLHandle,pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Flow order")));

	if (pGetInfo->pEncChannelnfo)
	{
		delete [] pGetInfo->pEncChannelnfo;
		pGetInfo->pEncChannelnfo = NULL;
	}
	
	delete pGetInfo;
	pGetInfo = NULL;
}

void CDlgBay::OnBnClickedButtonDelSubFlow()
{
	Subscribe_Traffic_Flow_Info_t* pGetInfo = new Subscribe_Traffic_Flow_Info_t;
	pGetInfo->nChnlCount = 1;
	pGetInfo->nInterval = 60;
	pGetInfo->pEncChannelnfo = new Enc_Channel_Info_t;
	pGetInfo->pEncChannelnfo->nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo->szId, DPSDK_CORE_ORG_GPS_LEN, "1000000$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo->szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");
	pGetInfo->nSubscribeFlag = 0;

	int iRet = DPSDK_SubscribeTrafficFlow(m_nDLLHandle,pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Cancel flow order")));

	delete pGetInfo->pEncChannelnfo;
	pGetInfo->pEncChannelnfo = NULL;
	delete pGetInfo;
	pGetInfo = NULL;
}

void CDlgBay::OnBnClickedButtonSubFlowBay()
{
	Subscribe_Bay_Car_Info_t* pGetInfo = new Subscribe_Bay_Car_Info_t;
	pGetInfo->nChnlCount =3;
	pGetInfo->pEncChannelnfo = new Enc_Channel_Info_t[3];
	(pGetInfo->pEncChannelnfo[0]).nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szId, DPSDK_CORE_ORG_GPS_LEN, "1000000$1$0$0");
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[1].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[1].szId, DPSDK_CORE_ORG_GPS_LEN, "1000001$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[1].szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[2].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[2].szId, DPSDK_CORE_ORG_GPS_LEN, "100012$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[2].szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");
	pGetInfo->nSubscribeFlag = 1;

	int iRet = DPSDK_SubscribeBayCarInfo(m_nDLLHandle,pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Specify channel lane flow, info output to BayCarInfo.txt")));

	if (pGetInfo->pEncChannelnfo)
	{
		delete [] pGetInfo->pEncChannelnfo;
		pGetInfo->pEncChannelnfo = NULL;
	}

	delete pGetInfo;
	pGetInfo = NULL;
}

void CDlgBay::OnBnClickedButtonDelSubFlowBay()
{
	Subscribe_Bay_Car_Info_t* pGetInfo = new Subscribe_Bay_Car_Info_t;
	pGetInfo->nChnlCount =3;
	pGetInfo->pEncChannelnfo = new Enc_Channel_Info_t[3];
	(pGetInfo->pEncChannelnfo[0]).nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szId, DPSDK_CORE_ORG_GPS_LEN, "1000000$1$0$0");
	strcpy_s((pGetInfo->pEncChannelnfo[0]).szName, DPSDK_CORE_ORG_NAME_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[1].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[1].szId, DPSDK_CORE_ORG_GPS_LEN, "1000001$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[1].szName, DPSDK_CORE_ORG_NAME_LEN, "tesssssssss");

	pGetInfo->pEncChannelnfo[2].nCameraType =  (dpsdk_camera_type_e)0;
	strcpy_s(pGetInfo->pEncChannelnfo[2].szId, DPSDK_CORE_ORG_GPS_LEN, "1000012$1$0$0");
	strcpy_s(pGetInfo->pEncChannelnfo[2].szName, DPSDK_CORE_ORG_GPS_LEN, "tesssssssss");
	pGetInfo->nSubscribeFlag = 0;

	int iRet = DPSDK_SubscribeBayCarInfo(m_nDLLHandle,pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Cancel specify channel lane flow order")));

	if (pGetInfo->pEncChannelnfo)
	{
		delete [] pGetInfo->pEncChannelnfo;
		pGetInfo->pEncChannelnfo = NULL;
	}

	delete pGetInfo;
	pGetInfo = NULL;
	
}

void CDlgBay::OnBnClickedButtonSubSpeed()
{
	int iRet = DPSDK_SubscribeAreaSpeedDetectInfo(m_nDLLHandle,1);
	::ShowCallRetInfo(this,iRet,_CS(_T("Interval speed order")));


}

void CDlgBay::OnBnClickedButtonDelSubSpeed()
{
	int iRet = DPSDK_SubscribeAreaSpeedDetectInfo(m_nDLLHandle,0);
	::ShowCallRetInfo(this,iRet,_CS(_T("Cancel zone speed order")));

}

void CDlgBay::OnBnClickedButtonSubSpeed2()
{
	Subscribe_Bay_Car_Info_t* pGetInfo = new Subscribe_Bay_Car_Info_t;
	pGetInfo->nChnlCount =0;
	pGetInfo->nSubscribeFlag = 1;

	int iRet = DPSDK_SubscribeBayCarInfo(m_nDLLHandle, pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("All channel lane flows, info output to BayCarInfo.txt")));

	delete pGetInfo;
	pGetInfo = NULL;
}

void CDlgBay::OnBnClickedButtonDelSubFlowBay2()
{
	Subscribe_Bay_Car_Info_t* pGetInfo = new Subscribe_Bay_Car_Info_t;
	pGetInfo->nChnlCount =0;
	pGetInfo->nSubscribeFlag = 0;

	int iRet = DPSDK_SubscribeBayCarInfo(m_nDLLHandle, pGetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("Cancel all channel lane flow order")));

	delete pGetInfo;
	pGetInfo = NULL;
}

BOOL CDlgBay::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_FALG));

	((CComboBox*)GetDlgItem(IDC_COMBO_FALG))->SetCurSel(0);
	GetDlgItem(IDC_EDIT_STOP_SECTION)->SetWindowText(_T("19"));
	GetDlgItem(IDC_EDIT_STOP_WAY)->SetWindowText(_T("01"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}



void CDlgBay::OnBnClickedBtAddAreainfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Area_Info_t areaInfo;

	areaInfo.nAreaType = AREATYPE_SPEEDLIMIT;
	strncpy_s(areaInfo.strAreaAttr, "strAreaAttr", DPSDK_CORE_AREA_ATTR_MAXLEN);
	strncpy_s(areaInfo.strAreaName, "strAreaName", DPSDK_CORE_AREA_NAME_MAXLEN);
	areaInfo.nSpeedLimit = 80;
	areaInfo.nNumMax = 10;

	int nAreaPoints = 2;
	Area_Point_t *pAreaPoint = new Area_Point_t[nAreaPoints];

	for (int i = 0; i < nAreaPoints; ++i)
	{
		Area_Point_t &ap = pAreaPoint[i];

		ap.dwLongitude = 10;
		ap.dwLatidude = 10;
	}

	areaInfo.arryAreaPoints = pAreaPoint;
	areaInfo.nAreaPointsCount = nAreaPoints;

	areaInfo.stuAlarmTime.enable = true;

	for (int i = 0; i < DPSDK_CORE_AREA_WEEK_DAYS; ++i)
	{
		Area_Time_Weekdays_t &weekdays = areaInfo.stuAlarmTime.areatimeWeekdays[i];
		weekdays.days = i;
		Area_Time_Period_t *pTime = new Area_Time_Period_t[1];
		strncpy_s(pTime->szBeginTime, "00:00:00", 32);
		strncpy_s(pTime->szEndTime, "23:59:59", 32);
		weekdays.arryAlarmtimePeriod = pTime;
		weekdays.nAlarmtimePeriodCount = 1;
	}

	char (*devidArray)[DPSDK_CORE_DEV_ID_LEN] = NULL;
	int nDevSize = 2;

	devidArray = new char [nDevSize][DPSDK_CORE_DEV_ID_LEN];
	for (int i = 0; i < nDevSize; ++i)
	{
		strncpy_s(devidArray[i], DPSDK_CORE_DEV_ID_LEN, "10000", DPSDK_CORE_DEV_ID_LEN);
	}

	char szAreaID[64] = {0};

	//int nRet = DPSDK_AddAreaInfo(m_iDpsdkHandle, &areaInfo, devidArray, nDevSize, szAreaID,64);


	//char pDevid[1][64]={0} ;
	//char pAreaid[128]={0};
	//int iRet = DPSDK_AddAreaInfo(m_nDLLHandle,&areaInfo,devidArray,nDevSize,szAreaID,64);

	int iRet = DPSDK_QueryDevAreaRelationLen(m_nDLLHandle,15000);
	int iRet3 = DPSDK_DelAreaInDev(m_nDLLHandle,"1001109", "6");
	int iRet4 = DPSDK_UploadRelationChange(m_nDLLHandle);
	printf("");

	delete[] pAreaPoint;
	delete[] devidArray;


}

void CDlgBay::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgBay::GetWidget() const
{
	return const_cast<CDlgBay*>(this);
}

CString CDlgBay::GetTestUIName() const
{
	return _T("ANPR");
}

void CDlgBay::OnBnClickedButtonSwitchDecetion()
{
	int nRet = -1;

	CString strStopSection;
	GetDlgItem(IDC_EDIT_STOP_SECTION)->GetWindowText(strStopSection);
	CWideToUtf8 szStopSection(strStopSection.GetString());

	CString strStopWay;
	GetDlgItem(IDC_EDIT_STOP_WAY)->GetWindowText(strStopWay);
	CWideToUtf8 szStopWay(strStopWay.GetString());
	
	char szCameraID[DPSDK_CORE_CHL_ID_LEN] = {0};
	nRet = DPSDK_GetCameraIDbyStopSectionandWay(m_nDLLHandle, szStopSection.c_str(), szStopWay.c_str(), szCameraID, 10000);
	if (nRet == 0)
	{
		bool bFlag = false;
		CString falg;
		GetDlgItem(IDC_COMBO_FALG)->GetWindowText(falg);
		int iflag = _ttoi(falg.GetString());
		bFlag = (iflag == 1)?true:false;
		nRet = DPSDK_OpenIntrusionDetection(m_nDLLHandle, szCameraID, bFlag, 20000);

		::ShowCallRetInfo(this, nRet, _CS(_T("Control Camera Intrusion Detection")));
	}else
	{
		::ShowCallRetInfo(this, nRet,_CS(_T("Get CameraID by StopSection and StopWay")));
	}
}
