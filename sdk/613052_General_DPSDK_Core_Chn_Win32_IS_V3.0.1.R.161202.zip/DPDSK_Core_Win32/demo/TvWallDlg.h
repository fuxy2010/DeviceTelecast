#pragma once
#include "DPSDK_Core.h"
#include "afxcmn.h"
#include "afxwin.h"
#include "resource.h"
#include "interface/IAbstractUI.h"

// CTvWallDlg �Ի���
typedef std::vector<int> VecOpenWndNo;
typedef std::map<int, VecOpenWndNo> MapScreenOpenWndInfo;
typedef std::map<int, MapScreenOpenWndInfo> MapTvWallOpenWndInfo;

typedef struct tagDecoderInfo_t
{
	CString strDecodeId;
	std::vector<int> vecScreenId;
	tagDecoderInfo_t()
	{
		strDecodeId = _T("");
		vecScreenId.clear();
	}

}DecoderInfo_t;

class CTvWallDlg : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CTvWallDlg)

public:
	CTvWallDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CTvWallDlg();

// �Ի�������
	enum { IDD = IDD_DLG_TVWALL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()


public:
	void SetHandle(int nDLLHandle);

protected:
	int32_t m_nDLLHandle;
	int		m_nTvWallCount;
	uint32_t	m_nScreenCount;
	std::map<int, TvWall_Info_t> m_mapTvwallInfo;
	//TvWall_Screen_Info_t* m_pScreenInfo;
public:
	virtual BOOL OnInitDialog();
	afx_msg void OndBtnGettvwallCount();
	afx_msg void OnBnClickedBtnGettvwallInfo();
	afx_msg void OnBnClickedBtnQueryLayout();
	afx_msg void OnBnClickedBtnGetLayout2();
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnBnClickedButton1();
	CListCtrl m_lstLayout;
	afx_msg void OnBtnSetSource();
	afx_msg void OnBtnCloseSource();
	afx_msg void OnOpenWindow();
	afx_msg void OnBnCloseWindow();
	afx_msg void OnBnMoveWindow();
    afx_msg void OnBnClickedButtonSetTopWindow();
	afx_msg void OnBnClickedButtonSetPip();
private:
	/*float m_fTop1;
	float m_fTop2;
	float m_fTop3;
	float m_fTop4;
	float m_fBottom1;
	float m_fBottom2;
	float m_fBottom3;
	float m_fBottom4;
	float m_fLeft1;
	float m_fLeft2;
	float m_fLeft3;
	float m_fLeft4;
	float m_fRight1;
	float m_fRight2;
	float m_fRight3;
	float m_fRight4;
	int m_nBigChan1;
	int m_nBigChan2;
	int m_nBigChan3;
	int m_nBigChan4;
	int m_nSmallChan1;
	int m_nSmallChan2;
	int m_nSmallChan3;
	int m_nSmallChan4;
	CComboBox m_cbxPip1;
	CComboBox m_cbxPip2;
	CComboBox m_cbxPip3;
	CComboBox m_cbxPip4;*/
public:
	afx_msg void OnBnClickedButtonTopWindow();
private:
	float m_fLeft;
	float m_fTop;
	float m_fWidth;
	float m_fHeight;
	//std::vector<int> m_vecWinNum;
	MapTvWallOpenWndInfo  m_mapTvWallOpenWndInfo;

public:
	//����Ϊ-1����ʾ�������
	void ClearOpenWndInfo(int nTvWallId = -1, int nScreenId = -1, int nWndNo = -1);

	void ClearOpenWndInfo(MapScreenOpenWndInfo* pMapScreen, int nScreenId = -1, int nWndNo = -1);

	void ClearOpenWndInfo(VecOpenWndNo* pVecOpenWndNo, int nWndNo = -1);

	void AddOpenWndInfo(int nTvWallId, int nScreenId, int nWndNo);

	void UpdateOpenWndNoList(int nTvWallId, int nScreenId);

private:
	void GetTvWallDecodeIdList(uint32_t nTvWallId, std::map<CString, DecoderInfo_t>& vecDecodeId);

public:
	afx_msg void OnBnClickedButtonClearTvwallScreen();
	afx_msg void OnStnClickedStaticRet();
	afx_msg void OnStnClickedStaticState();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnNMClickList1(NMHDR *pNMHDR, LRESULT *pResult);
};
