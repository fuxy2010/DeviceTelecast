// DlgPrison.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgPrison.h"
#include "WideMultiChange.h"
#include "DPSDK_Core_Error.h"

// CDlgPrison �Ի���

IMPLEMENT_DYNAMIC(CDlgPrison, CDialog)

CDlgPrison::CDlgPrison(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrison::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_PRISON)
{

}

CDlgPrison::~CDlgPrison()
{
}

void CDlgPrison::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgPrison, CDialog)
	ON_BN_CLICKED(IDC_BTN_GET_DISK_INFO, &CDlgPrison::OnBnClickedBtnGetDiskInfo)
	ON_BN_CLICKED(IDC_BTN_SET_HEADER, &CDlgPrison::OnBnClickedBtnSetHeader)
	ON_BN_CLICKED(IDC_BTN_CONTROL_BURNER, &CDlgPrison::OnBnClickedBtnControlBurner)
END_MESSAGE_MAP()


// CDlgPrison ��Ϣ��������
BOOL CDlgPrison::OnInitDialog()
{
	__super::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgPrison::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgPrison::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgPrison::GetWidget() const
{
	return const_cast<CDlgPrison*>(this);
}

CString CDlgPrison::GetTestUIName() const
{
	return _T("PRISON");
}

void CDlgPrison::OnBnClickedBtnGetDiskInfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strDevID;
	GetDlgItemText(IDC_EDIT_DEV_ID, strDevID);
	CWideToMulti szDevID(strDevID.GetString());
	int nSeq = 0, nInfoCount = 0;
	int nRet = DPSDK_GetDeviceDiskInfoCount(m_nDLLHandle, szDevID.c_str(), nInfoCount, nSeq);
	if(nRet == DPSDK_RET_SUCCESS && nInfoCount)
	{
		Device_Disk_Info_t* pDeviceDiskInfo = new Device_Disk_Info_t;
		pDeviceDiskInfo->pDiskInfoList = new Single_Disk_Info_t[nInfoCount];
		DPSDK_GetDeviceDiskInfo(m_nDLLHandle, nSeq, pDeviceDiskInfo);
		return;
	}
}
void CDlgPrison::OnBnClickedBtnSetHeader()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DevBurnerInfoHeader_t stuHeader;
	memset(&stuHeader, 0, sizeof(DevBurnerInfoHeader_t));
	TrialFormAttrName_t stuAttrName;
	memset(&stuAttrName, 0, sizeof(TrialFormAttrName_t));

	CString strDevID;
	GetDlgItemText(IDC_EDIT_DEV_ID, strDevID);
	CWideToMulti szDevID(strDevID.GetString());
	strcpy(stuHeader.m_deviceId, szDevID.c_str());
	strcpy(stuHeader.m_caseId, "qxnT3");
	strcpy(stuHeader.m_caseReferPerson, "���Կ�ʼ�참1");
	strcpy(stuHeader.m_caseUnderTaker, "qxn1");
	strcpy(stuHeader.m_caseDep, "�������� 172.6.10.202��Ѷ����");
	stuHeader.m_dataCheckOsdEn = true;
	stuHeader.m_AttachFileEn = true;
	stuHeader.m_multiBurnerDataCheck = true;

	strcpy(stuAttrName.m_caseIdAttr, "qxnT3");
	strcpy(stuAttrName.m_caseReferPersonAttr, "���Կ�ʼ�참1");
	strcpy(stuAttrName.m_caseUnderTakerAttr, "qxn1");
	strcpy(stuAttrName.m_caseDepAttr, "�������� 172.6.10.202��Ѷ����");

	int nRet = DPSDK_SetDevBurnerHeader(m_nDLLHandle, &stuHeader, &stuAttrName);
	return;
}

void CDlgPrison::OnBnClickedBtnControlBurner()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Control_Dev_Burner_Request_t req;
	CString strDevID;
	GetDlgItemText(IDC_EDIT_DEV_ID, strDevID);
	CWideToMulti szDevID(strDevID.GetString());
	strcpy(req.deviceId, szDevID.c_str());
	req.cmd = Cmd_StartBurn;
	req.channelMask = 1;
	req.burnerMask = 1;
	req.emMode = 0;
	req.emPack = 0;
	int nRet = DPSDK_ControlDevBurner(m_nDLLHandle, &req);
	if(nRet == DPSDK_RET_SUCCESS)
	{
		//Sleep(5000);
		req.cmd = Cmd_StopBurn;
		nRet = DPSDK_ControlDevBurner(m_nDLLHandle, &req);
		if(nRet == DPSDK_RET_SUCCESS)
		{
			MessageBox(L"success");
		}
		return;
	}
}
