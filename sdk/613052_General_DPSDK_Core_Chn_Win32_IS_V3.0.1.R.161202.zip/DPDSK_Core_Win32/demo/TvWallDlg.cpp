// TvWallDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "TvWallDlg.h"
#include "DPSDK_Core_Error.h"


// CTvWallDlg �Ի���

IMPLEMENT_DYNAMIC(CTvWallDlg, CDialog)

CTvWallDlg::CTvWallDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTvWallDlg::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_TVWALL)
	, m_nDLLHandle(NULL)
	, m_nTvWallCount(0)
	, m_fLeft(0)
	, m_fTop(0)
	, m_fWidth(0)
	, m_fHeight(0)
{
	//m_pScreenInfo = NULL;
}

CTvWallDlg::~CTvWallDlg()
{
	// 	if (m_pScreenInfo != NULL)
	// 	{
	// 		delete m_pScreenInfo;
	// 		m_pScreenInfo = NULL;
	// 	}
	ClearOpenWndInfo();
}

void CTvWallDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_lstLayout);
	/*DDX_Control(pDX, IDC_COMBO_PIP1, m_cbxPip1);
	DDX_Control(pDX, IDC_COMBO_PIP2, m_cbxPip2);
	DDX_Control(pDX, IDC_COMBO_PIP3, m_cbxPip3);
	DDX_Control(pDX, IDC_COMBO_PIP4, m_cbxPip4);
	DDX_Text(pDX,IDC_EDIT_TOP1,m_fTop1);
	DDX_Text(pDX,IDC_EDIT_TOP2,m_fTop2);
	DDX_Text(pDX,IDC_EDIT_TOP3,m_fTop3);
	DDX_Text(pDX,IDC_EDIT_TOP4,m_fTop4);
	DDX_Text(pDX,IDC_EDIT_BOTTOM1,m_fBottom1);
	DDX_Text(pDX,IDC_EDIT_BOTTOM2,m_fBottom2);
	DDX_Text(pDX,IDC_EDIT_BOTTOM3,m_fBottom3);
	DDX_Text(pDX,IDC_EDIT_BOTTOM4,m_fBottom4);
	DDX_Text(pDX,IDC_EDIT_LEFT1,m_fLeft1);
	DDX_Text(pDX,IDC_EDIT_LEFT2,m_fLeft2);
	DDX_Text(pDX,IDC_EDIT_LEFT3,m_fLeft3);
	DDX_Text(pDX,IDC_EDIT_LEFT4,m_fLeft4);
	DDX_Text(pDX,IDC_EDIT_RIGHT1,m_fRight1);
	DDX_Text(pDX,IDC_EDIT_RIGHT2,m_fRight2);
	DDX_Text(pDX,IDC_EDIT_RIGHT3,m_fRight3);
	DDX_Text(pDX,IDC_EDIT_RIGHT4,m_fRight4);
	DDX_Text(pDX,IDC_EDIT_BIG_CHAN1,m_nBigChan1);
	DDX_Text(pDX,IDC_EDIT_BIG_CHAN2,m_nBigChan2);
	DDX_Text(pDX,IDC_EDIT_BIG_CHAN3,m_nBigChan3);
	DDX_Text(pDX,IDC_EDIT_BIG_CHAN4,m_nBigChan4);
	DDX_Text(pDX,IDC_EDIT_SMALL_CHAN1,m_nSmallChan1);
	DDX_Text(pDX,IDC_EDIT_SMALL_CHAN2,m_nSmallChan2);
	DDX_Text(pDX,IDC_EDIT_SMALL_CHAN3,m_nSmallChan3);
	DDX_Text(pDX,IDC_EDIT_SMALL_CHAN4,m_nSmallChan4);*/
	DDX_Text(pDX,IDC_EDIT_LEFT,m_fLeft);
	DDX_Text(pDX,IDC_EDIT_UP,m_fTop);
	DDX_Text(pDX,IDC_EDIT_WIDTH,m_fWidth);
	DDX_Text(pDX,IDC_EDIT_HEIGHT,m_fHeight);
}


BEGIN_MESSAGE_MAP(CTvWallDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_GETTVWALL, &CTvWallDlg::OndBtnGettvwallCount)
	ON_BN_CLICKED(IDC_BTN_GETTVWALL_INFO, &CTvWallDlg::OnBnClickedBtnGettvwallInfo)
	ON_BN_CLICKED(IDC_BTN_QUERY_LAYOUT, &CTvWallDlg::OnBnClickedBtnQueryLayout)
	//ON_BN_CLICKED(IDC_BTN_GET_LAYOUT2, &CTvWallDlg::OnBnClickedBtnGetLayout2)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CTvWallDlg::OnCbnSelchangeCombo1)
	ON_BN_CLICKED(IDC_BUTTON1, &CTvWallDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CTvWallDlg::OnBtnSetSource)
	ON_BN_CLICKED(IDC_BUTTON9, &CTvWallDlg::OnBtnCloseSource)
	ON_BN_CLICKED(IDC_BUTTON3, &CTvWallDlg::OnOpenWindow)
	ON_BN_CLICKED(IDC_BUTTON4, &CTvWallDlg::OnBnCloseWindow)
	ON_BN_CLICKED(IDC_BUTTON5, &CTvWallDlg::OnBnMoveWindow)
	ON_BN_CLICKED(IDC_BUTTON_SET_PIP, &CTvWallDlg::OnBnClickedButtonSetPip)
	ON_BN_CLICKED(IDC_BUTTON_SET_TOP_WINDOW, &CTvWallDlg::OnBnClickedButtonSetTopWindow)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_TVWALL_SCREEN, &CTvWallDlg::OnBnClickedButtonClearTvwallScreen)
	//ON_STN_CLICKED(IDC_STATIC_RET, &CTvWallDlg::OnStnClickedStaticRet)
	ON_STN_CLICKED(IDC_STATIC_STATE, &CTvWallDlg::OnStnClickedStaticState)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, &CTvWallDlg::OnNMClickList1)
END_MESSAGE_MAP()


// CTvWallDlg ��Ϣ��������
void CTvWallDlg::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

BOOL CTvWallDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_lstLayout.SetExtendedStyle(m_lstLayout.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_lstLayout.InsertColumn(1, _CS(_T("No.")), LVCFMT_CENTER, 40);
	m_lstLayout.InsertColumn(2, _CS(_T("Screen ID")), LVCFMT_CENTER, 50);
	m_lstLayout.InsertColumn(3, _CS(_T("Name")), LVCFMT_CENTER, 70);
	m_lstLayout.InsertColumn(4, _CS(_T("Left")), LVCFMT_CENTER, 70);
	m_lstLayout.InsertColumn(5, _CS(_T("Top")), LVCFMT_CENTER, 70);
	m_lstLayout.InsertColumn(6, _CS(_T("Width")), LVCFMT_CENTER, 70);
	m_lstLayout.InsertColumn(7, _CS(_T("Height")), LVCFMT_CENTER, 70);
	m_lstLayout.InsertColumn(8, _CS(_T("Bind decoder or not")), LVCFMT_CENTER, 100);
	m_lstLayout.InsertColumn(9, _CS(_T("bCombine")), LVCFMT_CENTER, 70);
	((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(0);

	/*m_fTop1 = 0;
	m_fBottom1 = 0.4;
	m_fLeft1 = 0;
	m_fRight1 = 0.4;
	m_nBigChan1 = 3;
	m_nSmallChan1 = 0;
	m_cbxPip1.AddString(_CS(_T("Yes")));
	m_cbxPip1.AddString(_CS(_T("No")));
	m_cbxPip1.SelectString(0,_CS(_T("Yes")));

	m_fTop2 = 0.3;
	m_fBottom2 = 0.65;
	m_fLeft2 = 0.3;
	m_fRight2 = 0.65;
	m_nBigChan2 = 16;
	m_nSmallChan2 = 18;
	m_cbxPip2.AddString(_CS(_T("Yes")));
	m_cbxPip2.AddString(_CS(_T("No")));
	m_cbxPip2.SelectString(0,_CS(_T("No")));

	m_fTop3 = 0.30;
	m_fBottom3 = 0.65;
	m_fLeft3 = 0.3;
	m_fRight3 = 0.65;
	m_nBigChan3 = 20;
	m_nSmallChan3 = 21;
	m_cbxPip3.AddString(_CS(_T("Yes")));
	m_cbxPip3.AddString(_CS(_T("No")));
	m_cbxPip3.SelectString(0,_CS(_T("Yes")));

	m_fTop4 = 0.3;
	m_fBottom4 = 0.65;
	m_fLeft4 = 0.3;
	m_fRight4 = 0.65;
	m_nBigChan4 = 24;
	m_nSmallChan4 = 26;
	m_cbxPip4.AddString(_CS(_T("Yes")));
	m_cbxPip4.AddString(_CS(_T("No")));
	m_cbxPip4.SelectString(0,_CS(_T("Yes")));*/

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CTvWallDlg::OndBtnGettvwallCount()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	uint32_t nCount = 0;
	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryTvWallList(m_nDLLHandle, nCount), _CS(_T("Get tv wall total")));
	m_nTvWallCount = nCount;
}

void CTvWallDlg::OnBnClickedBtnGettvwallInfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCount()-1; i >= 0; i--)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO1))->DeleteString( i );
	}

	TvWall_List_Info_t tvwallInfo = {0};
	tvwallInfo.nCount = m_nTvWallCount;
	tvwallInfo.pTvWallInfo = new TvWall_Info_t[m_nTvWallCount];
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetTvWallList(m_nDLLHandle, &tvwallInfo), _CS(_T("Get tv wall info")));

	if (nRet == 0)
	{
		m_mapTvwallInfo.clear();
		for (int i = 0; i < m_nTvWallCount; i++)
		{
			int nId = tvwallInfo.pTvWallInfo[i].nTvWallId;
			CString strId;
			strId.Format(_T("%d"), nId);
			((CComboBox*)GetDlgItem(IDC_COMBO1))->InsertString(i, strId);
			((CComboBox*)GetDlgItem(IDC_COMBO1))->SetItemData(i, (DWORD)&tvwallInfo.pTvWallInfo[i]);

			m_mapTvwallInfo[nId] = tvwallInfo.pTvWallInfo[i];
		}
	}
	if(m_nTvWallCount > 0)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(0);
		if (dataInfo != NULL)
		{
			CString test;
			CMultiToWide strName(dataInfo->szName);
			test.Format(_CS(_T("name:%s,status:%d")), strName.wc_str(), dataInfo->nState);
			GetDlgItem(IDC_STATIC_STATE)->SetWindowText(test);
		}	
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}

void CTvWallDlg::OnBnClickedBtnQueryLayout()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		m_nScreenCount = 0;
		int nRet = ::ShowCallRetInfo(this, DPSDK_GetTvWallLayoutCount(m_nDLLHandle, dataInfo->nTvWallId, &m_nScreenCount), _CS(_T("Get tv wall layout")));

		if(m_nScreenCount>0)
		{
			TvWall_Layout_Info_t stuLayout;
			stuLayout.nTvWallId = dataInfo->nTvWallId;
			stuLayout.nCount = m_nScreenCount;
			stuLayout.pScreenInfo = new TvWall_Screen_Info_t[m_nScreenCount];
			for(int i=0;i<m_nScreenCount;i++)
			{
				memset(&stuLayout.pScreenInfo[i],0,sizeof(stuLayout.pScreenInfo[i]));
			}
			nRet = ::ShowCallRetInfo(this, DPSDK_GetTvWallLayout(m_nDLLHandle, &stuLayout), _CS(_T("Get tv wall layput info")));

			// ������Ϣд�뵽list��
			{
				m_lstLayout.DeleteAllItems();
				for (int i = 0; i < m_nScreenCount; i++)
				{
					CString text;
					text.Format(_T("%d"), i+1);
					m_lstLayout.InsertItem(i, text);

					text.Format(_T("%d"), stuLayout.pScreenInfo[i].nScreenId);
					m_lstLayout.SetItemText(i, 1, text);

					CUtf8ToWide temp(stuLayout.pScreenInfo[i].szName);
					text.Format(_T("%s"), temp.wc_str());
					m_lstLayout.SetItemText(i, 2, text);

					text.Format(_T("%f"), stuLayout.pScreenInfo[i].fLeft);
					m_lstLayout.SetItemText(i, 3, text);

					text.Format(_T("%f"), stuLayout.pScreenInfo[i].fTop);
					m_lstLayout.SetItemText(i, 4, text);

					text.Format(_T("%f"), stuLayout.pScreenInfo[i].fWidth);
					m_lstLayout.SetItemText(i, 5, text);

					text.Format(_T("%f"), stuLayout.pScreenInfo[i].fHeight);
					m_lstLayout.SetItemText(i, 6, text);

					CUtf8ToWide temp1(stuLayout.pScreenInfo[i].szDecoderId);
					text.Format(_T("%d_%s"), stuLayout.pScreenInfo[i].bBind ? 1:0,temp1.wc_str());
					m_lstLayout.SetItemText(i, 7, text);

					text.Format(_T("%d"), stuLayout.pScreenInfo[i].bCombine?1:0);
					m_lstLayout.SetItemText(i, 8, text);
				}
			}

			delete []stuLayout.pScreenInfo;
		}
	}
	else
	{
	    MessageBox(_CS(_T("No TV wall info!")));
	}


}

//void CTvWallDlg::OnBnClickedBtnGetLayout2()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
//	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
//	if (nsel >= 0)
//	{
//		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);
//
//		if(dataInfo == NULL)
//		{
//			return;
//		}
//		
//	}
//	else
//	{
//		MessageBox(_CS(_T("No TV wall info!")));
//	}
//	
//	
//}

void CTvWallDlg::OnCbnSelchangeCombo1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);
		if (dataInfo != NULL)
		{
			CString test;
			CMultiToWide strName(dataInfo->szName);
			test.Format(_CS(_T("name:%s,status:%d")), strName.wc_str(), dataInfo->nState);
			GetDlgItem(IDC_STATIC_STATE)->SetWindowText(test);

			UpdateOpenWndNoList(-1, -1);
		}
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}

}

void CTvWallDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		CString strText;
		GetDlgItem(IDC_COMBO_SPLIT)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please input split num")));
		}
		int nSplit = _ttoi(strText.GetString());


		TvWall_Screen_Split_t stuSplit;
		stuSplit.nTvWallId = dataInfo->nTvWallId;
		stuSplit.enSplitNum = (tvwall_screen_split_caps)nSplit;
		stuSplit.nScreenId = atoi(szId.c_str());
		int nRet = ::ShowCallRetInfo(this, DPSDK_SetTvWallScreenSplit(m_nDLLHandle, &stuSplit), _CS(_T("���ָ�")));
		if(nRet == DPSDK_RET_SUCCESS)
		{
			//�ָ�ںŴ�0��ʼ,�����ԭ�еĴ���
			ClearOpenWndInfo(stuSplit.nTvWallId, stuSplit.nScreenId);
			for(int i = 0;i<stuSplit.enSplitNum; i++)
			{
				AddOpenWndInfo(stuSplit.nTvWallId, stuSplit.nScreenId, i);
			}
			UpdateOpenWndNoList(stuSplit.nTvWallId, stuSplit.nScreenId);
		}
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}


void CTvWallDlg::OnBtnSetSource()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		CString strText;
		/*GetDlgItem(IDC_COMBO_SPLIT)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please input split num")));
		}
		int nSplit = _ttoi(strText.GetString());*/

		/*GetDlgItem(IDC_EDIT3)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please input window id")));
		}
		int nWindowId = _ttoi(strText.GetString());*/
		GetDlgItem(IDC_COMBO2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please select window id")));
			return;
		}
		int nWindowId = _ttoi(strText.GetString());

		/*if (nWindowId >= nSplit)
		{
			::PrintfText(_CS(_T("Set video source failed!")));
			MessageBox(_CS(_T("window id does not exist")));
			return;
		}*/

		GetDlgItem(IDC_EDIT2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please input camera id")));
			return;
		}
		CWideToUtf8 cameraId(strText.GetString());

		Set_TvWall_Screen_Window_Source_t stuSourceinfo;
		stuSourceinfo.nTvWallId = dataInfo->nTvWallId;
		stuSourceinfo.nScreenId = atoi(szId.c_str());
		stuSourceinfo.nWindowId = nWindowId;
		strcpy_s(stuSourceinfo.szCameraId, sizeof(stuSourceinfo.szCameraId), cameraId.c_str());
		stuSourceinfo.enStreamType = DPSDK_CORE_STREAMTYPE_MAIN;
		stuSourceinfo.nStayTime = 30;

		int nRet = ::ShowCallRetInfo(this, DPSDK_SetTvWallScreenWindowSource(m_nDLLHandle, &stuSourceinfo), _CS(_T("Set video source")));
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}

}

void CTvWallDlg::OnBtnCloseSource()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	if(nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		/*CString strText;
		GetDlgItem(IDC_EDIT3)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please input window id")));
		}
		int nWindowId = _ttoi(strText.GetString());*/
		CString strText;
		GetDlgItem(IDC_COMBO2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please select window id")));
			return;
		}
		int nWindowId = _ttoi(strText.GetString());

		TvWall_Screen_Close_Source_t stuCloseInfo;
		stuCloseInfo.nTvWallId = dataInfo->nTvWallId;
		stuCloseInfo.nScreenId = atoi(szId.c_str());
		stuCloseInfo.nWindowId = nWindowId;

		int nRet = ::ShowCallRetInfo(this, DPSDK_CloseTvWallScreenWindowSource(m_nDLLHandle, &stuCloseInfo), _CS(_T("Close video source")));
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}

}

void CTvWallDlg::OnOpenWindow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);

	/*for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCount()-1; i >= 0; i--)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO2))->DeleteString( i );
	}*/

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);


		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		//CString strText;
		//GetDlgItem(IDC_EDIT3)->GetWindowText(strText);
		//if (strText.GetLength() <= 0)
		//{
		//	//MessageBox(_CS(_T("please input window id")));
		//}
		//int nWindowId = _ttoi(strText.GetString());

		TvWall_Screen_Open_Window_t stuOpenInfo;
		stuOpenInfo.nTvWallId = dataInfo->nTvWallId;
		stuOpenInfo.nScreenId = atoi(szId.c_str());
		stuOpenInfo.nWindowId = nItem;//nWindowId;
		stuOpenInfo.fLeft = m_fLeft;
		stuOpenInfo.fTop = m_fTop;
		stuOpenInfo.fHeight = m_fHeight;
		stuOpenInfo.fWidth = m_fWidth;

		int nRet = ::ShowCallRetInfo(this, DPSDK_TvWallScreenOpenWindow(m_nDLLHandle, &stuOpenInfo), _CS(_T("Open window")));

		if (nRet == 0)
		{
			//m_vecWinNum.push_back(stuOpenInfo.nWindowId);
			AddOpenWndInfo(stuOpenInfo.nTvWallId, stuOpenInfo.nScreenId, stuOpenInfo.nWindowId);
		}
		UpdateOpenWndNoList(stuOpenInfo.nTvWallId, stuOpenInfo.nScreenId);
		/*int i= 0;
		std::vector<int>::iterator iter = m_vecWinNum.begin();
		while (iter!= m_vecWinNum.end())
		{
			int nId = (*iter);
			CString strId;
			strId.Format(_T("%d"), nId);
			((CComboBox*)GetDlgItem(IDC_COMBO2))->InsertString(i, strId);
			iter++;
			i++;
		}*/

	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}

void CTvWallDlg::OnBnCloseWindow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		CString strText;
		GetDlgItem(IDC_COMBO2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please select window id")));
			return;
		}
		int nWindowId = _ttoi(strText.GetString());


		TvWall_Screen_Close_Window_t stuCloseInfo;
		stuCloseInfo.nScreenId = atoi(szId.c_str());
		stuCloseInfo.nTvWallId = dataInfo->nTvWallId;
		stuCloseInfo.nWindowId = nWindowId;

		int nRet = ::ShowCallRetInfo(this, DPSDK_TvWallScreenColseWindow(m_nDLLHandle, &stuCloseInfo), _CS(_T("Close window")));

		if (nRet == 0)
		{
			ClearOpenWndInfo(stuCloseInfo.nTvWallId, stuCloseInfo.nScreenId, stuCloseInfo.nWindowId);
			/*std::vector<int>::iterator iter = m_vecWinNum.begin();
			while(iter != m_vecWinNum.end())
			{
				if ((*iter) == nWindowId)
				{
					m_vecWinNum.erase(iter);
					break;
				}
				iter ++;
			}		*/

			/*for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCount()-1; i >= 0; i--)
			{
				((CComboBox*)GetDlgItem(IDC_COMBO2))->DeleteString( i );
			}*/

			/*int i= 0;
			std::vector<int>::iterator iter1 = m_vecWinNum.begin();
			while (iter1 != m_vecWinNum.end())
			{
				int nId = (*iter1);
				CString strId;
				strId.Format(_T("%d"), nId);
				((CComboBox*)GetDlgItem(IDC_COMBO2))->InsertString(i, strId);
				iter1++;
				i++;
			}*/
			UpdateOpenWndNoList(stuCloseInfo.nTvWallId, stuCloseInfo.nScreenId);
			Invalidate(FALSE);
		}

	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}

void CTvWallDlg::OnBnMoveWindow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		CString strLeft;
		CString strUp;

		CString strText;
		GetDlgItem(IDC_COMBO2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please select window id")));
			return;
		}
		int nWindowId = _ttoi(strText.GetString());

		TvWall_Screen_Move_Window_t stuMoveInfo;
		stuMoveInfo.nTvWallId = dataInfo->nTvWallId;
		stuMoveInfo.fHeight = m_fHeight;
		stuMoveInfo.fWidth = m_fWidth;
		stuMoveInfo.fLeft = m_fLeft;
		stuMoveInfo.fTop = m_fTop;
		stuMoveInfo.nScreenId  = atoi(szId.c_str());
		stuMoveInfo.nWindowId = nWindowId;

		int nRet = ::ShowCallRetInfo(this, DPSDK_TvWallScreenMoveWindow(m_nDLLHandle, &stuMoveInfo), _CS(_T("Move window")));
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}	
}

void CTvWallDlg::OnBnClickedButtonSetTopWindow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������  

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();  

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		CString strText;
		GetDlgItem(IDC_COMBO2)->GetWindowText(strText);
		if (strText.GetLength() <= 0)
		{
			MessageBox(_CS(_T("please select window id")));
			return;
		}
		int nWindowId = _ttoi(strText.GetString());


		TvWall_Screen_Set_Top_Window_t stuTopWindowInfo;
		stuTopWindowInfo.nScreenId = atoi(szId.c_str());
		stuTopWindowInfo.nTvWallId = dataInfo->nTvWallId;
		stuTopWindowInfo.nWindowId = nWindowId;

		int nRet = ::ShowCallRetInfo(this, DPSDK_TvWallScreenSetTopWindow(m_nDLLHandle, &stuTopWindowInfo), _CS(_T("Window top")));
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}

void CTvWallDlg::OnBnClickedButtonSetPip()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	/*UpdateData(TRUE);

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		int nScreenId = atoi(szId.c_str());

		Pip_TvWall_Screen_Info_t pipTvWallScreenInfo;
		pipTvWallScreenInfo.nTvWallId = dataInfo->nTvWallId;

		int nCurSel = m_cbxPip1.GetCurSel();
		CString strPIP;
		m_cbxPip1.GetLBText(nCurSel,strPIP);
		if(_CS(_T("Yes")) == strPIP)
		{
			pipTvWallScreenInfo.picInPicInfo[0].enPIP = DPSDK_CORE_TVWALL_PIP;
		}
		else
		{
			pipTvWallScreenInfo.picInPicInfo[0].enPIP = DPSDK_CORE_TVWALL_GENERAL;
		}
		pipTvWallScreenInfo.picInPicInfo[0].fBottomPercent = m_fBottom1;
		pipTvWallScreenInfo.picInPicInfo[0].fLeftPercent = m_fLeft1;
		pipTvWallScreenInfo.picInPicInfo[0].fRightPercent = m_fRight1;
		pipTvWallScreenInfo.picInPicInfo[0].fTopPercent = m_fTop1;
		pipTvWallScreenInfo.picInPicInfo[0].nBigChnNum = m_nBigChan1;
		pipTvWallScreenInfo.picInPicInfo[0].nScreenID = 0;
		pipTvWallScreenInfo.picInPicInfo[0].nSmallChnNum = m_nSmallChan1;

		strPIP.Empty();
		nCurSel = m_cbxPip2.GetCurSel();
		m_cbxPip2.GetLBText(nCurSel,strPIP);
		if(_CS(_T("Yes")) == strPIP)
		{
			pipTvWallScreenInfo.picInPicInfo[1].enPIP = DPSDK_CORE_TVWALL_PIP;
		}
		else
		{
			pipTvWallScreenInfo.picInPicInfo[1].enPIP = DPSDK_CORE_TVWALL_GENERAL;
		}
		pipTvWallScreenInfo.picInPicInfo[1].fBottomPercent = m_fBottom2;
		pipTvWallScreenInfo.picInPicInfo[1].fLeftPercent = m_fLeft2;
		pipTvWallScreenInfo.picInPicInfo[1].fRightPercent = m_fRight2;
		pipTvWallScreenInfo.picInPicInfo[1].fTopPercent = m_fTop2;
		pipTvWallScreenInfo.picInPicInfo[1].nBigChnNum = m_nBigChan2;
		pipTvWallScreenInfo.picInPicInfo[1].nScreenID = 1;
		pipTvWallScreenInfo.picInPicInfo[1].nSmallChnNum = m_nSmallChan2;

		strPIP.Empty();
		nCurSel = m_cbxPip3.GetCurSel();
		m_cbxPip3.GetLBText(nCurSel,strPIP);
		if(_CS(_T("Yes")) == strPIP)
		{
			pipTvWallScreenInfo.picInPicInfo[2].enPIP = DPSDK_CORE_TVWALL_PIP;
		}
		else
		{
			pipTvWallScreenInfo.picInPicInfo[2].enPIP = DPSDK_CORE_TVWALL_GENERAL;
		}
		pipTvWallScreenInfo.picInPicInfo[2].fBottomPercent = m_fBottom3;
		pipTvWallScreenInfo.picInPicInfo[2].fLeftPercent = m_fLeft3;
		pipTvWallScreenInfo.picInPicInfo[2].fRightPercent = m_fRight3;
		pipTvWallScreenInfo.picInPicInfo[2].fTopPercent = m_fTop3;
		pipTvWallScreenInfo.picInPicInfo[2].nBigChnNum = m_nBigChan3;
		pipTvWallScreenInfo.picInPicInfo[2].nScreenID = 2;
		pipTvWallScreenInfo.picInPicInfo[2].nSmallChnNum = m_nSmallChan3;

		strPIP.Empty();
		nCurSel = m_cbxPip4.GetCurSel();
		m_cbxPip4.GetLBText(nCurSel,strPIP);
		if(_CS(_T("Yes")) == strPIP)
		{
			pipTvWallScreenInfo.picInPicInfo[3].enPIP = DPSDK_CORE_TVWALL_PIP;
		}
		else
		{
			pipTvWallScreenInfo.picInPicInfo[3].enPIP = DPSDK_CORE_TVWALL_GENERAL;
		}
		pipTvWallScreenInfo.picInPicInfo[3].fBottomPercent = m_fBottom4;
		pipTvWallScreenInfo.picInPicInfo[3].fLeftPercent = m_fLeft4;
		pipTvWallScreenInfo.picInPicInfo[3].fRightPercent = m_fRight4;
		pipTvWallScreenInfo.picInPicInfo[3].fTopPercent = m_fTop4;
		pipTvWallScreenInfo.picInPicInfo[3].nBigChnNum = m_nBigChan4;
		pipTvWallScreenInfo.picInPicInfo[3].nScreenID = 3;
		pipTvWallScreenInfo.picInPicInfo[3].nSmallChnNum = m_nSmallChan4;

		int nRet = ::ShowCallRetInfo(this, DPSDK_SetPipTvWallScreen(m_nDLLHandle, &pipTvWallScreenInfo, nScreenId, 50000), _CS(_T("PIP on wall")));
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}*/
}

void CTvWallDlg::GetTvWallDecodeIdList(uint32_t nTvWallId, std::map<CString, DecoderInfo_t>& vecDecodeId)
{
	vecDecodeId.clear();
	for(int i=0;i<m_lstLayout.GetItemCount();i++)
	{
		CString strText = m_lstLayout.GetItemText(i,7);
		int nPos = strText.Find('_');
		if(nPos<0)
			continue;
		strText = strText.Right(strText.GetLength() - nPos - 1);
		if(strText.Compare(_T(""))==0)
			continue;

		CString strScreenId = m_lstLayout.GetItemText(i,1);
		CWideToUtf8 szScreenId(strScreenId.GetString());
		int nScreenId = atoi(szScreenId.c_str());

		std::map<CString, DecoderInfo_t>::iterator it = vecDecodeId.find(strText);
		if(it == vecDecodeId.end())
		{
			DecoderInfo_t sDecoderInfo;
			sDecoderInfo.strDecodeId = strText;
			sDecoderInfo.vecScreenId.push_back(nScreenId);
			vecDecodeId.insert(std::make_pair(strText,sDecoderInfo));
		}else
		{
			it->second.vecScreenId.push_back(nScreenId);
		}
	}
}
void CTvWallDlg::OnBnClickedButtonClearTvwallScreen()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();

	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}
		std::map<CString, DecoderInfo_t> vecDecodeId;
		GetTvWallDecodeIdList(dataInfo->nTvWallId, vecDecodeId);
		//int nRet = ::ShowCallRetInfo(this, DPSDK_ClearTvWallScreen(m_nDLLHandle, dataInfo->nTvWallId), _CS(_T("Clear")));

		int nRet = -1;
		for(std::map<CString, DecoderInfo_t>::iterator it = vecDecodeId.begin(); it!= vecDecodeId.end();it++)
		{
			CWideToUtf8 szDecodeId(it->second.strDecodeId.GetString());
			nRet = DPSDK_ClearTvWallScreenByDecodeId(m_nDLLHandle, dataInfo->nTvWallId, szDecodeId.c_str());
			if(nRet == DPSDK_RET_SUCCESS)
			{
				std::vector<int>& vecScreenId = it->second.vecScreenId;
				for(int i = 0; i < vecScreenId.size(); i++)
				{
					ClearOpenWndInfo(dataInfo->nTvWallId, vecScreenId[i]);
					UpdateOpenWndNoList(-1, -1);
				}
			}
		}
		::ShowCallRetInfo(this, nRet, _CS(_T("Clear")));

		if (nRet == 0)
		{
			
			
			/*for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCount()-1; i >= 0; i--)
			{
				((CComboBox*)GetDlgItem(IDC_COMBO2))->DeleteString( i );
			}

			m_vecWinNum.clear();*/

			Invalidate(FALSE);
		}
	}
	else
	{
		MessageBox(_CS(_T("No TV wall info!")));
	}
}

void CTvWallDlg::OnStnClickedStaticRet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CTvWallDlg::OnStnClickedStaticState()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CTvWallDlg::UpdateOpenWndNoList(int nTvWallId, int nScreenId)
{
	//��ɾ������
	for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCount()-1; i >= 0; i--)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO2))->DeleteString( i );
	}
	((CComboBox*)GetDlgItem(IDC_COMBO2))->SetWindowText(_T(""));

	MapTvWallOpenWndInfo::iterator it = m_mapTvWallOpenWndInfo.find(nTvWallId);
	if(it != m_mapTvWallOpenWndInfo.end())
	{
		MapScreenOpenWndInfo& mapSrceen = it->second;

		MapScreenOpenWndInfo::iterator itSrceen = mapSrceen.find(nScreenId);
		if(itSrceen != mapSrceen.end())
		{
			VecOpenWndNo& vecOpenWndNo = itSrceen->second;

			int i= 0;
			VecOpenWndNo::iterator iter = vecOpenWndNo.begin();
			while (iter!= vecOpenWndNo.end())
			{
				int nId = (*iter);
				CString strId;
				strId.Format(_T("%d"), nId);
				((CComboBox*)GetDlgItem(IDC_COMBO2))->InsertString(i, strId);
				iter++;
				i++;
			}
			if(i>0)
			{
				((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(i-1);
			}
		}
	}
}

void CTvWallDlg::AddOpenWndInfo(int nTvWallId, int nScreenId, int nWndNo)
{
	MapTvWallOpenWndInfo::iterator it = m_mapTvWallOpenWndInfo.find(nTvWallId);
	if(it == m_mapTvWallOpenWndInfo.end())
	{
		VecOpenWndNo vecOpen;
		vecOpen.push_back(nWndNo);
		MapScreenOpenWndInfo mapScreen;
		mapScreen.insert(std::make_pair(nScreenId, vecOpen));
		m_mapTvWallOpenWndInfo.insert(std::make_pair(nTvWallId, mapScreen));
	}else
	{
		MapScreenOpenWndInfo& mapSrceen = it->second;

		MapScreenOpenWndInfo::iterator itSrceen = mapSrceen.find(nScreenId);
		if(itSrceen == mapSrceen.end())
		{
			VecOpenWndNo vecOpen;
			vecOpen.push_back(nWndNo);
			mapSrceen.insert(std::make_pair(nScreenId, vecOpen));
		}else
		{
			VecOpenWndNo& vecOpenWndNo = itSrceen->second;
			vecOpenWndNo.push_back(nWndNo);
		}
	}
}

void CTvWallDlg::ClearOpenWndInfo(int nTvWallId /*= -1*/, int nScreenId /*= -1*/, int nWndNo /*= -1*/)
{
	if(nTvWallId == -1)
	{
		for(MapTvWallOpenWndInfo::iterator it = m_mapTvWallOpenWndInfo.begin();it!=m_mapTvWallOpenWndInfo.end();it++)
		{
			MapScreenOpenWndInfo& mapSrceen = it->second;
			ClearOpenWndInfo(&mapSrceen);
		}
		m_mapTvWallOpenWndInfo.clear();
	}else
	{
		MapTvWallOpenWndInfo::iterator it = m_mapTvWallOpenWndInfo.find(nTvWallId);
		if(it != m_mapTvWallOpenWndInfo.end())
		{
			MapScreenOpenWndInfo& mapSrceen = it->second;
			ClearOpenWndInfo(&mapSrceen, nScreenId, nWndNo);
		}
	}
}

void CTvWallDlg::ClearOpenWndInfo(MapScreenOpenWndInfo* pMapScreen, int nScreenId /*= -1*/, int nWndNo /*= -1*/)
{
	if(pMapScreen)
	{
		if(nScreenId < 0)
		{
			for(MapScreenOpenWndInfo::iterator it = pMapScreen->begin();it!=pMapScreen->end();it++)
			{
				VecOpenWndNo& vecOpenWnd = it->second;
				ClearOpenWndInfo(&vecOpenWnd);
			}
			pMapScreen->clear();
		}else
		{
			MapScreenOpenWndInfo::iterator it = pMapScreen->find(nScreenId);
			if(it != pMapScreen->end())
			{
				VecOpenWndNo& vecOpenWndNo = it->second;
				ClearOpenWndInfo(&vecOpenWndNo, nWndNo);
			}
		}
		
	}
}

void CTvWallDlg::ClearOpenWndInfo(VecOpenWndNo* pVecOpenWndNo, int nWndNo /*= -1*/)
{
	if(pVecOpenWndNo)
	{
		if(nWndNo < 0)
			pVecOpenWndNo->clear();
		else
		{
			VecOpenWndNo::iterator it = pVecOpenWndNo->begin();
			while(it != pVecOpenWndNo->end())
			{
				if ((*it) == nWndNo)
				{
					pVecOpenWndNo->erase(it);
					break;
				}
				it++;
			}		
		}
	}
}

void CTvWallDlg::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CTvWallDlg::GetWidget() const
{
	return const_cast<CTvWallDlg*>(this);
}

CString CTvWallDlg::GetTestUIName() const
{
	return _T("TV wall");
}

void CTvWallDlg::OnNMClickList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	int nsel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
	if (nsel >= 0)
	{
		TvWall_Info_t* dataInfo = (TvWall_Info_t*)((CComboBox*)GetDlgItem(IDC_COMBO1))->GetItemData(nsel);

		if(dataInfo == NULL)
		{
			return;
		}

		POSITION pos = m_lstLayout.GetFirstSelectedItemPosition();
		int nItem = 0;
		if (pos)
		{
			nItem = m_lstLayout.GetNextSelectedItem(pos);
		}
		CString screenId = m_lstLayout.GetItemText(nItem, 1);
		CWideToUtf8 szId(screenId.GetString());

		UpdateOpenWndNoList(dataInfo->nTvWallId, atoi(szId.c_str()));
	}
	*pResult = 0;
}
