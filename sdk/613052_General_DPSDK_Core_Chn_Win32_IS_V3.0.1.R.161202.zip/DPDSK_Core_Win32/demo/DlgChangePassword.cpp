// DlgChangePassword.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgChangePassword.h"


// CDlgChangePassword �Ի���

IMPLEMENT_DYNAMIC(CDlgChangePassword, CDialog)

CDlgChangePassword::CDlgChangePassword(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgChangePassword::IDD, pParent)
	, m_nDLLHandle(NULL)
{

}

CDlgChangePassword::~CDlgChangePassword()
{
}

void CDlgChangePassword::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgChangePassword, CDialog)
	ON_BN_CLICKED(IDOK, &CDlgChangePassword::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgChangePassword ��Ϣ��������

void CDlgChangePassword::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

BOOL CDlgChangePassword::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgChangePassword::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData(TRUE);

	CString strOldPassword;
	CString strNewPassword;

	GetDlgItem(IDC_EDIT_OLD_PASSWORD)->GetWindowText(strOldPassword);
	GetDlgItem(IDC_EDIT_NEW_PASSWORD)->GetWindowText(strNewPassword);

	CWideToUtf8 szOldPassword(strOldPassword.GetString());
	CWideToUtf8 szNewPassword(strNewPassword.GetString());

	int nRet = DPSDK_ChangeUserPassword(m_nDLLHandle, szOldPassword.c_str(), szNewPassword.c_str());

	OnOK();
}

