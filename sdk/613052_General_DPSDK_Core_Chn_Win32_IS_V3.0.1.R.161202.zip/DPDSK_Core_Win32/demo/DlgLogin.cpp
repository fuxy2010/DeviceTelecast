// DlgLogin.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgLogin.h"

// CDlgLogin �Ի���

IMPLEMENT_DYNAMIC(CDlgLogin, CDialog)

CDlgLogin::CDlgLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgLogin::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_LOGIN)
{
}

CDlgLogin::~CDlgLogin()
{
}

void CDlgLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgLogin, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_LOGIN, &CDlgLogin::OnBnClickedButtonLogin)
	ON_BN_CLICKED(IDC_BUTTON_LOGOUT, &CDlgLogin::OnBnClickedButtonLogout)
	ON_WM_CLOSE()
END_MESSAGE_MAP()

IWidget* CDlgLogin::GetWidget() const
{
	return const_cast<CDlgLogin*>(this);
}

CString CDlgLogin::GetTestUIName() const
{
	return _T("Login");
}

void CDlgLogin::ShowUI(BOOL bShow)
{

}

// CDlgLogin ��Ϣ��������
BOOL CDlgLogin::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);

	/*GetDlgItem(IDC_EDIT1)->SetWindowText(_T("172.7.50.170"));
	GetDlgItem(IDC_EDIT2)->SetWindowText(_T("9000"));
	GetDlgItem(IDC_EDIT3)->SetWindowText(_T("1"));
	GetDlgItem(IDC_EDIT4)->SetWindowText(_T("1"));*/

	GetDlgItem(IDC_EDIT1)->SetWindowText(_T("172.7.10.10"));
	GetDlgItem(IDC_EDIT2)->SetWindowText(_T("9000"));
	GetDlgItem(IDC_EDIT3)->SetWindowText(_T("DPSDK"));
	GetDlgItem(IDC_EDIT4)->SetWindowText(_T("123456"));

	return TRUE;
}

void CDlgLogin::OnBnClickedButtonLogin()
{
	if(CUtilsMain::GetInstance()->m_LoginUtils.GetLoginStatus() == LOGIN_STATUS_ONLINE)
	{
		ShowWindow(SW_HIDE);
		CTest_DPSDK_CoreDlg::GetInstance()->ShowWindow(SW_SHOW);
		return;
	}
	if(CTest_DPSDK_CoreDlg::GetInstance())
	{
		CString strIp;
		CString strPort;
		CString strUsername;
		CString strPassword;

		GetDlgItem(IDC_EDIT1)->GetWindowText(strIp);
		GetDlgItem(IDC_EDIT2)->GetWindowText(strPort);
		GetDlgItem(IDC_EDIT3)->GetWindowText(strUsername);
		GetDlgItem(IDC_EDIT4)->GetWindowText(strPassword);

		int nRet = CUtilsMain::GetInstance()->m_LoginUtils.Login(strIp, strPort, strUsername, strPassword);

		CString strResult = _CS(_T("Login"));
		::ShowCallRetInfo(CTest_DPSDK_CoreDlg::GetInstance(), nRet , strResult);
		if(nRet == 0)
		{
			ShowWindow(SW_HIDE);
			CTest_DPSDK_CoreDlg::GetInstance()->ShowWindow(SW_SHOW);
			CTest_DPSDK_CoreDlg::GetInstance()->OnLoginSuccess();
		}else
		{
			MessageBox(strResult,_CS(_T("result")));
		}
	}
}

void CDlgLogin::OnBnClickedButtonLogout()
{
	if(CUtilsMain::GetInstance()->m_LoginUtils.GetLoginStatus() == LOGIN_STATUS_OFFLINE)
	{
		PostMessage(WM_CLOSE);
	}else if(CTest_DPSDK_CoreDlg::GetInstance())
	{
		CString strResult = _CS(_T("Logout"));

		int nRet = CUtilsMain::GetInstance()->m_LoginUtils.Logout();
		::ShowCallRetInfo(CTest_DPSDK_CoreDlg::GetInstance(), nRet, strResult);

		if(nRet == 0)
		{
			ShowWindow(SW_HIDE);
			CTest_DPSDK_CoreDlg::GetInstance()->ShowWindow(SW_SHOW);
		}else
		{
			MessageBox(strResult,_CS(_T("result")));
		}
	}
}

void CDlgLogin::OnClose()
{
	if(CTest_DPSDK_CoreDlg::GetInstance())
	{
		CTest_DPSDK_CoreDlg::GetInstance()->PostMessage(WM_CLOSE);
	}
	CDialog::OnClose();
}
