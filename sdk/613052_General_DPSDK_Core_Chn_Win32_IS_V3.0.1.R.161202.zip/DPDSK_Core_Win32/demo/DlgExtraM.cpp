// DlgAlarm.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DlgExtraM.h"
#include "DPSDK_Core_Error.h"
#include "DPSDK_Core.h"
#include "Time.h"
#include "WideMultiChange.h"

// CDlgAlarm �Ի���

IMPLEMENT_DYNAMIC(CDlgExtraM, CDialog)

CDlgExtraM::CDlgExtraM(CWnd* pParent /*=NULL*/)
: CDialog(CDlgExtraM::IDD, pParent)
{

}

CDlgExtraM::~CDlgExtraM()
{
}

int __stdcall DPSDKOsdInfoCallback(int32_t nPDLLHandle,
								   char* pXML,
								   int32_t nLen,
								   void* pUserParam)
{
	CDlgExtraM* pDlg = (CDlgExtraM*)pUserParam;
	MessageBox(NULL, CString(pXML), _T("��Ϣ"), MB_OK);
	return 0;
}

int __stdcall DPSDKHistoryOsdInfoCallback(int32_t nPDLLHandle,
								   char* pXML,
								   int32_t nLen,
								   void* pUserParam)
{
	CDlgExtraM* pDlg = (CDlgExtraM*)pUserParam;
	MessageBox(NULL, CString(pXML), _T("��Ϣ"), MB_OK);
	return 0;
}

void CDlgExtraM::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
	DPSDK_SetDPSDKOSDTempCallback(m_nDLLHandle, (fDPSDKOSDTemplatCallback)DPSDKOsdInfoCallback, this);
	DPSDK_SetDPSDKHistoryOSDCallback(m_nDLLHandle, (fDPSDKHistoryOSDCallback)DPSDKHistoryOsdInfoCallback, this);

}

void CDlgExtraM::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgExtraM, CDialog)
	ON_BN_CLICKED(IDC_BTN_GETOSDTEMP, &CDlgExtraM::OnBnClickedGetOSDTemp)
	//ON_MESSAGE(WM_EXTRAMDATA_CB, OnExtraMCallback)
	ON_BN_CLICKED(IDC_BTN_OpeTemp, &CDlgExtraM::OnBnClickedBtnOpetemp)
	ON_BN_CLICKED(IDC_BTN_SEARCHOSD, &CDlgExtraM::OnBnClickedBtnSearchosd)
	ON_BN_CLICKED(IDC_BTN_SENDOSD, &CDlgExtraM::OnBnClickedBtnSendosd)
	ON_BN_CLICKED(IDC_BTN_SENDSMS, &CDlgExtraM::OnBnClickedBtnSendsms)
END_MESSAGE_MAP()

// CDlgAlarm ��Ϣ��������
BOOL CDlgExtraM::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��	
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgExtraM::OnBnClickedGetOSDTemp()
{
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetOSDTemplatInfo(m_nDLLHandle), _T("��ȡOSDģ��"));
}
void CDlgExtraM::OnBnClickedBtnOpetemp()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//char chMsg[256] = "123456789";
	char chMsg2[256] = "5214";
	char chMsg3[256] = "222";
	CString strMeg = _T("��Ϣ��Ϣ");
	CWideToUtf8 chMsg(strMeg.GetBuffer());
	Ope_OSD_Templat_Info_t Info;
	Info.nMsgType = 1;
	Info.nOpeType = 1;
	Info.nTemplateId = 0;
	memcpy(Info.szMessage, chMsg.c_str(), 256);
	memcpy(Info.szName, chMsg2, 256);
	memcpy(Info.szMemo, chMsg3, 256);
	int nRet = ::ShowCallRetInfo(this, DPSDK_OperateOSDTemplatInfo(m_nDLLHandle, &Info), _T("��ȡOSDģ��"));
}

void CDlgExtraM::OnBnClickedBtnSearchosd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char chMsg[64] = "1000041";
	Search_History_OSDInfo_t Info;
	Info.nMsgType = 1;
	Info.nBeginTime = 1385827200;
	Info.nEndTime = 1388419200;
	memcpy(Info.szDevId, chMsg, 64);
	int nRet = ::ShowCallRetInfo(this, DPSDK_SearchHistoryOSDInfo(m_nDLLHandle, &Info), _T("��ȡ��ʷOSD��Ϣ"));
}

void CDlgExtraM::OnBnClickedBtnSendosd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char chMsg[64] = "1000043";
	char chMsg2[256] = "message";
	Send_OSDInfo_t Info;
	memcpy(Info.szDevId, chMsg, 64 );
	memcpy(Info.szMessage, chMsg2, 256 );
	int nRet = ::ShowCallRetInfo(this, DPSDK_SendOSDInfo(m_nDLLHandle, &Info), _T("����OSD��Ϣ"));
}

void CDlgExtraM::OnBnClickedBtnSendsms()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char chMsg1[64] = "1000041";
	char chMsg2[256] = "devName";
	CString strMeg = _T("��Ϣ��Ϣ");
	CWideToUtf8 chMsg(strMeg.GetBuffer());
	char chMsg4[256] = "13956325147";
	Send_SMS_Info_t Info;
	memcpy(Info.szDevId, chMsg1, 64 );
	memcpy(Info.szDevName, chMsg2, 256 );
	memcpy(Info.szMessage, chMsg.c_str(), 256 );
	memcpy(Info.szSMSNo, chMsg4, 256 );
	Info.nUserId = 2;
	Info.nTime = 1387209600;
	int nRet = ::ShowCallRetInfo(this, DPSDK_SendSMSInfo(m_nDLLHandle, &Info), _T("����SMS��Ϣ"));
}
