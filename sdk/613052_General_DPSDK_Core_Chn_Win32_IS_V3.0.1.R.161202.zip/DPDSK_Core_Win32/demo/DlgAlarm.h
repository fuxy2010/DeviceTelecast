#pragma once
#include "DPSDK_Core.h"
#include "interface/IAbstractUI.h"

// CDlgAlarm �Ի���

struct Single_Alarm_CB_Info_t
{
	char		szAlarmId[128];
	uint32_t	nDeviceType;
	char		szCameraId[64];
	char		szDeviceName[256];
	char		szChannelName[256];
	char		szCoding[64];
	char		szMessage[4096];
	uint32_t	nAlarmType;
	uint32_t	nEventType;
	uint32_t	nLevel;
	int64_t		nTime;
	char*		pszAlarmData;
	uint32_t	nAlarmDataLen;
	char*		pszPicData;
	uint32_t	nPicDataLen;
	void*		pUser;
	char		strDeviceID[DPSDK_CHAR_256];		// �豸ID
	uint32_t	nChannel;							// ͨ����	
};

class CDlgAlarm : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgAlarm)

public:
	CDlgAlarm(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgAlarm();

	void SetHandle(int nDLLHandle);

// �Ի�������
	enum { IDD = IDD_DLG_ALARM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()

	afx_msg void OnBnClickedButtonAlarmQuery();
	afx_msg void OnBnClickedButtonAddSolution();
	afx_msg void OnBnClickedButtonClearSolution();
	afx_msg void OnBnClickedButtonEnableAlarm();
	afx_msg void OnBnClickedButtonDisableAlarm();

	afx_msg LRESULT OnAlarmDataCallback(WPARAM wParam, LPARAM lParam);

	void InsertAlarmItem(Single_Alarm_Info_t* pAlarmInfo, int nCount);
	void InsertAlarmItem(Single_Alarm_CB_Info_t* pAlarmInfo);
	void PushAlarmCBInfo(Single_Alarm_CB_Info_t* pAlarmInfo);
	CString ConvertAlarmType(int nType);
	CString ConvertDealWith(int nType);
	static int DPSDK_CALLTYPE DPSDKAlarmCallback
		(
		int32_t nDLLHandle, 
		const char* szAlarmId, 
		uint32_t nDeviceType, 
		const char* szCameraId,//ͨ��ID
		const char* szDeviceName,
		const char* szChannelName,
		const char* szCoding,
		const char* szMessage,
		uint32_t nAlarmType,
		uint32_t nEventType,
		uint32_t nLevel,
		int64_t nTime,
		char* pAlarmData,
		uint32_t nAlarmDataLen,
		char* pPicData,
		uint32_t nPicDataLen,
		void* pUser
		);
	static int DPSDK_CALLTYPE DPSDKNewAlarmCallback
	(
		int32_t nDLLHandle, 
		const char* szAlarmId, 
		uint32_t nDeviceType, 
		const char* szDevicdId,//�豸ID
		uint32_t nChannelNo,//ͨ����
		const char* szDeviceName,
		const char* szChannelName,
		const char* szCoding,
		const char* szMessage,
		uint32_t nAlarmType,
		uint32_t nEventType,
		uint32_t nLevel,
		int64_t nTime,
		char* pAlarmData,
		uint32_t nAlarmDataLen,
		char* pPicData,
		uint32_t nPicDataLen,
		void* pUser
	);
private:
	int32_t		m_nDLLHandle;
	std::vector<Alarm_Single_Enable_Info_t>	m_vecAlarmScheme;

	std::queue<Single_Alarm_CB_Info_t*> m_queAlarmCBInfo;
	CMutex		m_mtxAlarmCBInfo;

	CListCtrl m_list1;
	CListCtrl m_list2;
public:
	afx_msg void OnBnClickedButtonEnableAlarmByDepartment();
	afx_msg void OnBnClickedButtonSendAlarmToServer();
	afx_msg void OnCbnSelchangeCombo2();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnBnClickedButton1();
};
