// DlgReal.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgReal.h"
#include "DPSDK_Core_Error.h"
#include "DPSDK_Ext.h"
#include "resource.h"
// CDlgReal �Ի���

IMPLEMENT_DYNAMIC(CDlgReal, CDialog)

CDlgReal::CDlgReal(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgReal::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_REAL)
	, m_nDLLHandle(NULL)
	, m_nSeq(-1)
	, m_nBrightness(0)
	, m_nContrast(0)
	, m_nSaturation(0)
	, m_nHue(0)
	, m_nVolReal(0)
{

}

CDlgReal::~CDlgReal()
{
}

void CDlgReal::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgReal::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX,IDC_EDIT_BRIGHTNESS,m_nBrightness);
	DDX_Text(pDX,IDC_EDIT_CONTRAST,m_nContrast);
	DDX_Text(pDX,IDC_EDIT_SATURATION,m_nSaturation);
	DDX_Text(pDX,IDC_EDIT_HUE,m_nHue);
	//DDV_MinMaxInt(pDX, m_nContrast, 0, 128);
	//DDV_MinMaxInt(pDX, m_nBrightness, 0, 128);
	//DDV_MinMaxInt(pDX, m_nSaturation, 0, 128);
	//DDV_MinMaxInt(pDX, m_nHue, 0, 128);
	DDX_Control(pDX, IDC_CHECK_RULE, m_CheckRule);
	DDX_Control(pDX, IDC_CHECK_OBJ, m_checkObj);
	DDX_Control(pDX, IDC_CHECK_LOCUS, m_checkLocus);
}


BEGIN_MESSAGE_MAP(CDlgReal, CDialog)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_OPEN_VIDEO, &CDlgReal::OnBnClickedButtonOpenVideo)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_VIDEO, &CDlgReal::OnBnClickedButtonCloseVideo)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_CAMERA, &CDlgReal::OnBnClickedButtonCloseCamera)
	ON_BN_CLICKED(IDC_BUTTON_CAPTURE_PICTURE, &CDlgReal::OnBnClickedButtonCapturePicture)
	ON_BN_CLICKED(IDC_BTN_GET_CAMID, &CDlgReal::OnBtnGetCamid)
	ON_BN_CLICKED(IDC_BUTTON_START_REAL_RECORD, &CDlgReal::OnBnClickedButtonStartRealRecord)
	ON_BN_CLICKED(IDC_BUTTON_STOP_REAL_RECORD, &CDlgReal::OnBnClickedButtonStopRealRecord)
	ON_BN_CLICKED(IDC_BUTTON_SET_OSD_TXT, &CDlgReal::OnBnClickedButtonSetOsdTxt)
	ON_BN_CLICKED(IDC_BUTTON_CLEAN_UP_OSD_INFO, &CDlgReal::OnBnClickedButtonCleanUpOsdInfo)
	ON_BN_CLICKED(IDC_BUTTON_GET_URL, &CDlgReal::OnBnClickedButtonGetUrl)
	ON_BN_CLICKED(IDC_BUTTON_ADJUST_COLOR, &CDlgReal::OnBnClickedButtonAdjustColor)
	ON_BN_CLICKED(IDC_BUTTON_START_AUDIO, &CDlgReal::OnBnClickedButtonStartAudio)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_AUDIO, &CDlgReal::OnBnClickedButtonCloseAudio)
	ON_BN_CLICKED(IDC_BUTTON_SET_VOLUME, &CDlgReal::OnBnClickedButtonSetVolume)
	ON_BN_CLICKED(IDC_BUTTON_GET_EXTERNAL_URL, &CDlgReal::OnBnClickedButtonGetExternalUrl)
	ON_BN_CLICKED(IDC_BUTTON_GET_VOLUME, &CDlgReal::OnBnClickedButtonGetVolume)
	ON_BN_CLICKED(IDC_BUTTON_GET_COLOR, &CDlgReal::OnBnClickedButtonGetColor)
	ON_BN_CLICKED(IDC_BUTTON_SET_DRAWFUN, &CDlgReal::OnBnClickedButtonSetDrawfun)
	ON_BN_CLICKED(IDC_BUTTON_YUV, &CDlgReal::OnBnClickedButtonYuv)
	ON_BN_CLICKED(IDC_BUTTON_STOP_YUV, &CDlgReal::OnBnClickedButtonStopYuv)
	ON_BN_CLICKED(IDC_BUTTON_YUV_CAPTURE, &CDlgReal::OnBnClickedButtonYuvCapture)
	ON_MESSAGE(WM_MOD_TRANS_MSG, &CDlgReal::OnModTransMsg)
	ON_BN_CLICKED(IDC_CHECK_RULE, &CDlgReal::OnBnClickedCheckRule)
	ON_BN_CLICKED(IDC_CHECK_OBJ, &CDlgReal::OnBnClickedCheckObj)
	ON_BN_CLICKED(IDC_CHECK_LOCUS, &CDlgReal::OnBnClickedCheckLocus)
	ON_BN_CLICKED(IDC_BUTTON_GET_AUDIO_CHANNELS, &CDlgReal::OnBnClickedButtonGetAudioChannels)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_CLOSE_AUDIO_CHANNEL, &CDlgReal::OnBnClickedButtonOpenCloseAudioChannel)
	ON_BN_CLICKED(IDC_BUTTON_GET_CHANNEL_STATE, &CDlgReal::OnBnClickedButtonGetChannelState)
END_MESSAGE_MAP()


// CDlgReal ��Ϣ��������

BOOL CDlgReal::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CAHANNEL_FLAG));
	((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CAHANNEL_FLAG))->SetCurSel(1);

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	::ShowWndPlayer(this, m_dlgWndPlayer);
	//GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1000003$1$0$0"));
	GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1001615$1$0$0"));

	m_nBrightness = 64;
	m_nContrast = 64;
	m_nSaturation = 64;
	m_nHue = 64;

	UpdateData(FALSE);

	m_dlgPtz.Create(IDD_DLG_PTZ, this);
	//m_dlgPtz.SetHandle(m_nDLLHandle);
	//m_dlgTab.AppendItem(&m_dlgPtz);
	m_dlgPtz.SetWindowPos(NULL,460,200,600,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);
	m_dlgPtz.ShowWindow(SW_SHOW);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgReal::OnClose()
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CloseRealStreamBySeq();

	CDialog::OnClose();
}

void CDlgReal:: CloseWin()
{
	OnClose();
}

void CDlgReal::OnBnClickedButtonOpenVideo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CloseRealStreamBySeq();

	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	Get_RealStream_Info_t stuRealStreamInfo = {0};
	strcpy_s(stuRealStreamInfo.szCameraId, sizeof(stuRealStreamInfo.szCameraId), szCameraId.c_str());
	stuRealStreamInfo.nStreamType = DPSDK_CORE_STREAMTYPE_MAIN;
	stuRealStreamInfo.nMediaType = DPSDK_CORE_MEDIATYPE_VIDEO;
	stuRealStreamInfo.nTransType = DPSDK_CORE_TRANSTYPE_TCP;

#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &stuRealStreamInfo), _CS(_T("Open video")));
	if(nRet == DPSDK_RET_SUCCESS)
	{
		int bRuleShow = m_CheckRule.GetCheck();
		::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_RULE_VISIBLE, bRuleShow);

		int bObjShow = m_checkObj.GetCheck();
		::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_OBJ_VISIBLE, bObjShow);

		int bLocusShow = m_checkLocus.GetCheck();
		::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_LOCUS_VISIBLE, bLocusShow);
	}
	//::ShowCallRetInfo(this,DPSDK_RegisterDrawFun(m_nDLLHandle,m_nSeq, fnDrawFun, this),_CS(_T("DrawFun")));

#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetRealStream(m_nDLLHandle, m_nSeq, &stuRealStreamInfo, m_dlgWndPlayer.GetMediaDataCallbackFunc(), &m_dlgWndPlayer), _CS(_T("Open video")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.OpenStream(m_nSeq);
	}
#endif
}

void CDlgReal::OnBnClickedButtonCloseVideo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq), _CS(_T("Close video")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_nSeq = -1;
	}
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_CloseRealStreamBySeq(m_nDLLHandle, m_nSeq), _CS(_T("Close video")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif	
}

void CDlgReal::OnBnClickedButtonCloseCamera()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.CloseRealStreamByCameraId(m_nDLLHandle, szCameraId.c_str()), _CS(_T("Close CAM video")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_nSeq = -1;
	}
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_CloseRealStreamByCameraId(m_nDLLHandle, szCameraId.c_str()), _CS(_T("Close CAM video")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif
}

void CDlgReal::OnBnClickedButtonCapturePicture()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CFileDialog dlg(FALSE, _T(".jpg"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("JPEG Files (*.jpg)|*.jpg|BMP Files (*.bmp)|*.bmp|"));
	if (dlg.DoModal() == IDOK)
	{
		CString strExtName = dlg.GetFileExt();
		dpsdk_pic_type_e nType = strExtName == _T("bmp") ? DPSDK_CORE_PIC_FORMAT_BMP : DPSDK_CORE_PIC_FORMAT_JPEG;

		CString strPathName = dlg.GetPathName();
		CWideToMulti szPathName(strPathName.GetString());

		::ShowCallRetInfo(this, m_dlgWndPlayer.Capture(m_nDLLHandle, m_nSeq, nType, szPathName.c_str()), _CS(_T("Snapshot")));
	}
}

void CDlgReal::CloseRealStreamBySeq(void)
{
#ifdef USING_DPSDK_EXT
	if (m_nSeq >= 0)
	{
		m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq);
		m_nSeq = -1;
	}
#else
	if (m_nSeq >= 0)
	{
		DPSDK_CloseRealStreamBySeq(m_nDLLHandle, m_nSeq);
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif
}

void CDlgReal::OnBtnGetCamid()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strDevIp1(_T(""));
	GetDlgItem(IDC_EDIT_IP)->GetWindowText(strDevIp1);
	if (strDevIp1.GetLength() <= 0)
	{
		MessageBox(_CS(_T("Please input device ip!!")));
		return;
	}
	CWideToUtf8 strDevIp(strDevIp1.GetString());

	CString strPort1(_T(""));
	GetDlgItem(IDC_EDIT_PORT)->GetWindowText(strPort1);
	if (strPort1.GetLength() <= 0)
	{
		MessageBox(_CS(_T("Please input device port!!")));
		return;
	}
	CWideToUtf8 strPort(strPort1.GetString());

	CString strChnlNo1(_T(""));
	GetDlgItem(IDC_EDIT_CHNL)->GetWindowText(strChnlNo1);
	if (strChnlNo1.GetLength() <= 0)
	{
		MessageBox(_CS(_T("Please input channel No.!!")));
		return;
	}
	CWideToUtf8 strChnlNo(strChnlNo1.GetString());

	char szCameraId[128] = {0};
	int nRet = DPSDK_GetCameraIdbyDevInfo(m_nDLLHandle, strDevIp.c_str(), atoi(strPort.c_str()), atoi(strChnlNo.c_str()), szCameraId);
	if (nRet == 0)
	{
		CMultiToWide camId(szCameraId);
		GetDlgItem(IDC_EDIT1)->SetWindowText(camId.wc_str());
		::ShowCallRetInfo(this, nRet, _CS(_T("Get Camera ID")));
	}
	else
	{
		GetDlgItem(IDC_EDIT1)->SetWindowText(_T(""));
		MessageBox(_CS(_T("get camera id failed")));
	}
	return;
}

void CDlgReal::OnBnClickedButtonStartRealRecord()
{
	CFileDialog dlg(FALSE, _T(""), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("dav (*.dav)|*.dav|avi (*.avi)|*.avi|(*.*)|*.*||"));//dav (*.dav)|avi (*.avi)|*.avi|asf (*.asf)|*.asf|
	if(dlg.DoModal() != IDOK)
		return;
	CString strFilePath = dlg.GetPathName();

	CWideToMulti szPathName(strFilePath);

	char szPath[MAX_PATH]={0};
	strcpy_s(szPath,sizeof(szPath),szPathName.c_str());
	m_dlgWndPlayer.StopRealRecord(m_nDLLHandle, m_nSeq);
	::ShowCallRetInfo(this, m_dlgWndPlayer.StartRealRecord(m_nDLLHandle, m_nSeq, szPath), _CS(_T("Start real-time video recording")));
}

void CDlgReal::OnBnClickedButtonStopRealRecord()
{	
	::ShowCallRetInfo(this, m_dlgWndPlayer.StopRealRecord(m_nDLLHandle, m_nSeq), _CS(_T("Stop real-time video recording")));
}

void CDlgReal::OnBnClickedButtonSetOsdTxt()
{
	CString strInfo;
	GetDlgItem(IDC_EDIT_OSD_INFO)->GetWindowText(strInfo);
	int nLenth = strInfo.GetLength();

	if (nLenth>30)
	{
		MessageBox(_CS(_T("Please set within 30 characters!")));
		return;
	}

	CWideToMulti szOsdTxt(strInfo);
	
	char szOsd[MAX_PATH]={0};
	strcpy_s(szOsd,sizeof(szOsd),szOsdTxt.c_str());

	
   ::ShowCallRetInfo(this, m_dlgWndPlayer.SetOsdTxt(m_nDLLHandle, m_nSeq,szOsd), _CS(_T("Set OSD file text")));
}

void CDlgReal::OnBnClickedButtonCleanUpOsdInfo()
{
	::ShowCallRetInfo(this, m_dlgWndPlayer.CleanUpOsdInfo(m_nDLLHandle, m_nSeq), _CS(_T("Clear osd info")));
}

void CDlgReal::OnBnClickedButtonGetUrl()
{
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	Get_RealStreamUrl_Info_t stuRealStreamUrlInfo = {0};
	strcpy_s(stuRealStreamUrlInfo.szCameraId, sizeof(stuRealStreamUrlInfo.szCameraId), szCameraId.c_str());
	stuRealStreamUrlInfo.nStreamType = DPSDK_CORE_STREAMTYPE_MAIN;
	stuRealStreamUrlInfo.nMediaType = DPSDK_CORE_MEDIATYPE_VIDEO;
	stuRealStreamUrlInfo.nTransType = DPSDK_CORE_TRANSTYPE_TCP;

	int iRet = DPSDK_GetRealStreamUrl(m_nDLLHandle,&stuRealStreamUrlInfo);
    ::ShowCallRetInfo(this,iRet, _CS(_T("Get URL")));

	if(iRet == 0)
	{
		CString strRealUrl(stuRealStreamUrlInfo.szUrl);
		MessageBox(strRealUrl);
	}

}

void CDlgReal::OnBnClickedButtonCloseUrl()
{
	/*int iRet = DPSDK_CloseStreamUrlBySeq(m_nDLLHandle,m_iRealSeq);
	::ShowCallRetInfo(this,iRet, _CS(_T("Close URL")));*/

}

void CDlgReal::OnBnClickedButtonCloseUrlByCamId()
{
	//CString strCameraId;
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//CWideToUtf8 szCameraId(strCameraId.GetString());

	//int iRet = DPSDK_CloseStreamUrlByCameraId(m_nDLLHandle,szCameraId.c_str());
	//::ShowCallRetInfo(this,iRet, _CS(_T("Close according to channel no.")));
}

void CDlgReal::OnBnClickedButtonAdjustColor()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData(TRUE);

	Video_Color_Info_t videoColorInfo;
	videoColorInfo.nBrightness = m_nBrightness;
	videoColorInfo.nContrast = m_nContrast;
	videoColorInfo.nHue = m_nHue;
	videoColorInfo.nSaturation = m_nSaturation;

	::ShowCallRetInfo(this, m_dlgWndPlayer.AdjustColor(m_nDLLHandle, m_nSeq, videoColorInfo), _CS(_T("Set image property")));
}

void CDlgReal::OnBnClickedButtonGetColor()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	Video_Color_Info_t videoColorInfo;

	::ShowCallRetInfo(this, m_dlgWndPlayer.GetColor(m_nDLLHandle, m_nSeq, videoColorInfo), _CS(_T("Get image property")));

	m_nBrightness = videoColorInfo.nBrightness;
	m_nContrast = videoColorInfo.nContrast;
	m_nHue = videoColorInfo.nHue;
	m_nSaturation = videoColorInfo.nSaturation;

	UpdateData(FALSE);
}

void CDlgReal::OnBnClickedButtonStartAudio()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	::ShowCallRetInfo(this, DPSDK_OpenAudio(m_nDLLHandle, m_nSeq,true), _CS(_T("Start audio")));

}

void CDlgReal::OnBnClickedButtonCloseAudio()
{
	::ShowCallRetInfo(this, DPSDK_OpenAudio(m_nDLLHandle, m_nSeq,false), _CS(_T("Close audio")));
}

void CDlgReal::OnBnClickedButtonSetVolume()
{
	CString strVolume;
	GetDlgItem(IDC_EDIT_VOLUME)->GetWindowText(strVolume);
	int nVol = _tstof(strVolume);

	::ShowCallRetInfo(this,DPSDK_SetVolume(m_nDLLHandle,m_nSeq,nVol),_CS(_T("Adjust volume")));
	int nRet = DPSDK_SetVolume(m_nDLLHandle,m_nSeq,nVol);
	if (nRet == 0)
	{
		m_nVolReal = nVol;//�ɹ�����0����ȥ����m_nVolreal
	}
}

void CDlgReal::OnBnClickedButtonGetExternalUrl()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

    CString strCameraId;
    GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
    CWideToUtf8 szCameraId(strCameraId.GetString());
	
    Get_ExternalRealStreamUrl_Info_t stuExternalRealStreamUrlInfo = {0};
    strcpy_s(stuExternalRealStreamUrlInfo.szCameraId, sizeof(stuExternalRealStreamUrlInfo.szCameraId), szCameraId.c_str());
    stuExternalRealStreamUrlInfo.bUsedVCS = false;
    stuExternalRealStreamUrlInfo.nMediaType = DPSDK_CORE_MEDIATYPE_VIDEO;
    stuExternalRealStreamUrlInfo.nStreamType = DPSDK_CORE_STREAMTYPE_MAIN;
    stuExternalRealStreamUrlInfo.nTrackId = DPSDK_CORE_TRACKIDTYPE_DHSTD;
    stuExternalRealStreamUrlInfo.nTransType = DPSDK_CORE_TRANSTYPE_TCP;

    int iRet = DPSDK_GetExternalRealStreamUrl(m_nDLLHandle,&stuExternalRealStreamUrlInfo);
    ::ShowCallRetInfo(this,iRet, _CS(_T("Get external URL")));
  
    if(iRet == 0)
 	{
 		CString strRealUrl(stuExternalRealStreamUrlInfo.szUrl);
 		MessageBox(strRealUrl);
 	}
}

void CDlgReal::OnBnClickedButtonGetVolume()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nVol;
	::ShowCallRetInfo(this,DPSDK_GetVolume(m_nDLLHandle,m_nSeq,nVol),_CS(_T("Adjust volume")));

	//if (nVol<64895)
	//{
	//	nVol += 1;
	//}
	if (m_nVolReal == 0)//�Ȼ�ȡ����
	{
		m_nVolReal = nVol;
	}	
	else if (m_nVolReal != 0)//�����������Ժ��ֻ�ȡ����
	{
		nVol = m_nVolReal;
	}


	CString strVolume;
	strVolume.Format(_T("%d"),nVol);

	GetDlgItem(IDC_EDIT_VOLUME)->SetWindowText(strVolume);
}

void DPSDK_CALLTYPE CDlgReal::fnDrawFun(int32_t nPDLLHandle, int32_t nSeq, void *hDc,void *pUser)
{
	CString str = _CS(_T("this is a test!"));

	SetBkMode((HDC)hDc,TRANSPARENT);
	SetTextColor((HDC)hDc, RGB(255,0,0));

	LOGFONT lf = {0};
	HFONT hFontNew, hFontOld;
	lf.lfHeight = 15;
	::lstrcpy(lf.lfFaceName,L"����");        

	hFontNew = CreateFontIndirect(&lf);
	hFontOld = (HFONT) SelectObject((HDC)hDc,hFontNew);

	TextOut((HDC)hDc, 50, 50, str, str.GetLength());

	SelectObject((HDC)hDc,hFontOld);
	DeleteObject(hFontNew);
}

void CDlgReal::OnBnClickedButtonSetDrawfun()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	::ShowCallRetInfo(this,DPSDK_RegisterDrawFun(m_nDLLHandle,m_nSeq, fnDrawFun, this),_CS(_T("DrawFun")));
}

//YUV���ݽṹ��
typedef struct tagPictureData
{
	UCHAR *pucData[4];			/**pucData[0]:Y ƽ��ָ�룬
								pucData[1]:U ƽ��ָ�룬
								pucData[2]:V ƽ��ָ�� */
	ULONG ulLineSize[4];		/**ulLineSize[0]: Y ƽ��ָ�룬
								ulLineSize[1]: U ƽ��ָ��,
								ulLineSize[2]: V ƽ��ָ�� */
	ULONG ulPicHeight;			/**ͼƬ�߶� */
	ULONG ulPicWidth;			/**ͼƬ���� */
	ULONG ulRenderTime;			/**������Ⱦ��ʱ�����ݣ���λΪ���룩*/
	ULONG ulReserverParam1;		/**�������� */
	ULONG ulReserverParam2;		/**�������� */
}PICTURE_DATA_S,*LPPICTURE_DATA_S;

double YUV2RGB_CONVERT_MATRIX[3][3] =
{
	{ 1, 0, 1.4022 },
	{ 1, -0.3456, -0.7145 },
	{ 1, 1.771, 0 }
};

static void ConvertYUV2RGB(byte* yuvFrame, byte* rgbFrame, int width, int height)
{
	int uIndex = width * height;
	int vIndex = uIndex + ((width * height) >> 2);
	int gIndex = width * height;
	int bIndex = gIndex * 2;

	int temp = 0;

	for ( int y = 0; y < height; y++ )
	{
		for ( int x = 0; x < width; x++ )
		{
			// R����
			temp = (int)(yuvFrame[y * width + x] + (yuvFrame[vIndex + (y / 2) * (width / 2) + x / 2] - 128) * YUV2RGB_CONVERT_MATRIX[0][2]);
			rgbFrame[y * width + x] = (byte)(temp < 0 ? 0 : (temp > 255 ? 255 : temp));
			// G����
			temp = (int)(yuvFrame[y * width + x] + (yuvFrame[uIndex + (y / 2) * (width / 2) + x / 2] - 128) * YUV2RGB_CONVERT_MATRIX[1][1] +
				(yuvFrame[vIndex + (y / 2) * (width / 2) + x / 2] - 128) * YUV2RGB_CONVERT_MATRIX[1][2]);
			rgbFrame[gIndex + y * width + x] = (byte)(temp < 0 ? 0 : (temp > 255 ? 255 : temp));
			// B����
			temp = (int)(yuvFrame[y * width + x] + (yuvFrame[uIndex + (y / 2) * (width / 2) + x / 2] - 128) * YUV2RGB_CONVERT_MATRIX[2][1]);
			rgbFrame[bIndex + y * width + x] = (byte)(temp < 0 ? 0 : (temp > 255 ? 255 : temp));
			//Color c = Color.FromArgb(rgbFrame[y * width + x], rgbFrame[gIndex + y * width + x], rgbFrame[bIndex + y * width + x]);
			//bm.SetPixel(x, y, c);
		}
	}
	//return bm;
}


static void WriteBMP(byte* rgbFrame, int width, int height, const wchar_t* bmpFile)
{
	// д BMP ͼ���ļ���

	int yu = width * 3 % 4;
	yu = yu != 0 ? 4 - yu : yu;

	int bytePerLine = width * 3 + yu;
	int rgb_size = width * 3 * height;

	CFile fs;
	fs.Open(bmpFile, CFile::modeCreate | CFile::typeBinary | CFile::modeWrite);

	BITMAPFILEHEADER bmpHeader;
	BITMAPINFOHEADER bmpInfo;

	memset(&bmpHeader, 0, sizeof(BITMAPFILEHEADER));
	memset(&bmpInfo, 0, sizeof(BITMAPINFOHEADER));
	bmpHeader.bfType = 0x4D42; //"MB"
	bmpHeader.bfSize = rgb_size + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
	bmpHeader.bfReserved1 = 0;
	bmpHeader.bfReserved2 = 0;
	bmpHeader.bfOffBits = 54; //sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFODEADER);

	bmpInfo.biSize = sizeof(BITMAPINFOHEADER);
	bmpInfo.biWidth = width;
	bmpInfo.biHeight = height;
	bmpInfo.biPlanes = 1;
	bmpInfo.biBitCount = 24;
	bmpInfo.biCompression = BI_RGB;
	bmpInfo.biSizeImage = rgb_size;
	bmpInfo.biXPelsPerMeter = 0;
	bmpInfo.biYPelsPerMeter = 0;
	bmpInfo.biClrUsed = 0;
	bmpInfo.biClrImportant = 0;

	fs.Write(&bmpHeader, sizeof(BITMAPFILEHEADER));
	fs.Write(&bmpInfo, sizeof(BITMAPINFOHEADER));

	byte* data = new byte[bytePerLine * height];
	int gIndex = width * height;
	int bIndex = gIndex * 2;

	for ( int y = height - 1, j = 0; y >= 0; y--, j++ )
	{
		for ( int x = 0, i = 0; x < width; x++ )
		{
			data[y * bytePerLine + i++] = rgbFrame[bIndex + j * width + x]; // B
			data[y * bytePerLine + i++] = rgbFrame[gIndex + j * width + x]; // G
			data[y * bytePerLine + i++] = rgbFrame[j * width + x]; // R
		}
	}

	fs.Write(data, bytePerLine * height);
	fs.Flush();

	fs.Close();
}

static int32_t DPSDK_CALLTYPE fMediaDataYUVCB( IN int32_t nPDLLHandle,
												IN int32_t nSeq, 
												IN const char* pBuf, 
												IN int32_t nLen,
												IN Frame_Info* pFrameInfo,
												IN void* pUserParam)
{
	CDlgReal* pDlg = (CDlgReal*)pUserParam;
	if(pDlg == NULL || !pDlg->m_bYUVCapture)
	{
		return 0;
	}
	pDlg->m_bYUVCapture = false;

	PICTURE_DATA_S picData;
	if (pFrameInfo->nType == T_YV12)
	{
		picData.pucData[0] = (unsigned char*)pBuf;
		picData.ulLineSize[0] = pFrameInfo->nWidth;

		picData.pucData[1] = (unsigned char*)(pBuf+pFrameInfo->nWidth*pFrameInfo->nHeight*5/4);
		picData.ulLineSize[1] = pFrameInfo->nWidth/2;

		picData.pucData[2] = (unsigned char*)(pBuf+pFrameInfo->nWidth*pFrameInfo->nHeight);
		picData.ulLineSize[2] = pFrameInfo->nWidth/2;
	}
	else if (pFrameInfo->nType == T_IYUV)
	{
		picData.pucData[0] = (unsigned char*)pBuf;
		picData.ulLineSize[0] = pFrameInfo->nWidth;

		picData.pucData[1] = (unsigned char*)(pBuf+pFrameInfo->nWidth*pFrameInfo->nHeight);
		picData.ulLineSize[1] = pFrameInfo->nWidth/2;

		picData.pucData[2] = (unsigned char*)(pBuf+pFrameInfo->nWidth*pFrameInfo->nHeight*5/4);
		picData.ulLineSize[2] = pFrameInfo->nWidth/2;
	}

	picData.ulPicHeight = pFrameInfo->nHeight;
	picData.ulPicWidth = pFrameInfo->nWidth;
	picData.ulRenderTime = pFrameInfo->nStamp;
	picData.ulReserverParam1 = 0;
	picData.ulReserverParam2 = 0;

	int width = picData.ulPicWidth;
	int height = picData.ulPicHeight;
	int n = width * height;

	//if ( n != pPictureData->ulLineSize[0] )
	//{
	//	g_pMainDlg->ShowMsg("width * height != pPictureData->ulLineSize[0]");
	//	return;
	//}

	int framesize = n + n / 2;

	byte *yuv = new byte[framesize];
	byte *rgb = new byte[3 * n];

	memcpy(yuv, picData.pucData[0], n);

	memcpy(yuv + n, picData.pucData[1], n / 4);

	memcpy(yuv + n + n / 4, picData.pucData[2], n / 4);

	ConvertYUV2RGB(yuv, rgb, width, height);

	WriteBMP(rgb, width, height, pDlg->m_strYUVPath.GetBuffer());

	return 0;
}

void CDlgReal::OnBnClickedButtonYuv()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DPSDK_CloseRealYUVStreamBySeq(m_nDLLHandle, m_nSeq);
	m_bYUVCapture = false;

	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	Get_RealStream_Info_t stuRealStreamInfo = {0};
	strcpy_s(stuRealStreamInfo.szCameraId, sizeof(stuRealStreamInfo.szCameraId), szCameraId.c_str());
	stuRealStreamInfo.nStreamType = DPSDK_CORE_STREAMTYPE_MAIN;
	stuRealStreamInfo.nMediaType = DPSDK_CORE_MEDIATYPE_VIDEO;
	stuRealStreamInfo.nTransType = DPSDK_CORE_TRANSTYPE_TCP;

	ShowCallRetInfo(this, DPSDK_GetRealYUVStream(m_nDLLHandle, m_nSeq, &stuRealStreamInfo, fMediaDataYUVCB, this), _CS(_T("Get YUV stream")));
}

void CDlgReal::OnBnClickedButtonStopYuv()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	ShowCallRetInfo(this, DPSDK_CloseRealYUVStreamBySeq(m_nDLLHandle, m_nSeq), _CS(_T("Close YUV stream")));
}

void CDlgReal::OnBnClickedButtonYuvCapture()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CFileDialog dlg(FALSE, _T(".bmp"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("BMP Files (*.bmp)|*.bmp|"));
	if (dlg.DoModal() == IDOK)
	{
		m_strYUVPath = dlg.GetPathName();
		m_bYUVCapture = true;
		ShowCallRetInfo(this, 0, _CS(_T("YUV snapshot")));
	}
}

IWidget* CDlgReal::GetWidget() const
{
	return const_cast<CDlgReal*>(this);
}

CString CDlgReal::GetTestUIName() const
{
	return _T("Real-time");
}

void CDlgReal::ShowUI(BOOL bShow)
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

//void CDlgReal::OnBnClickedBtnOpenvideopreview()
//{
//	// TODO: �ڴ����ӿؼ�֪ͨ�����������
//	CloseRealStreamBySeq();
//
//	CString strCameraId;
//	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
//	CWideToUtf8 szCameraId(strCameraId.GetString());
//
//	Get_RealStream_Info_t stuRealStreamInfo = {0};
//	strcpy_s(stuRealStreamInfo.szCameraId, sizeof(stuRealStreamInfo.szCameraId), szCameraId.c_str());
//	stuRealStreamInfo.nStreamType = Real_Video_Splite_8;
//	stuRealStreamInfo.nMediaType = DPSDK_CORE_MEDIATYPE_VIDEO;
//	stuRealStreamInfo.nTransType = DPSDK_CORE_TRANSTYPE_TCP;
//
//#ifdef USING_DPSDK_EXT
//	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideoPreview(m_nDLLHandle, m_nSeq, &stuRealStreamInfo,0), _CS(_T("Open video")));
//	//::ShowCallRetInfo(this,DPSDK_RegisterDrawFun(m_nDLLHandle,m_nSeq, fnDrawFun, this),_CS(_T("DrawFun")));
//
//#else
//	int nRet = ::ShowCallRetInfo(this, DPSDK_GetRealStream(m_nDLLHandle, m_nSeq, &stuRealStreamInfo, m_dlgWndPlayer.GetMediaDataCallbackFunc(), &m_dlgWndPlayer), _CS(_T("Open video")));
//	if (nRet == DPSDK_RET_SUCCESS)
//	{
//		m_dlgWndPlayer.OpenStream(m_nSeq);
//	}
//#endif
//}

LRESULT CDlgReal::OnModTransMsg(WPARAM wParam, LPARAM lParam)
{
	int nMsgType = (int) wParam;
	switch(nMsgType)
	{
	case MSG_IVS_ALARM:
		{
			IVS_Alarm_Info_t* pIvsAlarmInfo = (IVS_Alarm_Info_t*)lParam;
			if(pIvsAlarmInfo)
			{
				//m_nSeq
				DPSDK_SetIVSAlarmInfo(m_nDLLHandle, m_nSeq, pIvsAlarmInfo->nAlarmType, pIvsAlarmInfo->pszAlarmData, pIvsAlarmInfo->nAlarmDataLen);

				delete pIvsAlarmInfo;
				pIvsAlarmInfo = NULL;
			}
		}
		break;
	default:
		break;
	}
	return 0L;
}

void CDlgReal::OnBnClickedCheckRule()
{
	int bRuleShow = m_CheckRule.GetCheck();
	::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_RULE_VISIBLE, bRuleShow);
}

void CDlgReal::OnBnClickedCheckObj()
{
	int bObjShow = m_checkObj.GetCheck();
	::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_OBJ_VISIBLE, bObjShow);
}

void CDlgReal::OnBnClickedCheckLocus()
{
	int bLocusShow = m_checkLocus.GetCheck();
	::DPSDK_SetIvsShowFlag(m_nDLLHandle, m_nSeq, IVS_LOCUS_VISIBLE, bLocusShow);
}

void CDlgReal::OnBnClickedButtonGetAudioChannels()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	for (int i = ((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->GetCount()-1; i >= 0; i--)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->DeleteString( i );
	}
	int channels = 0;
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetAudioChannels(m_nDLLHandle, m_nSeq, channels), _CS(_T("��ȡ��������")));

	if (nRet == 0 && channels > 0)
	{
		
		for (int i = 0; i < channels; i++)
		{
			CString strId;
			strId.Format(_T("%d"), i);
			((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->InsertString(i, strId);
			((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->SetItemData(i, (DWORD)&i);
		}
		((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->SetCurSel(0);	
	}
}

void CDlgReal::OnBnClickedButtonOpenCloseAudioChannel()
{
	int audioChannel = ((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->GetCurSel();
	int flag = ((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CAHANNEL_FLAG))->GetCurSel();
	bool bflag = (flag == 0)?false:true;
	int nRet = ::ShowCallRetInfo(this, DPSDK_SetAudioChannel(m_nDLLHandle, m_nSeq, audioChannel, bflag), _CS(_T("��������״̬")));
	return;
}

void CDlgReal::OnBnClickedButtonGetChannelState()
{
	int audioChannel = ((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_CHANNEL))->GetCurSel();
	bool bflag = false;
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetAudioChannelState(m_nDLLHandle, m_nSeq, audioChannel, bflag), _CS(_T("��������״̬")));
	if (nRet == 0)
	{
		CString strId;
		strId.Format(_T("�����ţ�%d   ״̬��%s"), audioChannel, (bflag)?_T("��"):_T("��"));
		MessageBox(strId);
	}
	
}
