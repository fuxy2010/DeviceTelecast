// Test_PlatformDLLDlg.h : ͷ�ļ�
//

#pragma once
#include "DPSDK_Core.h"
#include "DlgReal.h"
#include "DlgDGroup.h"
#include "DlgPtz.h"
#include "DlgPlayback.h"
#include "DlgAlarm.h"
#include "TvWallDlg.h"
#include "DlgGeneral.h"
#include "DlgBay.h"
#include "DlgTalk.h"
#include "DlgFtp.h"
#include "DlgChangePassword.h"
#include "DlgAlarmBusiness.h"
#include "DlgLogin.h"
#include "Utils/UtilsMain.h"
#include "DlgTab.h"
#include "DlgIntelligent.h"
#include "DlgPrison.h"

#define  LAYOUT_CLIENT_WIDTH  1024    //960
#define  LAYOUT_CLIENT_HEIGHT 768     //720
#define  LAYOUT_DGROUP_POSX   11
#define  LAYOUT_DGROUP_POSY   55
#define  LAYOUT_DGROUP_WIDTH  194
#define  LAYOUT_DGROUP_HEIGHT 555
#define  LAYOUT_TAB_HEIGHT    23
#define  LAYOUT_TAB_POSX      212
#define  LAYOUT_TAB_POSY      30
#define  LAYOUT_FUN_HEIGHT    555

typedef struct tagDeviceChangeInfo
{
	dpsdk_change_type_e						changeType;

	char									szDevId[DPSDK_CORE_DEV_ID_LEN];					// 
	char									szDepCode[DPSDK_CORE_DGROUP_DGPCODE_LEN];		// 
	char									szNewDepCode[DPSDK_CORE_DGROUP_DGPCODE_LEN];	// 
}device_change_info_t;

typedef struct tagDeviceStatusInfo
{
	dpsdk_device_status_type_e				statusType;

	char									szDevId[DPSDK_CORE_DEV_ID_LEN];					// 
}device_status_info_t;

typedef struct tagChnlStatusInfo
{
	dpsdk_device_status_type_e				statusType;

	char									szChnlId[DPSDK_CORE_DEV_ID_LEN];					// 
}chnl_status_info_t;

typedef struct tagOrgDevChangeInfo
{
	dpsdk_org_change_type_e orgchangetype;
}org_dev_change_info_t;

#define WM_DEVICE_CHANGE		WM_USER+1000
#define WM_DEVICE_STATUS        WM_USER+1001
#define WM_STATUS               WM_USER+1002
#define WM_NVRCHNL_STATUS       WM_USER+1003
#define WM_LOGIN_SUCCESS        WM_USER+1004
#define WM_ORG_DEV_CHANGE       WM_USER+1005
#define WM_MOD_TRANS_MSG        WM_USER+1006
#define WM_INVITE_VT_CALL		WM_USER+1007

enum
{
	MSG_IVS_ALARM = 0,
};

struct IVS_Alarm_Info_t
{
	uint32_t	nAlarmType;
	char*		pszAlarmData;
	uint32_t	nAlarmDataLen;
};
// CTest_PlatformDLLDlg �Ի���
class CTest_DPSDK_CoreDlg : public CDialog
{
// ����
public:
	CTest_DPSDK_CoreDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TEST_PLATFORMDLL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()

	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedButtonLoadAllGroup();
	afx_msg void OnBnClickedButtonGetGroupString();
	afx_msg LRESULT OnDeviceStatusCallback( WPARAM wParam, LPARAM lParam );
	afx_msg LRESULT OnDpsdkStatusCallback( WPARAM wParam, LPARAM lParam );
	afx_msg LRESULT OnMsgLoginSuccess(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnOrgDevChangeCallback( WPARAM wParam, LPARAM lParam );
	afx_msg LRESULT OnModTransMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnClose();
	
private:
	CDlgReal				m_dlgReal;
	CDlgPtz					m_dlgPtz;
	CDlgPlayback			m_dlgPlayback;
	CDlgAlarm				m_dlgAlarm;
	CTvWallDlg				m_dlgTvWall;
	CDlgGeneral				m_dlgGeneral;
	CDlgBay					m_dlgBay;
	CDlgTalk				m_dlgTalk;
	CDlgFtp					m_dlgFtp;
	CDlgChangePassword		m_dlgChangePassword;
	CAlarmBusiness			m_dlgAlarmBusiness;
	CDlgLogin               m_dlgLogin;
	CDlgTab                 m_dlgTab;
	DlgIntelligent			m_dlgIntelligent;
	CDlgPrison				m_dlgPrison;

	static CTest_DPSDK_CoreDlg* m_instance;

public:
	BOOL DoLogin();
	void OnLoginSuccess();
	static CTest_DPSDK_CoreDlg* GetInstance();

public:
	CDlgDGroup		m_dlgDGroup;

	int32_t			m_nDLLHandle;	
	int32_t			m_nGroupInfoLen;
	
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnBnClickedBtnGeneral2();
	afx_msg void OnBnClickedButtonChangePassword();
	afx_msg void OnBnClickedButtonSetlog();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedBtTestjson();
	afx_msg void OnBnClickedBtGetuserinfo();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMenuLoadOs();
	afx_msg void OnMenuGetOs();
	afx_msg void OnMenuModifyPw();
	afx_msg void OnMenuSetLog();
	afx_msg void OnDmsGetPic();
	afx_msg void OnMenuGetByCwh();
	afx_msg void OnMenuStrtobinary();
	afx_msg void OnBnClickedCheckCompressed();
	afx_msg void OnMenuLogin();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
