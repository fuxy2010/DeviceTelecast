// DlgIntelligent.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgIntelligent.h"


// DlgIntelligent �Ի���

IMPLEMENT_DYNAMIC(DlgIntelligent, CDialog)

DlgIntelligent::DlgIntelligent(CWnd* pParent /*=NULL*/)
	: CDialog(DlgIntelligent::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_INTELLIGENT)
{
	memset(szCameraID, 0, sizeof(szCameraID));
	nQuerySeq = 0;
	m_nDLLHandle = 0;
	totalCount = 0;
}

DlgIntelligent::~DlgIntelligent()
{
}

void DlgIntelligent::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_CountList);
}

void DlgIntelligent::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void DlgIntelligent::CloseWin()
{
	DPSDK_StopQueryPersonCount(m_nDLLHandle, szCameraID, nQuerySeq);
	CDialog::OnClose();
}

BOOL DlgIntelligent::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	GetDlgItem(IDC_EDIT_CAMERA_ID)->SetWindowText(_T("1000001$1$0$0"));

	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_GRANULARITY));
	((CComboBox*)GetDlgItem(IDC_COMBO_GRANULARITY))->SetCurSel(2);

	SYSTEMTIME st;
	GetLocalTime(&st);
	CTime tm1(st.wYear, st.wMonth, st.wDay, 0, 0, 0);
	CTime tm2(st.wYear, st.wMonth, st.wDay, 23, 59, 59);

	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_BEGIN_DATE))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_BEGIN_TIME))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_END_DATE))->SetTime(&tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_END_TIME))->SetTime(&tm2);

	m_CountList.SetExtendedStyle(m_CountList.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_CountList.InsertColumn(1, _CS(_T("���")), LVCFMT_CENTER, 50);
	m_CountList.InsertColumn(2, _CS(_T("��ʼʱ��")), LVCFMT_CENTER, 150);
	m_CountList.InsertColumn(3, _CS(_T("����ʱ��")), LVCFMT_CENTER, 150);
	m_CountList.InsertColumn(4, _CS(_T("��������")), LVCFMT_CENTER, 100);
	m_CountList.InsertColumn(5, _CS(_T("��ȥ����")), LVCFMT_CENTER, 100);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

BEGIN_MESSAGE_MAP(DlgIntelligent, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_GET_ALL_COUNT, &DlgIntelligent::OnBnClickedButtonGetAllCount)
	ON_BN_CLICKED(IDC_BUTTON_STOP_COUNT, &DlgIntelligent::OnBnClickedButtonStopCount)
	ON_BN_CLICKED(IDC_BUTTON_GET_DITAL_COUNT, &DlgIntelligent::OnBnClickedButtonGetDitalCount)
END_MESSAGE_MAP()


void DlgIntelligent::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* DlgIntelligent::GetWidget() const
{
	return const_cast<DlgIntelligent*>(this);
}

CString DlgIntelligent::GetTestUIName() const
{
	return _T("Intelligent");
}
// DlgIntelligent ��Ϣ��������

void DlgIntelligent::OnBnClickedButtonGetAllCount()
{
	uint32_t nStartTime = 0;
	uint32_t nEndTime = 0;
	int nGranularity = 2;

	CString strCameraId;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strGranularity;
	GetDlgItem(IDC_COMBO_GRANULARITY)->GetWindowText(strGranularity);
	nGranularity = _ttoi(strGranularity.GetString());

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_BEGIN_DATE))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_BEGIN_TIME))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_END_DATE))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER_END_TIME))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());

	strcpy_s(szCameraID, sizeof(szCameraID), szCameraId.c_str());
	nStartTime = tmStart.GetTime();
	nEndTime = tmEnd.GetTime();

	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryPersonCount(m_nDLLHandle, szCameraID, nQuerySeq, totalCount, nStartTime, nEndTime, nGranularity), _CS(_T("Query Person Count ")));
	CString strType;
	strType.Format(_CS(_T("ͳ������: %d")),totalCount);
	MessageBox(strType);
}

void DlgIntelligent::OnBnClickedButtonStopCount()
{
	int nRet = ::ShowCallRetInfo(this, DPSDK_StopQueryPersonCount(m_nDLLHandle, szCameraID, nQuerySeq), _CS(_T("Stop Person Count ")));
}

void DlgIntelligent::OnBnClickedButtonGetDitalCount()
{
	m_CountList.DeleteAllItems();
	Person_Count_Info_t* info = new Person_Count_Info_t[100];
	memset(info, 0, sizeof(Person_Count_Info_t) * 100);
	for (int i = 0; i < (totalCount/100 + 1); ++i)
	{
		int nRet = ::ShowCallRetInfo(this, DPSDK_QueryPersonCountBypage(m_nDLLHandle, szCameraID, nQuerySeq, i, 100, info), _CS(_T("Query Person Count dital ")));
		if (nRet == 0)
		{
			InsertPersonInfoItem(info);
		}
	}
	DPSDK_StopQueryPersonCount(m_nDLLHandle, szCameraID, nQuerySeq); //���ֹͣ��ѯʹ��
}

void DlgIntelligent::InsertPersonInfoItem(Person_Count_Info_t* info)
{
	for (int i = 0; i < 100; ++i)
	{
		if (info[i].nStartTime == 0)
		{
			break;
		}
		if (info[i].nEnteredSubTotal == 0 && info[i].nExitedSubtotal == 0)
		{
			continue;
		}
		int nSeq = m_CountList.GetItemCount();
		CString strSeq;
		strSeq.Format(_T("%d"), nSeq+1);
		m_CountList.InsertItem(nSeq, strSeq); // ���

		CTime tmBegin(info[i].nStartTime);
		CString strBeginTime = tmBegin.Format(_T("%Y-%m-%d %H:%M:%S"));
		m_CountList.SetItemText(nSeq, 1, strBeginTime);// ��ʼʱ��

		CTime tmEnd(info[i].nEndTime);
		CString strEndTime = tmEnd.Format(_T("%Y-%m-%d %H:%M:%S"));
		m_CountList.SetItemText(nSeq, 2, strEndTime); // ����ʱ��

		CString strEntered;
		strEntered.Format(_T("%d"), info[i].nEnteredSubTotal);
		m_CountList.SetItemText(nSeq, 3, strEntered); // ��������

		CString strExited;
		strExited.Format(_T("%d"), info[i].nExitedSubtotal);
		m_CountList.SetItemText(nSeq, 4, strExited); // ��ȥ����
	}
}
