// DlgGeneral.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgGeneral.h"
#include "DPSDK_Core_Error.h"
#include "DPSDK_Core.h"
#include "json/json.h"

int __stdcall GetDataCallback( int32_t nPDLLHandle, uint32_t nChangeType, uint32_t nCount, Org_Info_t* pOrgInfo,void* pUserParam )
{
	int nCout = 0;
	CDlgGeneral* pDlgGen = (CDlgGeneral*)pUserParam;     
	/*int nRet = DPSDK_LoadOrgInfoByType(pDlgGen->m_nDLLHandle,(dpsdk_org_node_e)4,nCout);
	if (nRet != 0)
	{
		CString strMessge;
		strMessge.Format(L"%d",nRet);

		AfxMessageBox(strMessge);
	}
	else
	{
		CString strMessge;
		strMessge.Format(L"%d",nCout);
		AfxMessageBox(strMessge);
	}*/
	return 0;
}

int __stdcall DPSDKGeneralJsonTransportCallback(int32_t nPDLLHandle, const char* szJson, void* pUserParam)
{
	CDlgGeneral* pDlgGen = (CDlgGeneral*)pUserParam;
	if(pDlgGen)
	{
		pDlgGen->OnDPSDKGeneralJsonTransportCallback(nPDLLHandle, szJson);
	}
	return 0;
}
// CDlgGeneral �Ի���

IMPLEMENT_DYNAMIC(CDlgGeneral, CDialog)

CDlgGeneral::CDlgGeneral(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgGeneral::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_GENERAL)
{
     m_type = 1;
}

CDlgGeneral::~CDlgGeneral()
{
}



void CDlgGeneral::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CDlgGeneral::OnInitDialog()
{  
	_CWndCS(this);
	GetDlgItem(IDC_EDIT_CAMERA_ID)->SetWindowText(_T("1000024$1$0$1"));
	GetDlgItem(IDC_EDIT_CODE)->SetWindowText(_T("001"));
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->InsertString(0,_CS(_T("Organization")));
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->InsertString(1,_CS(_T("Department")));
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->InsertString(2,_CS(_T("Monitor zone")));
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->InsertString(3,_CS(_T("District")));  
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->SetCurSel(0);
   	return TRUE;
}

BEGIN_MESSAGE_MAP(CDlgGeneral, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_SAVE_OPT_LOG, &CDlgGeneral::OnBnClickedButtonSaveOptLog)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_INFO, &CDlgGeneral::OnBnClickedButtonLoadInfo)
	ON_BN_CLICKED(IDC_BUTTON_GET_ORG_COUNT, &CDlgGeneral::OnBnClickedButtonGetOrgCount)
	ON_BN_CLICKED(IDC_BUTTON_GET_ORG_INFO, &CDlgGeneral::OnBnClickedButtonGetOrgInfo)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_DEP_RALATION, &CDlgGeneral::OnBnClickedButtonLoadDepRalation)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_INFO_PERSON, &CDlgGeneral::OnBnClickedButtonLoadInfoPerson)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_PERSON_COUNT_BY_DEP, &CDlgGeneral::OnBnClickedButtonLoadPersonCountByDep)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_INFO_PERSON_BY_DEP, &CDlgGeneral::OnBnClickedButtonLoadInfoPersonByDep)
	ON_BN_CLICKED(IDC_BUTTON_GET_CHANEL_ID, &CDlgGeneral::OnBnClickedButtonGetChanelId)
//	ON_BN_CLICKED(IDC_BUTTON_LOG, &CDlgGeneral::OnBnClickedButtonLog)
	ON_BN_CLICKED(IDC_BUTTON_GET_PEOPLE_COUNT, &CDlgGeneral::OnBnClickedButtonGetPeopleCount)
	ON_BN_CLICKED(IDC_BUTTON_QUERYNVRSTATUS, &CDlgGeneral::OnBnClickedButtonQuerynvrstatus)
	ON_BN_CLICKED(IDC_BUTTON_GENERAL_SENDMSG, &CDlgGeneral::OnBnClickedButtonGeneralSendmsg)
	ON_BN_CLICKED(IDC_BUTTON_GENERAL_REMOTE_SNAP, &CDlgGeneral::OnBnClickedButtonGeneralRemoteSnap)
	ON_BN_CLICKED(IDC_BUTTON_TESTJSON, &CDlgGeneral::OnBnClickedButtonTestJson)

	ON_BN_CLICKED(IDC_BTN_QUERY_BY_SITE, &CDlgGeneral::OnBnClickedBtnQueryBySite)
	ON_BN_CLICKED(IDC_BTN_PLATFORM_CUR_TIME, &CDlgGeneral::OnBnClickedBtnPlatformCurTime)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgGeneral::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BTN_LOAD_DGROUP_INFO_LAYERED, &CDlgGeneral::OnBnClickedBtnLoadDgroupInfoLayered)
	ON_BN_CLICKED(IDC_BUTTON_TIME_OPEN, &CDlgGeneral::OnBnClickedButtonTimeOpen)
	ON_BN_CLICKED(IDC_BUTTON_TIME_CLOSE, &CDlgGeneral::OnBnClickedButtonTimeClose)
	ON_BN_CLICKED(IDC_BTN_RECONNNECT_TO_CMS, &CDlgGeneral::OnBnClickedBtnReconnnectToCms)
END_MESSAGE_MAP()

void CDlgGeneral::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;

	 DPSDK_SetGeneralJsonTransportCallback(m_nDLLHandle,(fDPSDKGeneralJsonTransportCallback)DPSDKGeneralJsonTransportCallback,this);
}

// CDlgGeneral ��Ϣ��������

void CDlgGeneral::OnBnClickedButtonSaveOptLog()
{
	CString strOpeDes;
	GetDlgItemText(IDC_EDIT_DESC,strOpeDes);
	CWideToUtf8 strOpDec(strOpeDes);

	CString strCameraId;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	int iRet = DPSDK_SaveOptLog(m_nDLLHandle,szCameraId.c_str(),GetCurrentTime(),(dpsdk_log_optType_e)(4),strOpDec.c_str());//GetCurrentTime()
	::ShowCallRetInfo(this,iRet, _CS(_T("Storage operation log")));
	
}

void CDlgGeneral::OnBnClickedButtonLoadInfo()
{
	int iCount = 0;    
	CString strInfoType;
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->GetWindowText(strInfoType);
	if(strInfoType == _CS(_T("Department")))
	{
		m_type = 2;
	}
	else if (strInfoType == _CS(_T("Monitor zone")))
	{
		m_type = 3;
	}
	else if (strInfoType == _CS(_T("District")))
	{
		m_type = 4;
	}
	else if (strInfoType == _CS(_T("Organization")))
	{
		m_type = 1;
	}
     DPSDK_SetDPSDKOrgChangeCallback(m_nDLLHandle,(fDPSDKOrgChangeCallback)GetDataCallback,this);
	int iRet = DPSDK_LoadOrgInfoByType(m_nDLLHandle,(dpsdk_org_node_e)m_type,iCount);
	::ShowCallRetInfo(this,iRet,_CS(_T("According to type load organization info")));
	 
	CString strCount;
	strCount.Format(_CS(_T("Organization number is ��%d")),iCount);
	MessageBox(strCount);
	return;
}

void CDlgGeneral::OnBnClickedButtonGetChanelId()
{
	Get_Channel_Info_t* pGetChannelInfo = new Get_Channel_Info_t;
	memset(pGetChannelInfo, 0 , sizeof(Get_Channel_Info_t));
	memcpy(pGetChannelInfo->szDeviceId, "1000036", DPSDK_CORE_DEV_ID_LEN);
	pGetChannelInfo->nEncChannelChildCount = 3;
	pGetChannelInfo->pEncChannelnfo = new Enc_Channel_Info_t[pGetChannelInfo->nEncChannelChildCount];
	memset(pGetChannelInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_t)*pGetChannelInfo->nEncChannelChildCount);

	DPSDK_GetChannelInfo(m_nDLLHandle, pGetChannelInfo);

	delete [] pGetChannelInfo->pEncChannelnfo;
	pGetChannelInfo->pEncChannelnfo = NULL;
	delete [] pGetChannelInfo;
	pGetChannelInfo = NULL;
}

void CDlgGeneral::OnBnClickedButtonGetOrgCount()
{
	Get_Org_Count_Info_t OrgCntInfo;
	OrgCntInfo.nGroupCount = 0;
	CString strOrgCode;
	GetDlgItem(IDC_EDIT_CODE)->GetWindowText(strOrgCode);
	CWideToUtf8 szCode(strOrgCode.GetString());
	strcpy_s(OrgCntInfo.szCoding,12,szCode.c_str());

	CString strInfoType;
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->GetWindowText(strInfoType);
	if(strInfoType == _CS(_T("Department")))
	{
		m_type = 2;
	}
	else if (strInfoType == _CS(_T("Monitor zone")))
	{
		m_type = 3;
	}
	else if (strInfoType == _CS(_T("District")))
	{
		m_type = 4;
	}
	else if (strInfoType == _CS(_T("Organization")))
	{
		m_type = 1;
	}
  
	int iRet = DPSDK_GetOrgCountByType(m_nDLLHandle,(dpsdk_org_node_e)m_type,&OrgCntInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("According to type load organization info")));

	int iCount = OrgCntInfo.nGroupCount;

	CString strCount;
	strCount.Format(_CS(_T("Organization number is ��%d")),iCount);
	MessageBox(strCount);
	return;
	
}

void CDlgGeneral::OnBnClickedButtonGetOrgInfo()
{
	Get_Org_Count_Info_t OrgCntInfo;
	OrgCntInfo.nGroupCount = 0;

	CString strInfoType;
	((CComboBox*)GetDlgItem(IDC_COMBO_INFO_TYPE))->GetWindowText(strInfoType);
	if(strInfoType == _CS(_T("Department")))
	{
		m_type = 2;
	}
	else if (strInfoType == _CS(_T("Monitor zone")))
	{
		m_type = 3;
	}
	else if (strInfoType == _CS(_T("District")))
	{
		m_type = 4;
	}
	else if (strInfoType == _CS(_T("Organization")))
	{
		m_type = 1;
	}

    CString strOrgCode;
	GetDlgItem(IDC_EDIT_CODE)->GetWindowText(strOrgCode);
	CWideToUtf8 szCode(strOrgCode.GetString());
	strcpy_s(OrgCntInfo.szCoding,12,szCode.c_str());
	DPSDK_GetOrgCountByType(m_nDLLHandle,(dpsdk_org_node_e)m_type,&OrgCntInfo);

    Get_Org_Info_t GetInfo;
	GetInfo.nOrgCount = OrgCntInfo.nGroupCount;
	GetInfo.pOrgInfo  = new Org_Info_t[GetInfo.nOrgCount];
	strcpy_s(GetInfo.szCoding,12,szCode.c_str());
	int iRet = DPSDK_GetOrgInfoByType( m_nDLLHandle,(dpsdk_org_node_e)m_type,&GetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("According to type load organization info")));

	if (GetInfo.nOrgCount == 0)
	{
		MessageBox(_CS(_T("Sorry, no matched info found!!!")));
		return;
	}

	CFileDialog dlg(FALSE, _T(".txt"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T(" Files (*.txt)|*.txt|"));
	if (dlg.DoModal() == IDOK)
	{
		CWideToMulti _szFileName(dlg.GetPathName());
		FILE *fp = NULL;
		fopen_s(&fp, _szFileName.c_str(), "a+");
		if (fp == NULL)
		{	
			return ;
		}
		if (iRet== DPSDK_RET_SUCCESS)
		{

			char buffer[1024] = {0};
			for (int i=0;i<GetInfo.nOrgCount;i++)
			{
				CUtf8ToWide szCode(GetInfo.pOrgInfo[i].szCode);
				CWideToMulti szCodeM(szCode.wc_str());

				CUtf8ToWide	szName(GetInfo.pOrgInfo[i].szName);
				CWideToMulti szNameM(szName.wc_str());

				CUtf8ToWide	szSN(GetInfo.pOrgInfo[i].szSN);
				CWideToMulti szSNM(szSN.wc_str());

				CUtf8ToWide	szType(GetInfo.pOrgInfo[i].szType);
				CWideToMulti szTypeM(szType.wc_str());

				CUtf8ToWide	szGpsX(GetInfo.pOrgInfo[i].szGpsX);
				CWideToMulti szGpsXM(szName.wc_str());

				CUtf8ToWide	szGpsY(GetInfo.pOrgInfo[i].szGpsY);
				CWideToMulti szGpsYM(szGpsY.wc_str());

				CUtf8ToWide	szMemo(GetInfo.pOrgInfo[i].szMemo);
				CWideToMulti szMemoM(szMemo.wc_str());

				sprintf(buffer,
					"szCode(%s),szName(%s),szSN(%s),szType(%s),szGpsX(%s),szGpsY(%s),szMemo(%s),nDomainId(%ld),nState(%ld)\n\n",
					szCodeM.c_str(),
					szNameM.c_str(),
					szSNM.c_str(),
					szTypeM.c_str(),
					szGpsXM.c_str(),
					szGpsYM.c_str(),
					szMemoM.c_str(),
					GetInfo.pOrgInfo[i].domainId,
					GetInfo.pOrgInfo[i].state);
				fwrite(buffer, 1,strlen(buffer)+1, fp);
			}	
		}		
		fclose(fp);
		fp = NULL;
	}		
	if (GetInfo.pOrgInfo!= NULL)
	{
		delete [] GetInfo.pOrgInfo;
		GetInfo.pOrgInfo=NULL;		
	}
	return ;
}


void CDlgGeneral::OnBnClickedButtonLoadDepRalation()
{
	int iCount = 0;

	int iRet = DPSDK_GetDeptAreaRelationCount(m_nDLLHandle,iCount);
	::ShowCallRetInfo(this,iRet,_CS(_T("Department zone relationship")));

	CString strCount;
	strCount.Format(_CS(_T("Relation record: %d")),iCount);
	MessageBox(strCount);
	return;	
}

void CDlgGeneral::OnBnClickedButtonLoadInfoPerson()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int iCount = 0;

	int iRet = DPSDK_LoadAllPersonInfo(m_nDLLHandle,iCount);
	::ShowCallRetInfo(this,iRet,_CS(_T("Load all staff info")));

	CString strCount;
	strCount.Format(_CS(_T("All staff quantity: %d")),iCount);
	MessageBox(strCount);
	return;
}

void CDlgGeneral::OnBnClickedButtonLoadPersonCountByDep()
{
	CString strOrgCode;
	GetDlgItem(IDC_EDIT_CODE)->GetWindowText(strOrgCode);
	CWideToUtf8 szCode(strOrgCode.GetString());
	char szDepCode[12] = {0};

	strcpy_s(szDepCode,12,szCode.c_str());
	int nCount = 0;
	int iRet = DPSDK_GetPersonCountByDept(m_nDLLHandle,szDepCode,nCount);
	::ShowCallRetInfo(this,iRet,_CS(_T("Search specific department staff quantity")));

	CString strCount;
	strCount.Format(_CS(_T("People number in the department is: %d")),nCount);
	MessageBox(strCount);
	return;
}

void CDlgGeneral::OnBnClickedButtonLoadInfoPersonByDep()
{
	Get_Person_Info_t GetInfo;
	GetInfo.pPersonInfo = 0;
	CString strOrgCode;
	GetDlgItem(IDC_EDIT_CODE)->GetWindowText(strOrgCode);
	CWideToUtf8 szCode(strOrgCode.GetString());
	char szDepCode[12] = {0};

	int nCount = 0;
	strcpy_s(szDepCode,strlen(szCode.c_str())+1,szCode.c_str());

	DPSDK_GetPersonCountByDept(m_nDLLHandle, szDepCode,nCount);

	GetInfo.pPersonInfo = new Person_Info_t[nCount];
	GetInfo.nPersonCount = nCount;
	strcpy_s(GetInfo.szDeptCoding,strlen(szCode.c_str())+1,szCode.c_str());

    int iRet = DPSDK_GetPersonInfoByDept(m_nDLLHandle,&GetInfo);
	::ShowCallRetInfo(this,iRet,_CS(_T("According to department loading staff info")));
	if (GetInfo.nPersonCount == 0)
	{
		MessageBox(_CS(_T("Sorry, no matched info found!!!")));
		return;
	}

	CFileDialog dlg(FALSE, _T(".txt"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T(" Files (*.txt)|*.txt|"));
	if (dlg.DoModal() == IDOK)
	{
		CWideToMulti _szFileName(dlg.GetPathName());
		FILE *fp = NULL;
		fopen_s(&fp, _szFileName.c_str(), "a+");
		if (fp == NULL)
		{	
			return ;
		}
		if (iRet== DPSDK_RET_SUCCESS)
		{
			char buffer[1024] = {0};
			for (int i=0;i<GetInfo.nPersonCount;i++)
			{
				CUtf8ToWide szId(GetInfo.pPersonInfo[i].szCode);
				CWideToMulti szIdM(szId.wc_str());

				CUtf8ToWide	szName(GetInfo.pPersonInfo[i].szName);
				CWideToMulti szNameM(szName.wc_str());

				CUtf8ToWide	szcoding(GetInfo.pPersonInfo[i].szDeptCode);
				CWideToMulti szcodingM(szcoding.wc_str());

				CUtf8ToWide	szsn(GetInfo.pPersonInfo[i].szSN);
				CWideToMulti szsnM(szsn.wc_str());

				CUtf8ToWide	sztype(GetInfo.pPersonInfo[i].szType);
				CWideToMulti sztypeM(sztype.wc_str());

				CUtf8ToWide	szoffice(GetInfo.pPersonInfo[i].szOffice);
				CWideToMulti szofficeM(szoffice.wc_str());

				CUtf8ToWide	szmobile(GetInfo.pPersonInfo[i].szMobileNum);
				CWideToMulti szmobileM(szmobile.wc_str());

				CUtf8ToWide	szvirtualNumber(GetInfo.pPersonInfo[i].szVirtualNum);
				CWideToMulti szvirtualNumberM(szvirtualNumber.wc_str());

				CUtf8ToWide	szstat(GetInfo.pPersonInfo[i].szState);
				CWideToMulti szstatM(szstat.wc_str());

				sprintf(buffer,
					"szId(%s),szName(%s),szcoding(%s),szsn(%s),sztype(%s),szoffice(%s),szmobile(%s),szvirtualNumber(%s),szstat(%s)\n\n",
					szIdM.c_str(),
					szNameM.c_str(),
					szcodingM.c_str(),
					szsnM.c_str(),
					sztypeM.c_str(),
					szofficeM.c_str(),
					szmobileM.c_str(),
					szvirtualNumberM.c_str(),
					szstatM.c_str());
				fwrite(buffer, 1,strlen(buffer)+1, fp);
			}	
		}	
		fclose(fp);
		fp = NULL;
	}	

	if (GetInfo.pPersonInfo!= NULL)
	{
		delete [] GetInfo.pPersonInfo;
		GetInfo.pPersonInfo=NULL;		
	}
	return ;
}
void CDlgGeneral::OnBnClickedButtonGetPeopleCount()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	/*Get_People_Count_t getPeopleCount;

	strcpy_s(getPeopleCount.szBeginTime,sizeof(getPeopleCount.szBeginTime),"2014-02-28 00:02:28");
	strcpy_s(getPeopleCount.szEndTime,sizeof(getPeopleCount.szEndTime),"2014-02-28 21:02:28");

	DPSDK_GetPeopleCount(m_nDLLHandle,&getPeopleCount);

	CString strPcCount;

	strPcCount.Format(_T("EnterCount:%d ; ExitCount:%d"),getPeopleCount.nEnterCount,getPeopleCount.nExitCount);

	MessageBox(strPcCount);*/
}



//int32_t CDlgGeneral::GetDataCallback( int32_t nPDLLHandle, uint32_t nChangeType, uint32_t nCount, Org_Info_t* pOrgInfo,void* pUserParam )
//{
//	int nCout = 0;
//	CDlgGeneral* pDlgGen = (CDlgGeneral*)pUserParam;
//	//int nRet = DPSDK_LoadOrgInfoByType(pDlgGen->m_nDLLHandle,(dpsdk_org_node_e)4,nCout);
//	//if (nRet != 0)
//	//{
//	//	CString strMessge;
//	//	strMessge.Format(L"%d",nRet);
//	//	//afxMessageBox(strMessge);
//	//AfxMessageBox(strMessge);
//	//}
//
//	return 0;
//
//
//}

void CDlgGeneral::OnBnClickedButtonQuerynvrstatus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//��ƽ̨��֧��json�ӿڣ�ʹ�ô˽ӿ�
	/*CString strCamID;
    GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);

	CWideToMulti szCamID(strCamID.GetString());
	const char* pCamID = szCamID.c_str();
	char* pIndex = const_cast<char*>(strchr(pCamID, '$'));
	if(pIndex != NULL)
	{
		pIndex[0] = 0;
	}
	DPSDK_QueryNVRChnlStatus(m_nDLLHandle, pCamID);*/

	//�ĳ�json�ӿڣ���ƽ̨ʹ��
	CString strCamID;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);

	CWideToMulti szCamID(strCamID.GetString());
	const char* pCamID = szCamID.c_str();
	char* pIndex = const_cast<char*>(strchr(pCamID, '$'));
	if(pIndex != NULL)
	{
		pIndex[0] = 0;
	}

	int nChnlNum = 0;
	int nRet = DPSDK_GetEncChannelCount(m_nDLLHandle, pCamID, nChnlNum);
	if(nRet == DPSDK_RET_SUCCESS)
	{
		demo::Json::Value queryInfo;
		queryInfo["method"] = "dmsDevStatus.getChlState";
		queryInfo["id"] = 42;
		demo::Json::Value& deviceInfo = queryInfo["params"];
		deviceInfo["DevID"] = pCamID;
		deviceInfo["chlCount"] = nChnlNum;
		nRet = DPSDK_GeneralJsonTransport(m_nDLLHandle, queryInfo.toStyledString().c_str(), DPSDK_MDL_DMS, GENERALJSON_TRAN_REQUEST);
	}
	::ShowCallRetInfo(this, nRet, _CS(_T("Query nvr status")));
}

void CDlgGeneral::OnDPSDKGeneralJsonTransportCallback(int32_t nPDLLHandle, const char* szJson)
{
	std::string strJson(szJson);
	demo::Json::Value jsonValue;
	demo::Json::Reader reader;
	if (!reader.parse(strJson, jsonValue))
	{
		::ShowCallRetInfo(this, -1, _CS(_T("json ����ʧ��")));
		return;
	}

	int id = jsonValue["id"].asInt();
	std::string strSrcMethod = jsonValue["method"].asString();
	bool bResult = jsonValue["result"].asBool();

	CString strDebugMsg = _T("");

	if(bResult)//���سɹ�
	{
		if (strSrcMethod.compare("dmsDevStatus.getChlState") == 0  && !jsonValue["params"].isNull() && jsonValue["params"].isObject() )
		{
			demo::Json::Value& ChlStatusList = jsonValue["params"]["chlStatusList"];
			demo::Json::Value::iterator chnl = ChlStatusList.begin();
			while ( chnl != ChlStatusList.end() )
			{	
				char szChnlNo[10] = {0};
				::strcpy_s(szChnlNo, 10, chnl.memberName());
				const char* p = chnl.memberName();
				int nStatus = ChlStatusList[p].asInt();
				p = NULL;

				chnl++;
				CMultiToWide sM2W(szChnlNo);
				CString strTemp = _T("");
				strTemp.Format(_T("chnlId=%s,status=%d;"), sM2W.wc_str(), nStatus);
				strDebugMsg+=strTemp;
			}

		}
		if (strSrcMethod == "User.getCurrentTime" && !jsonValue["params"].isNull() && jsonValue["params"].isObject() )
		{
			int64_t times = jsonValue["params"]["timeStr"].asInt64();
			time_t nTime = (time_t)times;
			struct tm *local;
			local = localtime(&nTime);
			strDebugMsg.Format(_T("Platform time now is %d-%d-%d %02d:%02d:%02d"), local->tm_year + 1900, local->tm_mon + 1, local->tm_mday, local->tm_hour,local->tm_min,local->tm_sec);
		}
	}else//����ʧ��
	{
		if (strSrcMethod.compare("dmsDevStatus.getChlState") == 0  && !jsonValue["error"].isNull() && jsonValue["error"].isObject() )
		{
			int nCode = jsonValue["error"]["Code"].asInt();
			std::string strMessage = jsonValue["error"]["Message"].asString();

			CString strTemp = _T("");
			strTemp.Format(_T("Code=%d,Message=%s;"), nCode, strMessage.c_str());
			strDebugMsg+=strTemp;
		}
	}

	//PrintfText(strDebugMsg);
}

void CDlgGeneral::OnBnClickedButtonGeneralSendmsg()
{
	// 
	CString strCamID;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);
	CWideToMulti szCamID(strCamID.GetString());
	const char* pCamID = szCamID.c_str();

	int devidlen = 0;

	for (int i = 0; i < strlen(pCamID); i ++)
	{
		if (pCamID[i] == '$')
		{
			devidlen = i;
			break;
		}
	}

	char devid[40] = {0};
	memcpy(devid, pCamID, devidlen);

	Send_OSDInfo_t sendosd = {0};
	strcpy(sendosd.szDevId, devid);

	CString sMsg;
    GetDlgItemText(IDC_EDIT_GENERAL_OSD, sMsg);

	CWideToUtf8 strMsg(sMsg);

	strcpy(sendosd.szMessage, strMsg.c_str());

	int ret = DPSDK_SendOSDInfo(m_nDLLHandle, &sendosd);
	
}

void CDlgGeneral::OnBnClickedButtonGeneralRemoteSnap()
{
	// TODO: 
	CString strCamID;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);
	CWideToMulti szCamID(strCamID.GetString());
	const char* pCamID = szCamID.c_str();


	DPSDK_RemoteDeviceSnap(m_nDLLHandle, pCamID, "c:\\" );
}

void CDlgGeneral::OnBnClickedButtonTestJson()
{
	//��ȡ������ʱ��
	//const char* szJson = "{\"method\":\"User.getCurrentTime\",\"params\":{},\"id\":88}";
	//int iRet = DPSDK_GeneralJsonTransport(m_nDLLHandle, szJson, DPSDK_MDL_CMS, GENERALJSON_TRAN_REQUEST);

	//��ȡ��������״̬
	//const char* szJson = "{\"method\":\"dev.getHADTStatus\",\"params\":{\"DevID\":\"1000002\"},\"id\":88}";
	//int iRet = DPSDK_GeneralJsonTransport(m_nDLLHandle, szJson, DPSDK_MDL_DMS, GENERALJSON_TRAN_REQUEST);

	//��ǰ���豸��ȡGPS��Ϣ
	//const char* szJson = "{\"method\":\"dms.queryGPS\",\"params\":{\"DevID\":\"1000013\",\"Channel\":0},\"id\":88}";
	//int iRet = DPSDK_GeneralJsonTransport(m_nDLLHandle, szJson, DPSDK_MDL_DMS, GENERALJSON_TRAN_REQUEST);

	//��ǰ���豸ץͼ
	const char* szJson = "{ \"method\":\"dev.snap\",\"params\":{\"DevID\":\"1000000\",\"DevChannel\":0,\"PicNum\":1,\"SnapType\":2,\"CmdSrc\":1},\"id\":88 }";
	int iRet = DPSDK_GeneralJsonTransport(m_nDLLHandle, szJson, DPSDK_MDL_DMS, GENERALJSON_TRAN_REQUEST);

	return;
}

void CDlgGeneral::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgGeneral::GetWidget() const
{
	return const_cast<CDlgGeneral*>(this);
}

CString CDlgGeneral::GetTestUIName() const
{
	return _T("General");
}

void CDlgGeneral::OnBnClickedBtnQueryBySite()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nChnlIdCount = 0;
	int nSiteCode = GetDlgItemInt(IDC_EDIT_QUERY_BY_SITE);
	int nRet = DPSDK_QueryChnlIdBySiteCode(m_nDLLHandle, nSiteCode, nChnlIdCount);
	if(nChnlIdCount > 0)
	{
		ChnlIdBySiteCode_Info_t info;
		info.pSingleChnlIdInfo = new Single_ChnlId_Info_t[nChnlIdCount];
		DPSDK_GetChnlIdBySiteCode(m_nDLLHandle, nSiteCode, &info);
		char szMsg[1024] = {0};
		for(int i = 0; i < nChnlIdCount; i++)
		{
			strcat(szMsg, info.pSingleChnlIdInfo[i].szChnlId);
			strcat(szMsg, "\r\n");
		}
		MessageBoxA(NULL, szMsg, NULL, MB_OK);
	}
	else
	{
		MessageBoxA(NULL, "No channel id", NULL, MB_OK);
	}
}

void CDlgGeneral::OnBnClickedBtnPlatformCurTime()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	long lCurTime = 0;
	int nRet = DPSDK_GetCurrentPlatformTime(m_nDLLHandle, lCurTime);
	if(nRet == 0)
	{
		char szBuf[100] = {0};
		sprintf(szBuf, "time = %ld", lCurTime);
		MessageBoxA(NULL, szBuf, NULL, MB_OK);
	}
	else
	{
		MessageBoxA(NULL, "DPSDK_GetCurrentPlatformTime failed", NULL, MB_OK);
	}
}

void CDlgGeneral::OnBnClickedButton1()
{
	//��ȡ��������Ϣ
	/*CString strCamID;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);

	CWideToMulti szCamID(strCamID.GetString());
	Channel_View_Info_t info;
	memset(&info, 0, sizeof(Channel_View_Info_t));
	int nRet = DPSDK_QueryChannelViewInfo(m_nDLLHandle, szCamID.c_str(), &info);

	const char* pCamID = szCamID.c_str();
	char* pIndex = const_cast<char*>(strchr(pCamID, '$'));
	if(pIndex != NULL)
	{
		pIndex[0] = 0;
	}
	
	nRet = DPSDK_QueryDeviceViewInfo(m_nDLLHandle, pCamID);

	nRet = nRet + 0;*/

	//����������ȡ������ʱ����
	CString strDebugMsg = _T("");

	CString strCamID;
	GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);

	CWideToMulti szCamID(strCamID.GetString());
	time_t nTime = (time_t)atoi(szCamID.c_str());
	struct tm *local;
	local = localtime(&nTime);
	strDebugMsg.Format(_T("time %d-%d-%d %02d:%02d:%02d"), local->tm_year + 1900, local->tm_mon + 1, local->tm_mday, local->tm_hour,local->tm_min,local->tm_sec);
	MessageBox(strDebugMsg);
	
	//�����豸ID��ȡ�豸��ϸ��Ϣ
	//CString strCamID;
	//GetDlgItem(IDC_EDIT_CAMERA_ID)->GetWindowText(strCamID);

	//CWideToMulti szCamID(strCamID.GetString());
	//Device_Info_Ex_t info = {0};
	//memset(&info, 0, sizeof(Device_Info_Ex_t));
	//int nRet = DPSDK_GetDeviceInfoExById(m_nDLLHandle, szCamID.c_str(), &info);

	//return;

	//int devtype = 0;
	//int nRet = DPSDK_GetDeviceTypeByDevId(m_nDLLHandle, pCamID, (dpsdk_dev_type_e&)devtype);
	//int devtype = -1;
	//int nRet = DPSDK_GetDeviceInfoById(m_nDLLHandle, pCamID, devtype);
	//CString strType;
	//strType.Format(_CS(_T("��������: %d")),devtype);
	//MessageBox(strType);
}

void CDlgGeneral::OnBnClickedBtnLoadDgroupInfoLayered()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nGroupLen = 0;
	char szOrgCode[200] = {0};
	GetDlgItemTextA(GetSafeHwnd(), IDC_EDIT_CODE, szOrgCode, 200);
	Load_Dep_Info_t stuLoadDepInfo = {""/*"001059"*/, DPSDK_CORE_GEN_GETGROUP_OPERATION_ALL};
	strcpy(stuLoadDepInfo.szCoding, szOrgCode);
	int nRet = DPSDK_LoadDGroupInfoLayered(m_nDLLHandle, &stuLoadDepInfo, nGroupLen);

	char* pGroupBuf = new char[nGroupLen+1];
	memset(pGroupBuf, 0, nGroupLen+1);
	DPSDK_GetDGroupLayeredStr(m_nDLLHandle, pGroupBuf, nGroupLen, szOrgCode);
	delete [] pGroupBuf;
	return;
}

void CDlgGeneral::OnBnClickedButtonTimeOpen()
{
	::ShowCallRetInfo(this, DPSDK_SetSyncTimeOpen(m_nDLLHandle, true), _CS(_T("��ȫ��Уʱ����")));
}

void CDlgGeneral::OnBnClickedButtonTimeClose()
{
	::ShowCallRetInfo(this, DPSDK_SetSyncTimeOpen(m_nDLLHandle, false), _CS(_T("�ر�ȫ��Уʱ����")));
}

void CDlgGeneral::OnBnClickedBtnReconnnectToCms()
{
	int nRet = DPSDK_ReconnectToCMS(m_nDLLHandle);
	if (nRet == 0)
	{
		::ShowCallRetInfo(this, nRet , _CS(_T("����CMS�ɹ�")));
	} 
	else
	{
		::ShowCallRetInfo(this, nRet, _CS(_T("����CMSʧ��")));
	}
}
