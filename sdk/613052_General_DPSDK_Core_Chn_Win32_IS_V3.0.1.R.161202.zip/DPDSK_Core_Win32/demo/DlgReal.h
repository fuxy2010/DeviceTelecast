#pragma once
#include "DPSDK_Core.h"
#include "WndPlayer.h"
#include "interface/IAbstractUI.h"
#include "DlgPtz.h"
#include "afxwin.h"

// CDlgReal �Ի���

class CDlgReal : public CDialog,public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgReal)
public:
	CDlgReal(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgReal();

	void SetHandle(int nDLLHandle);

// �Ի�������
	enum { IDD = IDD_DLG_REAL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
	
	
	afx_msg void OnBnClickedButtonOpenVideo();
	afx_msg void OnBnClickedButtonCloseVideo();
	afx_msg void OnBnClickedButtonCloseCamera();
	afx_msg void OnBnClickedButtonCapturePicture();
	afx_msg void OnClose();

	void CloseRealStreamBySeq(void);

private:
	CWndPlayer	m_dlgWndPlayer;
	int32_t		m_nDLLHandle;
	int32_t		m_nSeq;
public:
	CDlgPtz		m_dlgPtz;

	int m_iRealSeq;
public:
	static void DPSDK_CALLTYPE fnDrawFun(int32_t nPDLLHandle, int32_t nSeq, void *hDc,void *pUser);
	afx_msg void OnBtnGetCamid();
	afx_msg void OnBnClickedButtonStartRealRecord();
	afx_msg void OnBnClickedButtonStopRealRecord();
	afx_msg void OnBnClickedButtonSetOsdTxt();
	afx_msg void OnBnClickedButtonCleanUpOsdInfo();
	void    CloseWin();
	afx_msg void OnBnClickedButtonGetUrl();
	afx_msg void OnBnClickedButtonCloseUrl();
	afx_msg void OnBnClickedButtonCloseUrlByCamId();
private:
	int m_nBrightness;
	int m_nContrast;
	int m_nSaturation;
	int m_nHue;
	int m_nVolReal;
public:
	afx_msg void OnBnClickedButtonAdjustColor();
	afx_msg void OnBnClickedButtonStartAudio();
	afx_msg void OnBnClickedButtonCloseAudio();
	afx_msg void OnBnClickedButtonSetVolume();
	afx_msg void OnBnClickedButtonGetExternalUrl();
	afx_msg void OnBnClickedButtonGetVolume();
	afx_msg void OnBnClickedButtonGetColor();
	afx_msg void OnBnClickedButtonSetDrawfun();
	afx_msg void OnBnClickedButtonYuv();
	afx_msg void OnBnClickedButtonStopYuv();

	CString m_strYUVPath;
	bool m_bYUVCapture;
	afx_msg void OnBnClickedButtonYuvCapture();

	virtual IWidget* GetWidget() const;
	virtual CString GetTestUIName() const;
	virtual void ShowUI(BOOL bShow);

	afx_msg LRESULT OnModTransMsg(WPARAM wParam, LPARAM lParam);
	CButton m_CheckRule;
	CButton m_checkObj;
	CButton m_checkLocus;
	afx_msg void OnBnClickedCheckRule();
	afx_msg void OnBnClickedCheckObj();
	afx_msg void OnBnClickedCheckLocus();
	afx_msg void OnBnClickedButtonGetAudioChannels();
	afx_msg void OnBnClickedButtonOpenCloseAudioChannel();
	afx_msg void OnBnClickedButtonGetChannelState();
};
