// DlgPlayback.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgPlayback.h"
#include "DPSDK_Core_Error.h"
#include "resource.h"
// CDlgPlayback �Ի���

#define WM_DOWNLOAD_RECORD_COMPLETE		WM_USER + 1
#define WM_DOWNLOAD_RECORD_PROGRESS		WM_USER + 2

#define ID_TIMER_PLAY_POS				1
#define ID_INTERVAL_PLAY				3000
#define ID_TOTOL_SPLIT                  100

int _nDownloadSeq = -1;

IMPLEMENT_DYNAMIC(CDlgPlayback, CDialog)

CDlgPlayback::CDlgPlayback(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPlayback::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_PLAYBACK)
	, m_nDLLHandle(NULL)
	, m_nSeq(-1)
	, m_nBrightness(0)
	, m_nContrast(0)
	, m_nSaturation(0)
	, m_nHue(0)
	, m_nBeginTime(0)
	, m_nEndTime(0)
	, m_nTimeLen(0)
	, m_bLocal(0)
	, m_nTimePos(0)
	, m_bSetPos(true)
	, m_enPlaybackType(PLAYBACK_BY_FILE)
	, m_nVolPlayback(0)
{
	memset(nCameraId, 0, DPSDK_CORE_CHL_ID_LEN);
	szSource = DPSDK_CORE_PB_RECSOURCE_PLATFORM;
	FileIndex = 0;
}

CDlgPlayback::~CDlgPlayback()
{
	m_mapFileRecord.clear();
	m_mapTimeRecord.clear();

	std::deque<int> deqSeq;
	//m_mtxDownload.Lock();
	std::map<int, DownloadRecordInfo>::iterator itDownload = m_mapDownload.begin();
	while (itDownload != m_mapDownload.end())
	{
		deqSeq.push_back(itDownload->first);
		if (itDownload->second.fp != NULL)
		{
			fclose(itDownload->second.fp);
			itDownload->second.fp = NULL;
		}
		itDownload = m_mapDownload.erase(itDownload);

	}
	//m_mtxDownload.Unlock();
	while (!deqSeq.empty())
	{
		::DPSDK_CloseRecordStreamBySeq(m_nDLLHandle, deqSeq.front());
		deqSeq.pop_front();
	}
}

void CDlgPlayback::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgPlayback::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX,IDC_EDIT_BRIGHTNESS,m_nBrightness);
	DDX_Text(pDX,IDC_EDIT_CONTRAST,m_nContrast);
	DDX_Text(pDX,IDC_EDIT_SATURATION,m_nSaturation);
	DDX_Text(pDX,IDC_EDIT_HUE,m_nHue);
	DDV_MinMaxInt(pDX, m_nContrast, 0, 128);
	DDV_MinMaxInt(pDX, m_nBrightness, 0, 128);
	DDV_MinMaxInt(pDX, m_nSaturation, 0, 128);
	DDV_MinMaxInt(pDX, m_nHue, 0, 128);
	DDX_Control(pDX, IDC_SLIDER_PLAYBCK_POS, m_sliderPlaybackPos);
}

BEGIN_MESSAGE_MAP(CDlgPlayback, CDialog)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_QUERY_RECORD, &CDlgPlayback::OnBnClickedButtonQueryRecord)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_BY_FILE, &CDlgPlayback::OnBnClickedButtonPlaybackByFile)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_BY_TIME, &CDlgPlayback::OnBnClickedButtonPlaybackByTime)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE_PLAYBACK, &CDlgPlayback::OnBnClickedButtonPausePlayback)
	ON_BN_CLICKED(IDC_BUTTON_RESUME_PLAYBACK, &CDlgPlayback::OnBnClickedButtonResumePlayback)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_PLAYBACK, &CDlgPlayback::OnBnClickedButtonClosePlayback)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_CAMERA, &CDlgPlayback::OnBnClickedButtonCloseCamera)
	ON_CBN_SELCHANGE(IDC_COMBO_SEL_SPEED, &CDlgPlayback::OnCbnSelchangeComboSelSpeed)
	ON_BN_CLICKED(IDC_BUTTON_CAPTURE, &CDlgPlayback::OnBnClickedButtonCapture)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_BY_FILE, &CDlgPlayback::OnBnClickedButtonLoadByFile)
	ON_BN_CLICKED(IDC_BUTTON_STOP_LOAD, &CDlgPlayback::OnBnClickedButtonStopLoad)
	ON_MESSAGE(WM_DOWNLOAD_RECORD_PROGRESS, HandleDownloadRecordProgress)
	ON_MESSAGE(WM_DOWNLOAD_RECORD_COMPLETE, HandleDownloadRecordComplete)
	ON_BN_CLICKED(IDC_BUTTON_LOAD_BY_TIME, &CDlgPlayback::OnBnClickedButtonLoadByTime)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE_LOAD, &CDlgPlayback::OnBnClickedButtonPauseLoad)
	ON_BN_CLICKED(IDC_BUTTON_RESUME_LOAD, &CDlgPlayback::OnBnClickedButtonResumeLoad)
	ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_LOCAL, &CDlgPlayback::OnBnClickedButtonPlaybackLocal)
	ON_BN_CLICKED(IDC_BUTTON_GET_FRAME_TIME, &CDlgPlayback::OnBnClickedButtonGetFrameTime)
	ON_BN_CLICKED(IDC_BUTTON_ADJUST_COLOR, &CDlgPlayback::OnBnClickedButtonAdjustColor)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_AUDIO, &CDlgPlayback::OnBnClickedButtonOpenAudio)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_AUDIO, &CDlgPlayback::OnBnClickedButtonCloseAudio)
// 	ON_BN_CLICKED(IDC_BUTTON_PLAY_ONEBYONE, &CDlgPlayback::OnBnClickedButtonPlayOnebyone)
// 	ON_BN_CLICKED(IDC_BUTTON_PLAY_ONEBYONE_BACK, &CDlgPlayback::OnBnClickedButtonPlayOnebyoneBack)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_SET_VOLUME, &CDlgPlayback::OnBnClickedButtonSetVolume)
	ON_BN_CLICKED(IDC_BUTTON_GET_VOLUME, &CDlgPlayback::OnBnClickedButtonGetVolume)
	ON_BN_CLICKED(IDC_BUTTON_GET_COLOR, &CDlgPlayback::OnBnClickedButtonGetColor)
	ON_BN_CLICKED(IDC_BT_DOWNLOAD_MP4, &CDlgPlayback::OnBnClickedBtDownloadMp4)
//	ON_BN_CLICKED(IDC_BUTTON1, &CDlgPlayback::OnBnClickedButton1)
ON_BN_CLICKED(IDC_BUTTON_PLATFORM_RECORD_FOR_A_PERIOD, &CDlgPlayback::OnBnClickedButtonPlatformRecordForAPeriod)
ON_BN_CLICKED(IDC_BUTTON_STOP_PLATFORM_RECORD, &CDlgPlayback::OnBnClickedButtonStopPlatformRecord)
ON_BN_CLICKED(IDC_BUTTON_START_PLAYBACK_RECORD, &CDlgPlayback::OnBnClickedButtonStartPlaybackRecord)
ON_BN_CLICKED(IDC_BUTTON_STOP_PLAYBACK_RECORD, &CDlgPlayback::OnBnClickedButtonStopPlaybackRecord)
ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_ONEBYONE, &CDlgPlayback::OnBnClickedButtonPlaybackOnebyone)
ON_BN_CLICKED(IDC_BUTTON_PLAYBACK_NORMOL, &CDlgPlayback::OnBnClickedButtonPlaybackNormol)
END_MESSAGE_MAP()

// CDlgPlayback ��Ϣ��������
BOOL CDlgPlayback::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO1));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO2));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED));

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	::ShowWndPlayer(this, m_dlgWndPlayer);
	InitializeCriticalSection(&m_cs);
	
	//GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1000002$1$0$0"));
	((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->SetCurSel(3);

	SYSTEMTIME st;
	GetLocalTime(&st);
	CTime tm1(st.wYear, st.wMonth, st.wDay, 0, 0, 0);
	CTime tm2(st.wYear, st.wMonth, st.wDay, 23, 59, 59);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->SetTime(&tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->SetTime(&tm2);

	m_list.SetExtendedStyle(m_list.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_list.InsertColumn(1, _CS(_T("No.")), LVCFMT_CENTER, 50);
	m_list.InsertColumn(2, _CS(_T("Start time")), LVCFMT_CENTER, 130);
	m_list.InsertColumn(3, _CS(_T("End time")), LVCFMT_CENTER, 130);
	m_list.InsertColumn(4, _CS(_T("File index")), LVCFMT_CENTER, 80);
	m_list.InsertColumn(5, _CS(_T("File size (KB)")), LVCFMT_CENTER, 100);
	m_list.InsertColumn(6, _CS(_T("Source")), LVCFMT_CENTER, 80);
	m_list.InsertColumn(7, _CS(_T("Type")), LVCFMT_CENTER, 80);

	GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1001615$1$0$0"));
	::DPSDK_SetMediaDataCompleteCallback(m_nDLLHandle, CDlgPlayback::MediaDataComplete, this);

	m_nBrightness = 64;
	m_nContrast = 64;
	m_nSaturation = 64;
	m_nHue = 64;
	m_nPos = 0;

	m_sliderPlaybackPos.SetClickCallBack(SetPlayPosCallback,this,0);
	m_sliderPlaybackPos.SetRange(0,ID_TOTOL_SPLIT);
	m_sliderPlaybackPos.SetTicFreq(1);
	m_sliderPlaybackPos.SetPos(0);

	GetDlgItem(IDC_EDIT_TIME_OUT)->SetWindowText(_T("10000"));
//	GetDlgItem(IDC_EDIT_PLATFORM_RECORD)->SetWindowText(_T("10000"));

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgPlayback::OnClose()
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CloseRecordStreamBySeq();

	CDialog::OnClose();
}

void CDlgPlayback::CloseWin()
{
   OnClose();
}

void CDlgPlayback::OnBnClickedButtonQueryRecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_list.DeleteAllItems();
	m_mapFileRecord.clear();

	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	int nRecSource = _ttoi(strRecSource.GetString());

	CString strRecType;
	GetDlgItem(IDC_COMBO2)->GetWindowText(strRecType);
	int nRecType = _ttoi(strRecType.GetString());

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());

	Query_Record_Info_t stuQueryInfo = {0};
	strcpy_s(stuQueryInfo.szCameraId, sizeof(stuQueryInfo.szCameraId), szCameraId.c_str());
	stuQueryInfo.nSource = (dpsdk_recsource_type_e)nRecSource;
	stuQueryInfo.nRecordType = (dpsdk_record_type_e)nRecType;
	stuQueryInfo.uBeginTime = tmStart.GetTime();
	stuQueryInfo.uEndTime = tmEnd.GetTime();

	int nRecordCount = 0;
	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryRecord(m_nDLLHandle, &stuQueryInfo, nRecordCount), _CS(_T("Search record quantity")));
	if (nRet != DPSDK_RET_SUCCESS)
		return;

	if (nRecordCount > 0)
	{
		Record_Info_t stuRecordInfo = {0};
		strcpy_s(stuRecordInfo.szCameraId, sizeof(stuRecordInfo.szCameraId), szCameraId.c_str());
		stuRecordInfo.nBegin = 0;
		stuRecordInfo.nCount = nRecordCount;
		stuRecordInfo.pSingleRecord = new Single_Record_Info_t[stuRecordInfo.nCount];
		nRet = ::ShowCallRetInfo(this, DPSDK_GetRecordInfo(m_nDLLHandle, &stuRecordInfo), _CS(_T("Search record info")));
		if (nRet == DPSDK_RET_SUCCESS)
		{
			InsertRecordItem(stuRecordInfo.pSingleRecord, stuRecordInfo.nRetCount);
		}

		for (int i=0; i<(int)stuRecordInfo.nRetCount; i++)
		{
			Single_Record_Info_t& stuSingle = stuRecordInfo.pSingleRecord[i];
			RecordInfo info = {szCameraId.c_str(), stuSingle.nFileIndex, stuSingle.nSource, stuSingle.nRecordType, stuSingle.uBeginTime, stuSingle.uEndTime, stuSingle.uLength};

			m_mapFileRecord[stuSingle.nFileIndex] = info;
		}

		//int nBufferLen = 120 * (nRecordCount+1); // fixme:��Ź��õĳ���
		//char* pszBuffer = new char[nBufferLen];
		//memset(pszBuffer, 0, sizeof(char)*nBufferLen);
		//PacketRecordInfo(&stuRecordInfo, pszBuffer, nBufferLen);

		delete[] stuRecordInfo.pSingleRecord;

	}

}

void CDlgPlayback::OnBnClickedButtonPlaybackByFile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CloseRecordStreamBySeq();
	((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->SetCurSel(3);

	POSITION pos = m_list.GetFirstSelectedItemPosition();
	if (pos != NULL) 
	{
		int nItem = m_list.GetNextSelectedItem(pos);

		Get_RecordStream_File_Info_t stuFileInfo = {0};

		CString strCameraId;
		GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
		CWideToUtf8 szCameraId(strCameraId.GetString());
		strcpy_s(stuFileInfo.szCameraId, sizeof(stuFileInfo.szCameraId), szCameraId.c_str());
		strcpy_s(nCameraId, sizeof(nCameraId), szCameraId.c_str());

		CString strTimeout;
		GetDlgItem(IDC_EDIT_TIME_OUT)->GetWindowText(strTimeout);
		CWideToUtf8 szTimeout(strTimeout.GetString());
		int nTimeout = atoi(szTimeout.c_str());

		stuFileInfo.nMode = DPSDK_CORE_PB_MODE_NORMAL;

		CString strFileIndex = m_list.GetItemText(nItem, 3);
		stuFileInfo.nFileIndex = _ttoi(strFileIndex.GetString());
		FileIndex = stuFileInfo.nFileIndex;

		CString strBeginTime = m_list.GetItemText(nItem, 1);
		COleDateTime dtBeginTime;
		dtBeginTime.ParseDateTime(strBeginTime);
		SYSTEMTIME stBeginTime;
		dtBeginTime.GetAsSystemTime(stBeginTime);
		CTime beginTime(stBeginTime);

		stuFileInfo.uBeginTime = beginTime.GetTime();

		CString strEndTime = m_list.GetItemText(nItem, 2);
		COleDateTime dtEndTime;
		dtEndTime.ParseDateTime(strEndTime);
		SYSTEMTIME stEndTime;
		dtEndTime.GetAsSystemTime(stEndTime);
		CTime endTime(stEndTime);

		CString strRecSource;
		GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
		szSource = dpsdk_recsource_type_e(_ttoi(strRecSource.GetString()));
		

		stuFileInfo.uEndTime = endTime.GetTime();

		m_enPlaybackType = PLAYBACK_BY_FILE;

#ifdef USING_DPSDK_EXT
		int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &stuFileInfo, nTimeout), _CS(_T("Playback by file")));
		if(0 == nRet)
		{
			m_nBeginTime = stuFileInfo.uBeginTime;
			m_nEndTime = stuFileInfo.uEndTime;
			SetTimer(ID_TIMER_PLAY_POS, ID_INTERVAL_PLAY, NULL);
		}
#else
		/*CString ss;
		ss.Format(_T("t1 = %d\n"), GetTickCount());
		OutputDebugString(ss);*/
		int nRet = ::ShowCallRetInfo(this, DPSDK_GetRecordStreamByFile(m_nDLLHandle, m_nSeq, &stuFileInfo, m_dlgWndPlayer.GetMediaDataCallbackFunc(), &m_dlgWndPlayer), _T("Playback by file"));
		if (nRet == DPSDK_RET_SUCCESS)
		{
			m_dlgWndPlayer.OpenStream(m_nSeq);
		}
#endif
	}
}

void CDlgPlayback::OnBnClickedButtonPlaybackByTime()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CloseRecordStreamBySeq();
	((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->SetCurSel(3);

	Get_RecordStream_Time_Info_t stuTimeInfo = {0};

	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());
	strcpy_s(stuTimeInfo.szCameraId, sizeof(stuTimeInfo.szCameraId), szCameraId.c_str());
	strcpy_s(nCameraId, sizeof(nCameraId), szCameraId.c_str());

	CString strTimeout;
	GetDlgItem(IDC_EDIT_TIME_OUT)->GetWindowText(strTimeout);
	CWideToUtf8 szTimeout(strTimeout.GetString());
    int nTimeout = atoi(szTimeout.c_str());

	stuTimeInfo.nMode = DPSDK_CORE_PB_MODE_NORMAL;

	CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	stuTimeInfo.nSource = dpsdk_recsource_type_e(_ttoi(strRecSource.GetString()));
	szSource = stuTimeInfo.nSource;

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());
	stuTimeInfo.uBeginTime = tmStart.GetTime();
	stuTimeInfo.uEndTime = tmEnd.GetTime();

	m_enPlaybackType = PLAYBACK_BY_TIME;

#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &stuTimeInfo, nTimeout), _CS(_T("Playback by time")));
	if(0 == nRet)
	{
		m_nBeginTime = stuTimeInfo.uBeginTime;
		m_nEndTime = stuTimeInfo.uEndTime;

		SetTimer(ID_TIMER_PLAY_POS, ID_INTERVAL_PLAY, NULL);
	}
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_GetRecordStreamByTime(m_nDLLHandle, m_nSeq, &stuTimeInfo, m_dlgWndPlayer.GetMediaDataCallbackFunc(), &m_dlgWndPlayer), _T("Playback by time"));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.OpenStream(m_nSeq);
	}
#endif
	
}

void CDlgPlayback::OnBnClickedButtonPlaybackLocal()
{
	CFileDialog dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Record Files (*.dav)|*.dav|"));
	if (dlg.DoModal() == IDOK)
	{
		CWideToMulti _szFileName(dlg.GetPathName());

		int cRet = m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq);
	
		Get_Record_Local_Info_t stuLocolInfo = {0};
		strcpy_s(stuLocolInfo.szFilePath,sizeof(stuLocolInfo.szFilePath),_szFileName.c_str());
		//strncpy(stuLocolInfo.szFilePath, _szFileName.c_str(), 1024);

#ifdef USING_DPSDK_EXT
		int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &stuLocolInfo), _CS(_T("Playback by local playback")));
		
		if (nRet == DPSDK_RET_SUCCESS)
		{
			m_bLocal = 1;
			SetTimer(ID_TIMER_PLAY_POS, ID_INTERVAL_PLAY, NULL);
		}
#else
		int nRet = ::ShowCallRetInfo(this, DPSDK_GetRecordStreamByTime(m_nDLLHandle, m_nSeq, &stuLocolInfo, m_dlgWndPlayer.GetMediaDataCallbackFunc(), &m_dlgWndPlayer), _T("Playback by time"));
		if (nRet == DPSDK_RET_SUCCESS)
		{
			m_dlgWndPlayer.OpenStream(m_nSeq);
		}
#endif
	}
}


void CDlgPlayback::OnBnClickedButtonPausePlayback()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.PauseVideo(m_nDLLHandle, m_nSeq), _CS(_T("Pause playback")));
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_PauseRecordStreamBySeq(m_nDLLHandle, m_nSeq), _CS(_T("Pause playback")));
#endif
}

void CDlgPlayback::OnBnClickedButtonResumePlayback()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.ResumeVideo(m_nDLLHandle, m_nSeq), _CS(_T("Continue playback")));
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_ResumeRecordStreamBySeq(m_nDLLHandle, m_nSeq), _CS(_T("Continue playback")));
#endif
}

void CDlgPlayback::OnBnClickedButtonClosePlayback()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq), _CS(_T("Close playback")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_nSeq = -1;

		KillTimer(ID_TIMER_PLAY_POS);
	}
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_CloseRecordStreamBySeq(m_nDLLHandle, m_nSeq), _CS(_T("Close playback")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif
}

void CDlgPlayback::OnBnClickedButtonCloseCamera()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.CloseRecordStreamByCameraId(m_nDLLHandle, szCameraId.c_str()), _CS(_T("Close CAM playback")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_nSeq = -1;
	}
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_CloseRecordStreamByCameraId(m_nDLLHandle, szCameraId.c_str()), _CS(_T("Close CAM playback")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif
}

void CDlgPlayback::OnCbnSelchangeComboSelSpeed()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nIndex = ((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->GetCurSel();
	CString strSpeed;
	((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->GetLBText(nIndex, strSpeed);
	int nSpeed = _ttoi(strSpeed.GetString());

#ifdef USING_DPSDK_EXT
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.SetVideoSpeed(m_nDLLHandle, m_nSeq, (dpsdk_playback_speed_e)nSpeed), _CS(_T("Adjust playback speed")));
#else
	int nRet = ::ShowCallRetInfo(this, DPSDK_SetRecordStreamSpeed(m_nDLLHandle, m_nSeq, (dpsdk_playback_speed_e)nSpeed), _CS(_T("Adjust playback speed")));
#endif
}

void CDlgPlayback::InsertRecordItem(Single_Record_Info_t* pRecordInfo, int nCount)
{
	for (int i=0; i<nCount; i++)
	{
		int nSeq = m_list.GetItemCount();
		CString strSeq;
		strSeq.Format(_T("%d"), nSeq+1);
		m_list.InsertItem(nSeq, strSeq); // ���

		CTime tmBegin(pRecordInfo[i].uBeginTime);
		CString strBeginTime = tmBegin.Format(_T("%Y-%m-%d %H:%M:%S"));
		m_list.SetItemText(nSeq, 1, strBeginTime);// ��ʼʱ��

		CTime tmEnd(pRecordInfo[i].uEndTime);
		CString strEndTime = tmEnd.Format(_T("%Y-%m-%d %H:%M:%S"));
		m_list.SetItemText(nSeq, 2, strEndTime); // ����ʱ��

		CString strFileIndex;
		strFileIndex.Format(_T("%d"), pRecordInfo[i].nFileIndex);
		m_list.SetItemText(nSeq, 3, strFileIndex); // �ļ�����

		CString strSize;
		strSize.Format(_T("%lld"), pRecordInfo[i].uLength);
		m_list.SetItemText(nSeq, 4, strSize); // �ļ���С

		CString strSource = pRecordInfo[i].nSource == DPSDK_CORE_PB_RECSOURCE_DEVICE ? _CS(_T("Device")) : _CS(_T("Platform"));
		m_list.SetItemText(nSeq, 5, strSource); // ��Դ

		CString strType;
		switch (pRecordInfo[i].nRecordType)
		{
		case DPSDK_CORE_PB_RECORD_MANUAL:
			strType = _CS(_T("Manual record"));
			break;
		case DPSDK_CORE_PB_RECORD_ALARM:
		case CENTER_DISK_FULL:
		case CENTER_DISK_FAULT:
			strType = _CS(_T("Alarm record"));
			break;
		case DPSDK_CORE_PB_RECORD_MOTION_DETECT:
			strType = _CS(_T("Motion detection"));
			break;
		case DPSDK_CORE_PB_RECORD_VIDEO_LOST:
			strType = _CS(_T("Video loss"));
			break;
		case DPSDK_CORE_PB_RECORD_VIDEO_SHELTER:
			strType = _CS(_T("Tampering"));
			break;
		case DPSDK_CORE_PB_RECORD_TIMER:
			strType = _CS(_T("Scheduled record"));
			break;
		case DPSDK_CORE_PB_RECORD_ALL_DAY:
			strType = _CS(_T("All-day record"));
			break;
		default:
			strType.Format(_T("%d"), pRecordInfo[i].nRecordType);
		}
		m_list.SetItemText(nSeq, 6, strType); // ����
	}
}

void CDlgPlayback::CloseRecordStreamBySeq(void)
{
#ifdef USING_DPSDK_EXT
	if (m_nSeq >= 0)
	{
		m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq);
		m_nSeq = -1;
	}
#else
	if (m_nSeq >= 0)
	{
		DPSDK_CloseRecordStreamBySeq(m_nDLLHandle, m_nSeq);
		m_dlgWndPlayer.CloseStream(m_nSeq);
		m_nSeq = -1;
	}
#endif
}

void CDlgPlayback::OnBnClickedButtonCapture()
{	
	CFileDialog dlg(FALSE, _T(".jpg"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("JPEG Files (*.jpg)|*.jpg|BMP Files (*.bmp)|*.bmp|"));
	if (dlg.DoModal() == IDOK)
	{
		CString strExtName = dlg.GetFileExt();
		dpsdk_pic_type_e nType = strExtName == _T("bmp") ? DPSDK_CORE_PIC_FORMAT_BMP : DPSDK_CORE_PIC_FORMAT_JPEG;

		CString strPathName = dlg.GetPathName();
		CWideToMulti szPathName(strPathName.GetString());

		::ShowCallRetInfo(this, m_dlgWndPlayer.Capture(m_nDLLHandle, m_nSeq, nType, szPathName.c_str()), _CS(_T("Snapshot")));
	}
}

int CDlgPlayback::DoMediaDataCallback(int nSeq, const char* szData, int nLen)
{
    EnterCriticalSection(&m_cs);//20807
	std::map<int, DownloadRecordInfo>::iterator iter = m_mapDownload.find(nSeq);
	if (iter != m_mapDownload.end())
	{
		if (nLen == 0)
		{
			PostMessage(WM_DOWNLOAD_RECORD_COMPLETE, nSeq, 0);
		}
		else if (iter->second.fp != NULL)
		{
			fwrite(szData, sizeof(char), nLen, iter->second.fp);

			iter->second.nDownLength += (int)nLen;

			int nPos = ((float)iter->second.nDownLength)/((float)iter->second.nFileLength )* 100;

			if (nPos >= 100)
			{
				nPos =100;
			}

			if (nPos > iter->second.nPos)
			{
				iter->second.nPos = nPos;
				PostMessage(WM_DOWNLOAD_RECORD_PROGRESS, nSeq, nPos);	
			}
		}
	}
    LeaveCriticalSection(&m_cs);
	return 0;
}

int32_t DPSDK_CALLTYPE CDlgPlayback::MediaDataCallback(int nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, char* szData, int32_t nDataLen, void* pUserParam)
{
	CDlgPlayback* pCtrl = (CDlgPlayback*)pUserParam;
	pCtrl->DoMediaDataCallback(nSeq, szData, nDataLen);

	return 0;
}

LRESULT CDlgPlayback::HandleDownloadRecordComplete(WPARAM wParam, LPARAM lParam)
{
	bool bComplete = true;
	int nSeq = (int)wParam;

	EnterCriticalSection(&m_cs);
	std::map<int, DownloadRecordInfo>::iterator itDownload = m_mapDownload.find(nSeq);
	if (itDownload == m_mapDownload.end())
	{
		LeaveCriticalSection(&m_cs);
		return -1;
	}
	DownloadRecordInfo infoDownload = itDownload->second;
    LeaveCriticalSection(&m_cs);
	// �����������ܵ��ùرսӿڣ����������
	::DPSDK_CloseRecordStreamBySeq(m_nDLLHandle, nSeq);

	if (infoDownload.bPlatformByTime)
	{
		std::map<int, std::deque<RecordInfo>>::iterator itRecord = m_mapTimeRecord.find(nSeq);
		if (itRecord != m_mapTimeRecord.end() && !itRecord->second.empty())
		{
			std::string _szCameraId = infoDownload.strCameraId;
			std::string _szFileName = infoDownload.strFileName;
			Get_RecordStream_File_Info_t stuInfo = {0};
			strcpy_s(stuInfo.szCameraId, sizeof(stuInfo.szCameraId), _szCameraId.c_str());
			stuInfo.nMode = DPSDK_CORE_PB_MODE_DOWNLOAD;
			stuInfo.nFileIndex = ((RecordInfo)itRecord->second.front()).nFileIndex;

			int nSeq = -1;
			int iRet = m_dlgWndPlayer.GetRecordStreamByFile(m_nDLLHandle, nSeq, &stuInfo, CDlgPlayback::MediaDataCallback, this);
			if (iRet == DPSDK_RET_SUCCESS)
			{
				bComplete = false;
				itRecord->second.pop_front();
				m_mapTimeRecord[nSeq] = itRecord->second;
				m_mapTimeRecord.erase(itRecord);
				DownloadRecordInfo info /*= {_szCameraId.c_str(), _szFileName.c_str(), infoDownload.fp, infoDownload.nFileLength, infoDownload.nDownLength, true}*/;
				info.strCameraId = _szCameraId;
				info.strFileName = _szFileName;
				info.fp = infoDownload.fp;
				info.nFileLength = infoDownload.nFileLength;
				info.nDownLength = infoDownload.nDownLength;
				info.bPlatformByTime = true;
				info.nPos = 0;
				EnterCriticalSection(&m_cs);
				m_mapDownload[nSeq] = info;
				LeaveCriticalSection(&m_cs);
			}
		}
	}

	EnterCriticalSection(&m_cs);
	itDownload = m_mapDownload.find(nSeq);
	if (itDownload == m_mapDownload.end() )
	{
		LeaveCriticalSection(&m_cs);
		return -1;
	}
	if (bComplete && itDownload->second.fp != NULL)
	{
		fclose(itDownload->second.fp);
		itDownload->second.fp = NULL;
	}
	CString strFileName(CMultiToWide(itDownload->second.strFileName.c_str()).wc_str());
	m_mapDownload.erase(itDownload);
	LeaveCriticalSection(&m_cs);

	if (bComplete)
	{
		//OnDownloadRecordComplete(strFileName);
		int nPos  = 100;
		CString strInfo;
		strInfo.Format(_CS(_T("Download speed: %d")), nPos);
		GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText(strInfo);
	}

	return 0;
}

LRESULT CDlgPlayback::HandleDownloadRecordProgress(WPARAM wParam, LPARAM lParam)
{
	int nPos  = (int)lParam;
	CString strInfo;
	strInfo.Format(_CS(_T("Download speed: %d")), nPos);

	GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText(strInfo);

	return 0;
}

int32_t DPSDK_CALLTYPE fnDownloadFinishedCallback( IN int32_t nPDLLHandle,
													IN int32_t nDownloadSeq,
													IN void *pUserParam)
{
	char szFileName[1024] = {0};
	::DPSDK_GetFileNameFormDownloadInfoBySeq(nPDLLHandle, nDownloadSeq, szFileName, 1024);
	CString strFileName(CMultiToWide(szFileName).wc_str());
	
	CString strInfo;
	strInfo.Format(_CS(_T("%s Download complete!")), strFileName);

	AfxMessageBox(strInfo);
	return 1;
}

int32_t DPSDK_CALLTYPE fnDownloadProgressCallback( IN int32_t nPDLLHandle,
													IN int32_t nDownloadSeq,
													IN int32_t nPos,
													IN void *pUserParam)
{
	CDlgPlayback *pDlg = (CDlgPlayback*)pUserParam;

	pDlg->PostMessage(WM_DOWNLOAD_RECORD_PROGRESS, nDownloadSeq, nPos);

	return 0;
}

int32_t DPSDK_CALLTYPE fnDownloadNetErrorCallback( IN int32_t nPDLLHandle,
												  IN int32_t nDownloadSeq,
												  IN void *pUserParam)
{
	CString strInfo;
	strInfo.Format(_CS(_T("nDownloadSeq:%d Download Net Error!")), nDownloadSeq);

	AfxMessageBox(strInfo);

	return 0;
}

void CDlgPlayback::OnBnClickedButtonLoadByFile()
{
	POSITION pos = m_list.GetFirstSelectedItemPosition();
	if (pos == NULL)
	{
		MessageBox(_CS(_T("Please select one record")), _CS(_T("Record file")), MB_OK);
		return;
	}

	int nPos = 0;
	CString strInfo;
	strInfo.Format(_CS(_T("Download speed: %d")), nPos);
    GetDlgItem(IDC_STATIC_PROGRESS)->SetWindowText(strInfo);

	int nFileIndex = m_list.GetNextSelectedItem(pos);

	std::map<int, RecordInfo>::iterator itRecord = m_mapFileRecord.find(nFileIndex);
	if (itRecord == m_mapFileRecord.end())
	{
		return ;
	}

	CFileDialog dlg(FALSE, _T(".dav"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Record Files (*.dav)|*.dav|"));
	if (dlg.DoModal() == IDOK)
	{
		CWideToMulti _szFileName(dlg.GetPathName());
		FILE *fp = NULL;
		fopen_s(&fp, _szFileName.c_str(), "wb");
		if (fp == NULL)
		{	
			return ;
		}

		std::string _szCameraId(itRecord->second.strCameraId);
		Get_RecordStream_File_Info_t stuInfo = {0};
		strcpy_s( stuInfo.szCameraId, sizeof(stuInfo.szCameraId), _szCameraId.c_str() );
		stuInfo.nMode = DPSDK_CORE_PB_MODE_DOWNLOAD;
		stuInfo.nFileIndex = nFileIndex;

		int nSeq = -1;
		int iRet = m_dlgWndPlayer.GetRecordStreamByFile(m_nDLLHandle, nSeq, &stuInfo, CDlgPlayback::MediaDataCallback, this);
		GetDlgItem(IDC_EDIT_PATH)->SetWindowText(dlg.GetPathName());
		::ShowCallRetInfo(this,iRet, _CS(_T("Download by file")));
		if (iRet== DPSDK_RET_SUCCESS)
		{
			DownloadRecordInfo info /*= {_szCameraId.c_str(), _szFileName.c_str(), fp, itRecord->second.nFileLength*1024, 0, false}*/;
			info.strCameraId = _szCameraId.c_str();
			info.strFileName = _szFileName.c_str();
			info.fp = fp;
			info.nFileLength = itRecord->second.nFileLength*1024;
			info.bPlatformByTime = false;
			info.nPos = 0;
			EnterCriticalSection(&m_cs);
			m_mapDownload[nSeq] = info;
			LeaveCriticalSection(&m_cs);
		}
		else
		{
			fclose(fp);
			fp = NULL;
		}
	
	}	
}

void CDlgPlayback::OnBnClickedButtonStopLoad()
{
	CString strPath;
	GetDlgItem(IDC_EDIT_PATH)->GetWindowText(strPath);

	CWideToMulti _szFileName(strPath);
	int nSeq = -1;
	EnterCriticalSection(&m_cs);
	std::map<int, DownloadRecordInfo>::iterator itDownload = m_mapDownload.begin();
	for (; itDownload != m_mapDownload.end(); itDownload++)
	{
		if (!strcmp(itDownload->second.strFileName.c_str(), _szFileName.c_str()))
		{
			nSeq = itDownload->first;
			if (itDownload->second.fp != NULL)
			{
				fclose(itDownload->second.fp);
				itDownload->second.fp = NULL;
			}
			m_mapDownload.erase(itDownload);
			break;
		}
	}
	LeaveCriticalSection(&m_cs);

	// �����������ܵ��ùرսӿڣ����������
	if (nSeq >= 0)
	{
		int iRet = m_dlgWndPlayer.StopPlayBackLoad(m_nDLLHandle, nSeq);
		::ShowCallRetInfo(this,iRet, _CS(_T("Stop downloading")));
		std::map<int, std::deque<RecordInfo>>::iterator itRecord = m_mapTimeRecord.find(nSeq);
		if (itRecord != m_mapTimeRecord.end())
		{
			m_mapTimeRecord.erase(itRecord);
		}
	}


}

void CDlgPlayback::OnBnClickedButtonPauseLoad()
{
	CString strPath;
	GetDlgItem(IDC_EDIT_PATH)->GetWindowText(strPath);
	
	CWideToMulti _szFileName(strPath);
	int nSeq = -1;

	EnterCriticalSection(&m_cs);
	std::map<int, DownloadRecordInfo>::iterator itDownload = m_mapDownload.begin();
	for (; itDownload != m_mapDownload.end(); itDownload++)
	{
		if (strcmp(itDownload->second.strFileName.c_str(), _szFileName.c_str()) == 0)
		{
			nSeq = itDownload->first;
			break;
		}
	}
	LeaveCriticalSection(&m_cs);

	if (nSeq >= 0)
	{
		int iRet = m_dlgWndPlayer.PauseRecordStreamBySeq(m_nDLLHandle, nSeq);
		::ShowCallRetInfo(this,iRet, _CS(_T("Pause downloading")));
	}

}

void CDlgPlayback::OnBnClickedButtonResumeLoad()
{
	CString strPath;
	GetDlgItem(IDC_EDIT_PATH)->GetWindowText(strPath);

	CWideToMulti _szFileName(strPath);
	int nSeq = -1;

    EnterCriticalSection(&m_cs);
	std::map<int, DownloadRecordInfo>::iterator itDownload = m_mapDownload.begin();
	for (; itDownload != m_mapDownload.end(); itDownload++)
	{
		if (strcmp(itDownload->second.strFileName.c_str(), _szFileName.c_str()) == 0)
		{
			nSeq = itDownload->first;
			break;
		}
	}
	LeaveCriticalSection(&m_cs);
	if (nSeq >= 0)
	{
		int iRet = m_dlgWndPlayer.ResumePlaybackBySeq(m_nDLLHandle, nSeq);
		::ShowCallRetInfo(this,iRet, _CS(_T("Continue downloading")));
	}

}


void CDlgPlayback::OnBnClickedButtonLoadByTime()
{
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);

	CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	int nRecSource = _ttoi(strRecSource.GetString());

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());

	CFileDialog dlg(FALSE, _T(".dav"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("Record Files (*.dav)|*.dav|"));
	if (dlg.DoModal() == IDOK)
	{
		std::deque<RecordInfo> deqInfo;
		ULONGLONG nTotalLength = QueryDownloadRecord(strCameraId, nRecSource, tmStart.GetTime(), tmEnd.GetTime(), deqInfo);
		if (nTotalLength == 0)
		{
			return ;
		}

		CWideToMulti _szFileName(dlg.GetPathName());
		/*FILE *fp = NULL;
		fopen_s(&fp, _szFileName.c_str(), "wb");
		if (fp == NULL)
		{
			return ;
		}*/

		int m_nLastError = 0;
		CWideToUtf8 _szCameraId(strCameraId);
		
		Get_RecordStream_Time_Info_t stuInfo = {0};
		strcpy_s(stuInfo.szCameraId, sizeof(stuInfo.szCameraId), _szCameraId.c_str());
		stuInfo.nMode = DPSDK_CORE_PB_MODE_DOWNLOAD;
		stuInfo.nSource = dpsdk_recsource_type_e(nRecSource);
		stuInfo.uBeginTime = tmStart.GetTime();
		stuInfo.uEndTime = tmEnd.GetTime();

		int nSeq = -1;
	/*	m_nLastError = m_dlgWndPlayer.GetRecordStreamByTime(m_nDLLHandle, nSeq, &stuInfo, CDlgPlayback::MediaDataCallback, this);
		GetDlgItem(IDC_EDIT_PATH)->SetWindowText(dlg.GetPathName());
		::ShowCallRetInfo(this,m_nLastError, _CS(_T("Download by time")));
		if (m_nLastError == DPSDK_RET_SUCCESS)
		{
			DownloadRecordInfo info;
			info.strCameraId = _szCameraId.c_str();
			info.strFileName = _szFileName.c_str();
			info.fp = fp;
			info.nFileLength = nTotalLength;
			info.bPlatformByTime = false;
			EnterCriticalSection(&m_cs);
			m_mapDownload[nSeq] = info;
			LeaveCriticalSection(&m_cs);
		}
	

		if (m_nLastError != DPSDK_RET_SUCCESS)
		{
			fclose(fp);
			fp = NULL;
		}*/
		DPSDK_SetDownloadFinishedCallback(m_nDLLHandle, fnDownloadFinishedCallback, this);
		DPSDK_SetDownloadProgressCallback(m_nDLLHandle, fnDownloadProgressCallback, this);
		DPSDK_SetDownloadNetErrorCallback(m_nDLLHandle, fnDownloadNetErrorCallback, this);

		m_nLastError = DPSDK_DownloadRecordByTime(m_nDLLHandle, nSeq, _szCameraId.c_str(), dpsdk_recsource_type_e(nRecSource), tmStart.GetTime(), tmEnd.GetTime(), _szFileName.c_str());
		GetDlgItem(IDC_EDIT_PATH)->SetWindowText(dlg.GetPathName());
		::ShowCallRetInfo(this,m_nLastError, _CS(_T("Download by time")));
		if (m_nLastError == DPSDK_RET_SUCCESS)
		{
			DownloadRecordInfo info;
			info.strCameraId = _szCameraId.c_str();
			info.strFileName = _szFileName.c_str();
			//info.fp = fp;
			info.nFileLength = nTotalLength;
			info.bPlatformByTime = false;
			EnterCriticalSection(&m_cs);
			m_mapDownload[nSeq] = info;
			LeaveCriticalSection(&m_cs);
		}
		return ;

	}
}

ULONGLONG CDlgPlayback::QueryDownloadRecord(LPCTSTR szCameraId, LONG nSourceType, ULONGLONG nBeginTime, ULONGLONG nEndTime, std::deque<RecordInfo>& deqInfo)
{
	CWideToUtf8 _szCameraId(szCameraId);
	Query_Record_Info_t stuInfo = {0};
	strcpy_s(stuInfo.szCameraId, sizeof(stuInfo.szCameraId), _szCameraId.c_str());
	stuInfo.nSource = dpsdk_recsource_type_e(nSourceType);
	stuInfo.nRecordType = DPSDK_CORE_PB_RECORD_UNKONWN;
	stuInfo.uBeginTime = nBeginTime;
	stuInfo.uEndTime = nEndTime;

	Record_Info_t stuRecInfo = {0};
	strcpy_s(stuRecInfo.szCameraId, sizeof(stuRecInfo.szCameraId), _szCameraId.c_str());

	int nRecordCount = 0;
	int iRet = m_dlgWndPlayer.QueryRecord(m_nDLLHandle, &stuInfo, nRecordCount);

	int m_nLastError = 0;

	if (nRecordCount > 0)
	{
		stuRecInfo.nBegin = 0;
		stuRecInfo.nCount = nRecordCount;
		stuRecInfo.pSingleRecord = new Single_Record_Info_t[stuRecInfo.nCount];
		m_nLastError = ::DPSDK_GetRecordInfo(m_nDLLHandle, &stuRecInfo);
	}

	if (m_nLastError == DPSDK_RET_SUCCESS)
	{
		// ֻҪ���²�ѯ�ɹ�����Ҫ����ļ�¼���
		//m_mapFileRecord.clear(); lz
	}

	ULONGLONG nTotalLength = 0; 
	for (int i=0; i<(int)stuRecInfo.nRetCount; i++)
	{
		Single_Record_Info_t& stuSingle = stuRecInfo.pSingleRecord[i];
	
		if (nBeginTime <= stuSingle.uBeginTime && nEndTime >= stuSingle.uEndTime)
		{
			nTotalLength += stuSingle.uLength;
		}
		else if (nBeginTime <= stuSingle.uBeginTime && nEndTime > stuSingle.uBeginTime && nEndTime<= stuSingle.uEndTime)
		{
			nTotalLength += (nEndTime - stuSingle.uBeginTime) * stuSingle.uLength / (stuSingle.uEndTime - stuSingle.uBeginTime);
		}
		else if (nBeginTime >= stuSingle.uBeginTime && nBeginTime < stuSingle.uEndTime && nEndTime >= stuSingle.uEndTime)
		{
			nTotalLength += (stuSingle.uEndTime - nBeginTime) * stuSingle.uLength / (stuSingle.uEndTime - stuSingle.uBeginTime);
		}
		else if (nBeginTime >= stuSingle.uBeginTime && nEndTime<= stuSingle.uEndTime)
		{
			nTotalLength += (nEndTime - nBeginTime) * stuSingle.uLength / (stuSingle.uEndTime - stuSingle.uBeginTime);
		}

	}
	
	if(stuRecInfo.pSingleRecord)
	{
		delete [] stuRecInfo.pSingleRecord; 
		stuRecInfo.pSingleRecord = NULL; 
	} 

	return nTotalLength * 1024; // ת���ֽ���
}

void CDlgPlayback::OnBnClickedButtonGetFrameTime()
{
	uint64_t time = 0;
	int nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.GetFrameTime(m_nDLLHandle,m_nSeq,time), _CS(_T("Get current stream flow time")));
	

	CTime playbackTime(time); 
	CString strPlaybackTime; 
	strPlaybackTime.Format(_T("%4d-%2d-%2d %2d:%2d:%2d"),playbackTime.GetYear(),playbackTime.GetMonth(), 
	playbackTime.GetDay(),playbackTime.GetHour(),playbackTime.GetMinute(),playbackTime.GetSecond()); 

	MessageBox(strPlaybackTime);   
}

void CDlgPlayback::OnBnClickedButtonGetColor()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	Video_Color_Info_t videoColorInfo;

	::ShowCallRetInfo(this, m_dlgWndPlayer.GetColor(m_nDLLHandle, m_nSeq, videoColorInfo), _CS(_T("Get image property")));

	m_nBrightness = videoColorInfo.nBrightness;
	m_nContrast = videoColorInfo.nContrast;
	m_nHue = videoColorInfo.nHue;
	m_nSaturation = videoColorInfo.nSaturation;

	UpdateData(FALSE);
}

void CDlgPlayback::OnBnClickedButtonAdjustColor()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	UpdateData(TRUE);

	Video_Color_Info_t videoColorInfo;
	videoColorInfo.nBrightness = m_nBrightness;
	videoColorInfo.nContrast = m_nContrast;
	videoColorInfo.nHue = m_nHue;
	videoColorInfo.nSaturation = m_nSaturation;

	::ShowCallRetInfo(this, m_dlgWndPlayer.AdjustColor(m_nDLLHandle, m_nSeq, videoColorInfo), _CS(_T("Set image property")));
}

// void CDlgPlayback::OnBnClickedButtonPlayOnebyone()
// {
// 	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 
// 	::ShowCallRetInfo(this, m_dlgWndPlayer.PlayOneByOne(m_nDLLHandle, m_nSeq), _CS(_T("Single frame play")));
// }
// 
// void CDlgPlayback::OnBnClickedButtonPlayOnebyoneBack()
// {
// 	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 
// 	::ShowCallRetInfo(this, m_dlgWndPlayer.PlayOneByOneBack(m_nDLLHandle, m_nSeq), _CS(_T("Single frame backward")));
// }

void CDlgPlayback::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if(nIDEvent == ID_TIMER_PLAY_POS)
	{
//		KillTimer(ID_TIMER_PLAY_POS);
		uint64_t nCurTime = 0;
		m_dlgWndPlayer.GetFrameTime(m_nDLLHandle,m_nSeq,nCurTime);

	/*	if (m_nBeginTime == 0)
		{
            m_nBeginTime = nCurTime;
		}*/

		// �������ȣ�˵���Ѿ���λ�˻طš�
		if (m_nTimePos != m_nPos)
		{
			m_bSetPos = false;
		}
		else
		{
            m_bSetPos = true;
		}

		if(nCurTime < m_nBeginTime)
		{
			nCurTime = m_nBeginTime;
		}

		if (m_bLocal == 1)
		{
			m_dlgWndPlayer.GetPlayPos(m_nDLLHandle,m_nSeq,m_nTimePos);
		}
		else
		{
			m_nTimePos = ((nCurTime - m_nBeginTime)*ID_TOTOL_SPLIT)/(m_nEndTime - m_nBeginTime);
		}

		if (m_bSetPos)
		{
			m_nPos = m_nTimePos;
			m_sliderPlaybackPos.SetPos(m_nPos);
		}
		else
		{
            m_nTimePos = m_nPos;
		}
		
	}
	else
	{
		CDialog::OnTimer(nIDEvent);
	}
}

int32_t DPSDK_CALLTYPE CDlgPlayback::MediaDataComplete(int nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, void* pUserParam)
{
	CDlgPlayback* pDlgPlayback = (CDlgPlayback*)pUserParam;
	pDlgPlayback->m_sliderPlaybackPos.SetPos(ID_TOTOL_SPLIT);

	return 0;
}

void CDlgPlayback::SetPlayPosCallback(void* pUser,int nPos)
{
	CDlgPlayback* pThis = (CDlgPlayback*)pUser;

	pThis->SetPlaybackPos(nPos);
}

void CDlgPlayback::SetPlaybackPos(int nPos)
{
	if(PLAYBACK_BY_FILE == m_enPlaybackType)
	{
		uint64_t uBeginTime = m_nBeginTime + ((nPos*(m_nEndTime - m_nBeginTime))/ID_TOTOL_SPLIT);
		uint64_t uEndTime = m_nEndTime;

		//m_dlgWndPlayer.PauseVideo(m_nDLLHandle, m_nSeq);		
		if (m_bLocal)
		{
			::DPSDK_SeekLocalPlaybackBySeq(m_nDLLHandle, m_nSeq, nPos);
		}
		else
		{
			//m_dlgWndPlayer.SeekVideo(m_nDLLHandle, m_nSeq, uBeginTime, uEndTime);//�˷��������Բ�ǿ
			
			::DPSDK_StopPlaybackBySeq(m_nDLLHandle, m_nSeq); //����Ҫ�ر�֮ǰ��¼���豸¼��֧�ִ򿪶�·
			Get_RecordStream_Time_Info_t info;
			memset(&info, 0, sizeof(Get_RecordStream_Time_Info_t));
			strcpy_s(info.szCameraId, sizeof(info.szCameraId), nCameraId);
			info.nMode = DPSDK_CORE_PB_MODE_NORMAL;
			info.nRight = DPSDK_CORE_NOT_CHECK_RIGHT;
			info.nSource = szSource;
			info.uBeginTime = uBeginTime;
			info.uEndTime = uEndTime;
			int nRet = m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &info);	
		}

	    //::DPSDK_SeekRecordStreamBySeq(m_nDLLHandle, m_nSeq, uBeginTime, uEndTime);	
	}
	else
	{
		uint64_t uBeginTime = m_nBeginTime + ((nPos*(m_nEndTime - m_nBeginTime))/ID_TOTOL_SPLIT);
		uint64_t uEndTime = m_nEndTime;
		//::DPSDK_SeekRecordStreamBySeq(m_nDLLHandle, m_nSeq, uBeginTime, uEndTime);//�˷��������Բ�ǿ

		::DPSDK_StopPlaybackBySeq(m_nDLLHandle, m_nSeq); //����Ҫ�ر�֮ǰ��¼���豸¼��֧�ִ򿪶�·
		Get_RecordStream_Time_Info_t info;
		memset(&info, 0, sizeof(Get_RecordStream_Time_Info_t));
		strcpy_s(info.szCameraId, sizeof(info.szCameraId), nCameraId);
		info.nMode = DPSDK_CORE_PB_MODE_NORMAL;
		info.nRight = DPSDK_CORE_NOT_CHECK_RIGHT;
		info.nSource = szSource;
		info.uBeginTime = uBeginTime;
		info.uEndTime = uEndTime;
		int nRet = m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &info);
		
	}
	m_nPos = nPos;
	m_sliderPlaybackPos.SetPos(m_nPos);
}

void CDlgPlayback::OnBnClickedButtonOpenAudio()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	::ShowCallRetInfo(this, DPSDK_OpenAudio(m_nDLLHandle, m_nSeq,true), _CS(_T("Start audio")));
}

void CDlgPlayback::OnBnClickedButtonCloseAudio()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	::ShowCallRetInfo(this, DPSDK_OpenAudio(m_nDLLHandle, m_nSeq,false), _CS(_T("Close audio")));
}


void CDlgPlayback::OnBnClickedButtonSetVolume()
{
	CString strVolume;
	GetDlgItem(IDC_EDIT_SET_VOLUME)->GetWindowText(strVolume);
	int nVol = _tstoi(strVolume);

	::ShowCallRetInfo(this,DPSDK_SetVolume(m_nDLLHandle,m_nSeq,nVol),_CS(_T("Adjust volume")));
	int nRet = DPSDK_SetVolume(m_nDLLHandle,m_nSeq,nVol);
	if (nRet == 0)
	{
		m_nVolPlayback = nVol;//�ɹ�����0����ȥ����m_nVolPlayback
	}

}


void CDlgPlayback::OnBnClickedButtonGetVolume()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	int nVol;
	::ShowCallRetInfo(this,DPSDK_GetVolume(m_nDLLHandle,m_nSeq,nVol),_CS(_T("Adjust volume")));

	//if (nVol<64895)
	//{
	//	nVol += 1;
	//}
	if (m_nVolPlayback == 0)//�Ȼ�ȡ����
	{
		m_nVolPlayback = nVol;
	}	
	else if (m_nVolPlayback != 0)//�����������Ժ��ֻ�ȡ����
	{
		nVol = m_nVolPlayback;
	}


	CString strVolume;
	strVolume.Format(_T("%d"),nVol);
	GetDlgItem(IDC_EDIT_SET_VOLUME)->SetWindowText(strVolume);
}


void CDlgPlayback::OnBnClickedBtDownloadMp4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);

	CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	int nRecSource = _ttoi(strRecSource.GetString());

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());

	CFileDialog dlg(FALSE, _T(".dav"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("(*.mp4)|*.mp4|"));
	if (dlg.DoModal() == IDOK)
	{
		std::deque<RecordInfo> deqInfo;
		//ULONGLONG nTotalLength = QueryDownloadRecord(strCameraId, nRecSource, tmStart.GetTime(), tmEnd.GetTime(), deqInfo);
		// ����ƽ̨���ص�¼�񳤶�Ϊ0
		/*if (nTotalLength == 0)
		{
			return ;
		}*/

		CWideToMulti _szFileName(dlg.GetPathName());

		int m_nLastError = 0;
		CWideToUtf8 _szCameraId(strCameraId);
		

		Get_RecordStream_Time_Info_t stuInfo = {0};
		strncpy(stuInfo.szCameraId, _szCameraId.c_str(), sizeof(stuInfo.szCameraId));
		stuInfo.nMode = DPSDK_CORE_PB_MODE_DOWNLOAD;
		stuInfo.nSource = dpsdk_recsource_type_e(nRecSource);
		stuInfo.uBeginTime = tmStart.GetTime();
		stuInfo.uEndTime = tmEnd.GetTime();

#if 0
		FILE *fp = NULL;
		fopen_s(&fp, _szFileName.c_str(), "wb");
		if (fp == NULL)
		{
			return ;
		}

		int nSeq = -1;
		m_nLastError = m_dlgWndPlayer.GetRecordStreamByTime(m_nDLLHandle, nSeq, &stuInfo, CDlgPlayback::MediaDataCallback, this);
		::ShowCallRetInfo(this,m_nLastError, _CS(_T("Download by time")));
		if (m_nLastError == DPSDK_RET_SUCCESS)
		{
			DownloadRecordInfo info;
			info.strCameraId = _szCameraId.c_str();
			info.strFileName = _szFileName.c_str();
			info.fp = fp;
			info.nFileLength = nTotalLength;
			info.bPlatformByTime = false;
			EnterCriticalSection(&m_cs);
			m_mapDownload[nSeq] = info;
			LeaveCriticalSection(&m_cs);
		}
	

		if (m_nLastError != DPSDK_RET_SUCCESS)
		{
			fclose(fp);
			fp = NULL;
		}

		return ;
#else
		int nDownloadSeq = -1;
		DPSDK_SetDownloadFinishedCallback(m_nDLLHandle, fnDownloadFinishedCallback, this);
		DPSDK_SetDownloadProgressCallback(m_nDLLHandle, fnDownloadProgressCallback, this);

		//DPSDK_DownloadRecordByTime(m_nDLLHandle, nDownloadSeq, _szCameraId.c_str(), (dpsdk_recsource_type_e)3, tmStart.GetTime(), tmEnd.GetTime(), _szFileName.c_str(), 10*000);
		m_nLastError = DPSDK_DownloadRecordByTimeEx(m_nDLLHandle, nDownloadSeq, _szCameraId.c_str(), (dpsdk_recsource_type_e)nRecSource, tmStart.GetTime(), tmEnd.GetTime(), _szFileName.c_str(), 3 ,10*1000);
		GetDlgItem(IDC_EDIT_PATH)->SetWindowText(dlg.GetPathName());
		::ShowCallRetInfo(this,m_nLastError, _CS(_T("Download by time")));
		if (m_nLastError == DPSDK_RET_SUCCESS)
		{
			DownloadRecordInfo info;
			info.strCameraId = _szCameraId.c_str();
			info.strFileName = _szFileName.c_str();
			//info.fp = fp;
			//info.nFileLength = nTotalLength;
			info.bPlatformByTime = false;
			EnterCriticalSection(&m_cs);
			m_mapDownload[nDownloadSeq] = info;
			LeaveCriticalSection(&m_cs);
		}
		_nDownloadSeq = nDownloadSeq;
#endif

	}
}

void CDlgPlayback::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);

	CWideToMulti szCameraId(strCameraId.GetString());

	char* pCameraId = const_cast<char*>(szCameraId.c_str());
	char* pIndex = strrchr(pCameraId, '$');
	if(pIndex != NULL)
	{
		pIndex[1] = 0;
	}

	CloseRecordStreamBySeq();
	((CComboBox*)GetDlgItem(IDC_COMBO_SEL_SPEED))->SetCurSel(3);

	Get_RecordStream_Time_Info_t stuTimeInfo = {0};

	CString strTimeout;
	GetDlgItem(IDC_EDIT_TIME_OUT)->GetWindowText(strTimeout);
	CWideToUtf8 szTimeout(strTimeout.GetString());
	int nTimeout = atoi(szTimeout.c_str());

	stuTimeInfo.nMode = DPSDK_CORE_PB_MODE_NORMAL;

	CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	stuTimeInfo.nSource = dpsdk_recsource_type_e(_ttoi(strRecSource.GetString()));

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());
	stuTimeInfo.uBeginTime = tmStart.GetTime();
	stuTimeInfo.uEndTime = tmEnd.GetTime();

	m_enPlaybackType = PLAYBACK_BY_TIME;

	char szNew[64] = {0};
	for(int i=0;i<6;i++)
	{
		int nRet = m_dlgWndPlayer.CloseVideo(m_nDLLHandle, m_nSeq);
		if (nRet == DPSDK_RET_SUCCESS)
		{
			m_nSeq = -1;

			KillTimer(ID_TIMER_PLAY_POS);
		}
		sprintf(stuTimeInfo.szCameraId,"%s%d", pCameraId, i);
		
		nRet = ::ShowCallRetInfo(this, m_dlgWndPlayer.OpenVideo(m_nDLLHandle, m_nSeq, &stuTimeInfo, nTimeout), _CS(_T("Playback by time")));
		if(0 == nRet)
		{
			m_nBeginTime = stuTimeInfo.uBeginTime;
			m_nEndTime = stuTimeInfo.uEndTime;

			SetTimer(ID_TIMER_PLAY_POS, ID_INTERVAL_PLAY, NULL);
		}
	}
}

void CDlgPlayback::OnBnClickedButtonPlatformRecordForAPeriod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraID;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraID);

	CWideToMulti _szCameraID(strCameraID.GetString());
	

	::ShowCallRetInfo(this, DPSDK_StartPlatformReocrd(m_nDLLHandle, _szCameraID.c_str()), _CS(_T("Enable platform record")));
}

void CDlgPlayback::OnBnClickedButtonStopPlatformRecord()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraID;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraID);

	CWideToMulti _szCameraID(strCameraID.GetString());

	::ShowCallRetInfo(this, DPSDK_StopPlatformReocrd(m_nDLLHandle, _szCameraID.c_str()), _CS(_T("Stop platform record")));
}

void CDlgPlayback::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgPlayback::GetWidget() const
{
	return const_cast<CDlgPlayback*>(this);
}

CString CDlgPlayback::GetTestUIName() const
{
	return _T("Playback");
}

void CDlgPlayback::OnBnClickedButtonStartPlaybackRecord()
{
	::ShowCallRetInfo(this, DPSDK_StartRecord(m_nDLLHandle, m_nSeq, "D:\\playbackrecord.dav"), _CS(_T("Start PlayBack Record")));
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CDlgPlayback::OnBnClickedButtonStopPlaybackRecord()
{
	::ShowCallRetInfo(this, DPSDK_StopRecord(m_nDLLHandle, m_nSeq), _CS(_T("Stop PlayBack Record")));
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CDlgPlayback::OnBnClickedButtonPlaybackOnebyone()
{
	::ShowCallRetInfo(this, DPSDK_PlayOneByOne(m_nDLLHandle, m_nSeq), _CS(_T("��֡�ط�")));
}

void CDlgPlayback::OnBnClickedButtonPlaybackNormol()
{
	::ShowCallRetInfo(this, DPSDK_Play(m_nDLLHandle, m_nSeq), _CS(_T("��֡�ط�")));
}
