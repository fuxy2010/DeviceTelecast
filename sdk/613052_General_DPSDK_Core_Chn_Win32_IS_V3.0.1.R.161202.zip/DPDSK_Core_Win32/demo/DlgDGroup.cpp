// DlgDGroup.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "Test_DPSDK_CoreDlg.h"
#include "DlgDGroup.h"

#define SAFE_DELETE(obj)		if(obj){delete obj; obj = NULL;}
#define SAFE_M_DELETE(obj)		if(obj){delete []obj; obj = NULL;}


//#define SHOW_NEW_ORG_AND_DEV_VIEW
// CDlgDGroup �Ի���

IMPLEMENT_DYNAMIC(CDlgDGroup, CDialog)

CDlgDGroup::CDlgDGroup(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDGroup::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_DGROUP)
{

}

CDlgDGroup::~CDlgDGroup()
{
}

void CDlgDGroup::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TREE1, m_treeGroup);
}


BEGIN_MESSAGE_MAP(CDlgDGroup, CDialog)
	ON_NOTIFY(NM_DBLCLK, IDC_TREE1, &CDlgDGroup::OnNMDblclkTree1)
	ON_MESSAGE(WM_DEVICE_CHANGE, OnDeviceChangeCallback)
	ON_WM_SIZE()
END_MESSAGE_MAP()

LRESULT CDlgDGroup::OnDeviceChangeCallback( WPARAM wParam, LPARAM lParam )
{
	device_change_info_t* pChangeInfo = (device_change_info_t*)wParam;
	if (pChangeInfo == NULL)
	{
		return S_OK;
	}

	//	DPSDK_CORE_CHANGE_ADD_DEV					= 1,					 // �����豸			
	//	DPSDK_CORE_CHANGE_MODIFY_DEV				= 2,					 // �޸��豸
	//	DPSDK_CORE_CHANGE_DEL_DEV					= 3,					 // ɾ���豸
	//	DPSDK_CORE_CHANGE_ADD_ORG					= 4,					 // ������֯
	//	DPSDK_CORE_CHANGE_MODIFY_ORG				= 5,					 // �޸���֯ 
	//	DPSDK_CORE_CHANGE_DELETE_ORG				= 6,					 // ɾ����֯ 

	if (pChangeInfo->changeType == DPSDK_CORE_CHANGE_ADD_DEV 
		|| pChangeInfo->changeType == DPSDK_CORE_CHANGE_DEL_DEV)
	{
		// 
		CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(pChangeInfo->szDepCode);
		if (itfind == m_mapCodeItem.end())
		{
			return S_OK;
		}
		// ���»�ȡһ��
		RefreshItem(itfind->second);
	}
	else if (pChangeInfo->changeType == DPSDK_CORE_CHANGE_MODIFY_DEV)
	{
		// ȷ���Ӹ���ʼˢ
		std::string strtemp = strlen(pChangeInfo->szDepCode)>strlen(pChangeInfo->szNewDepCode)?pChangeInfo->szNewDepCode:pChangeInfo->szDepCode;

		CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(strtemp);
		if (itfind == m_mapCodeItem.end())
		{
			return S_OK;
		}
		RefreshItem(itfind->second);
		
		strtemp = strlen(pChangeInfo->szDepCode)>strlen(pChangeInfo->szNewDepCode)?pChangeInfo->szDepCode:pChangeInfo->szNewDepCode;


		itfind = m_mapCodeItem.find(strtemp);
		if (itfind == m_mapCodeItem.end())
		{
			return S_OK;
		}
		RefreshItem(itfind->second);
		// ���»�ȡ����
	}
	else if ( pChangeInfo->changeType == DPSDK_CORE_CHANGE_ADD_ORG ||
			  pChangeInfo->changeType == DPSDK_CORE_CHANGE_MODIFY_ORG ||
			  pChangeInfo->changeType == DPSDK_CORE_CHANGE_DELETE_ORG )
	{
		// �򵥵� ���»�ȡ���ڵ�
		std::string strtemp = pChangeInfo->szDepCode;
		
		if (strcmp(pChangeInfo->szDepCode, "001") == 0)
		{
			return S_OK; 
		}

		strtemp = strtemp.substr(0, strtemp.size() - 3);


		CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(strtemp);
		if (itfind == m_mapCodeItem.end())
		{
			return S_OK;
		}
		// ���»�ȡһ��
		RefreshItem(itfind->second);
	}


	return S_OK;

}

// CDlgDGroup ��Ϣ��������

BOOL CDlgDGroup::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);

	/*HTREEITEM hRootItem = m_treeGroup.InsertItem(_CS(_T("Root")));

	Item_Infor_t item;
	item.nType = 1;
	item.strCode = "001";
	
	m_mapTreeItem.insert(std::make_pair(hRootItem, item));
	m_mapCodeItem.insert(std::make_pair("001", hRootItem));*/   //whgTag

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgDGroup::CreateDSSTree(int nType)
{
	m_treeGroup.DeleteAllItems();
	
	//�߼���֯
	if(DPSDK_HasLogicOrg(m_nDLLHandle))
	{
		Dep_Info_Ex_t pDepInfoEx;
		memset(&pDepInfoEx, 0 , sizeof(pDepInfoEx));
		int nRet = DPSDK_GetLogicRootDepInfo(m_nDLLHandle, &pDepInfoEx);
		if(nRet == DPSDK_RET_SUCCESS)
		{
			Item_Infor_t item;
			item.nType = 1;
			item.strCode = pDepInfoEx.szCoding;
			HTREEITEM hRootItem = m_treeGroup.InsertItem(_CS(_T("Root")));
			CreateNodeDep(hRootItem, item.strCode.c_str(), nType);
			m_treeGroup.Expand(hRootItem, TVE_EXPAND);
		}
	}
	else
	{	//������֯
		Item_Infor_t item;
		item.nType = 1;
		item.strCode = "001";
		HTREEITEM hRootItem = m_treeGroup.InsertItem(_CS(_T("Root")));
		CreateNodeDep(hRootItem, item.strCode.c_str(), nType);
		m_treeGroup.Expand(hRootItem, TVE_EXPAND);
	}
}

bool CDlgDGroup::CreateNodeDep(HTREEITEM hParent, const char* szDepId, int nType)
{
	bool bShowNewOrgAndDevView = false;
#ifdef SHOW_NEW_ORG_AND_DEV_VIEW
	bShowNewOrgAndDevView = true;
#endif
	Get_Dep_Count_Info_t* pGetCountInfo = new Get_Dep_Count_Info_t;
	memset(pGetCountInfo, 0 , sizeof(Get_Dep_Count_Info_t));
	memcpy(pGetCountInfo->szCoding, szDepId,strlen(szDepId));

	int nRet = DPSDK_GetDGroupCount( m_nDLLHandle, pGetCountInfo );
	if (nRet != 0)
	{
		SAFE_DELETE(pGetCountInfo);
		return false;
	}
#if 0
	Get_Dep_Info_t* pGetDepInfo = new Get_Dep_Info_t;
	memset(pGetDepInfo, 0 , sizeof(Get_Dep_Info_t));
	memcpy(pGetDepInfo->szCoding, szDepId, strlen(szDepId));

	pGetDepInfo->nDepCount = pGetCountInfo->nDepCount;
	pGetDepInfo->nDeviceCount = pGetCountInfo->nDeviceCount;

	if (pGetDepInfo->nDepCount > 0)
	{
		pGetDepInfo->pDepInfo = new Dep_Info_t[pGetCountInfo->nDepCount];
		memset(pGetDepInfo->pDepInfo, 0, sizeof(Dep_Info_t)*pGetCountInfo->nDepCount);
	}

	if (pGetDepInfo->nDeviceCount > 0)
	{
		pGetDepInfo->pDeviceInfo = new Device_Info_Ex_t[pGetCountInfo->nDeviceCount];
		memset(pGetDepInfo->pDeviceInfo, 0, sizeof(Device_Info_Ex_t)*pGetCountInfo->nDeviceCount);
	}

	nRet = DPSDK_GetDGroupInfo(m_nDLLHandle, pGetDepInfo);
	if (nRet != 0)
	{
		SAFE_DELETE(pGetCountInfo);
		SAFE_M_DELETE(pGetDepInfo->pDepInfo);
		SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
		SAFE_DELETE(pGetDepInfo);
		return;
	}

	// ��������֯�ڵ�
	for (uint32_t i=0; i< pGetDepInfo->nDepCount; ++i)
	{
		CUtf8ToWide szName(pGetDepInfo->pDepInfo[i].szDepName);
		HTREEITEM hInsertItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);

		CreateNodeDep(hInsertItem, pGetDepInfo->pDepInfo[i].szCoding, nType);
	}

	for ( uint32_t i = 0; i< pGetDepInfo->nDeviceCount && !bShowNewOrgAndDevView; ++i )
	{
		CUtf8ToWide szName(pGetDepInfo->pDeviceInfo[i].szName);
		HTREEITEM hInsertItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);

		if ( pGetDepInfo->pDeviceInfo[i].nEncChannelChildCount == 0 )
		{
			continue;
		}
		Get_Channel_Info_t* pGetChannelInfo = new Get_Channel_Info_t;

		memset(pGetChannelInfo, 0 , sizeof(Get_Channel_Info_t));
		memcpy(pGetChannelInfo->szDeviceId, pGetDepInfo->pDeviceInfo[i].szId, DPSDK_CORE_DEV_ID_LEN);
		pGetChannelInfo->nEncChannelChildCount = pGetDepInfo->pDeviceInfo[i].nEncChannelChildCount;
		pGetChannelInfo->pEncChannelnfo = new Enc_Channel_Info_t[pGetChannelInfo->nEncChannelChildCount];
		memset(pGetChannelInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_t)*pGetChannelInfo->nEncChannelChildCount);

		nRet = DPSDK_GetChannelInfo(m_nDLLHandle, pGetChannelInfo);
		if (nRet != 0)
		{
			SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
			SAFE_DELETE(pGetChannelInfo);
			continue;
		}

		for ( int nChannel = 0; nChannel < pGetChannelInfo->nEncChannelChildCount; ++ nChannel)
		{

			char caminfo[512] = {0};
			strcpy_s(caminfo, sizeof(caminfo), pGetChannelInfo->pEncChannelnfo[nChannel].szName);
			strcat(caminfo,"(");
			strcat(caminfo, pGetChannelInfo->pEncChannelnfo[nChannel].szId);
			strcat(caminfo, ")");
			CUtf8ToWide szName(caminfo);

			HTREEITEM hInsertChannelItem = m_treeGroup.InsertItem(szName.wc_str(), hInsertItem);

		}
		SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
		SAFE_DELETE(pGetChannelInfo);
	}

	//add by whg 2015.06.17
	if(pGetCountInfo->nChannelCount > 0 && bShowNewOrgAndDevView)
	{
		Get_Dep_Channel_Info_t* pGetChannelInfo = new Get_Dep_Channel_Info_t;
		memset(pGetChannelInfo, 0 , sizeof(Get_Dep_Channel_Info_t));
		memcpy(pGetChannelInfo->szCoding, szDepId, strlen(szDepId));
		pGetChannelInfo->nEncChannelChildCount = pGetCountInfo->nChannelCount;
		pGetChannelInfo->pEncChannelnfo = new Enc_Channel_Info_t[pGetCountInfo->nChannelCount];
		memset(pGetChannelInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_t)*pGetChannelInfo->nEncChannelChildCount);

		nRet = DPSDK_GetDepChannelInfo(m_nDLLHandle, pGetChannelInfo);
		if (nRet != 0)
		{
			SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
			SAFE_DELETE(pGetChannelInfo);
		}else
		{
			for ( int nChannel = 0; nChannel < pGetChannelInfo->nEncChannelChildCount; ++ nChannel)
			{

				char caminfo[512] = {0};
				strcpy_s(caminfo, sizeof(caminfo), pGetChannelInfo->pEncChannelnfo[nChannel].szName);
				strcat(caminfo,"(");
				strcat(caminfo, pGetChannelInfo->pEncChannelnfo[nChannel].szId);
				strcat(caminfo, ")");
				CUtf8ToWide szName(caminfo);

				HTREEITEM hInsertChannelItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);

			}
			SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
			SAFE_DELETE(pGetChannelInfo);
		}
	}

	SAFE_DELETE(pGetCountInfo);
	SAFE_M_DELETE(pGetDepInfo->pDepInfo);
	SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
	SAFE_DELETE(pGetDepInfo);
#else
	Get_Dep_Info_Ex_t* pGetDepInfo = new Get_Dep_Info_Ex_t;
	memset(pGetDepInfo, 0 , sizeof(Get_Dep_Info_Ex_t));
	memcpy(pGetDepInfo->szCoding, szDepId, strlen(szDepId));

	pGetDepInfo->nDepCount = pGetCountInfo->nDepCount;
	pGetDepInfo->nDeviceCount = pGetCountInfo->nDeviceCount;
	pGetDepInfo->nChannelCount = pGetCountInfo->nChannelCount;

	if (pGetCountInfo->nDepCount > 0)
	{
		pGetDepInfo->pDepInfo = new Dep_Info_t[pGetCountInfo->nDepCount];
		memset(pGetDepInfo->pDepInfo, 0, sizeof(Dep_Info_t)*pGetCountInfo->nDepCount);
	}

	if (pGetCountInfo->nDeviceCount > 0)
	{
		pGetDepInfo->pDeviceInfo = new Device_Info_Ex_t[pGetCountInfo->nDeviceCount];
		memset(pGetDepInfo->pDeviceInfo, 0, sizeof(Device_Info_Ex_t)*pGetCountInfo->nDeviceCount);
	}

	if (pGetCountInfo->nChannelCount > 0)
	{
		pGetDepInfo->pEncChannelnfo = new Enc_Channel_Info_Ex_t[pGetCountInfo->nChannelCount];
		memset(pGetDepInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_Ex_t) * pGetCountInfo->nChannelCount);
	}

	nRet = DPSDK_GetDGroupInfoEx(m_nDLLHandle, pGetDepInfo);
	if (nRet != 0)
	{
		SAFE_DELETE(pGetCountInfo);
		SAFE_M_DELETE(pGetDepInfo->pDepInfo);
		SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
		SAFE_DELETE(pGetDepInfo);
		return false;
	}
	int ChildGroupCount = 0;
	//���ӽ���Լ��ӽڵ��µ�ͨ��
	for (uint32_t i=0; i< pGetDepInfo->nDepCount; ++i)
	{
		CUtf8ToWide szName(pGetDepInfo->pDepInfo[i].szDepName);
		HTREEITEM hInsertItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);

		bool res = CreateNodeDep(hInsertItem, pGetDepInfo->pDepInfo[i].szCoding, nType);
		if(res)
		{
			ChildGroupCount++;
		}
	}

	int realChannelCount = 0;
	//���뱾������µ�ͨ��
	if (hParent)
	{
		for ( uint32_t j = 0; j< pGetDepInfo->nChannelCount && !bShowNewOrgAndDevView; ++j )
		{
			//û��ʵʱԤ��Ȩ�ޣ���չʾ
			uint64_t nRight = pGetDepInfo->pEncChannelnfo[j].nRight;
			if ( (nRight & U_RIGHT_MONITOR) == 0 )
			{
				/*char temp[256] = {0};
				sprintf_s(temp, sizeof(temp), "[TEST_DPSDK_CORE]CamearID = %s has no right to open video",pGetDepInfo->pEncChannelnfo[j].szId);
				DPSDK_WriteDPSDKLog(m_nDLLHandle,temp);*/
				continue;
			}

			char caminfo[512] = {0};
			strcpy_s(caminfo, sizeof(caminfo), pGetDepInfo->pEncChannelnfo[j].szName);
			strcat(caminfo,"(");
			strcat(caminfo, pGetDepInfo->pEncChannelnfo[j].szId);
			strcat(caminfo, ")");
			CUtf8ToWide szName(caminfo);

			HTREEITEM hInsertChannelItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);
			realChannelCount++;
		}
	}

	//add by whg 2015.06.17
	//if(pGetCountInfo->nChannelCount > 0 && bShowNewOrgAndDevView)
	//{
	//	Get_Dep_Channel_Info_t* pGetChannelInfo = new Get_Dep_Channel_Info_t;
	//	memset(pGetChannelInfo, 0 , sizeof(Get_Dep_Channel_Info_t));
	//	memcpy(pGetChannelInfo->szCoding, szDepId, strlen(szDepId));
	//	pGetChannelInfo->nEncChannelChildCount = pGetCountInfo->nChannelCount;
	//	pGetChannelInfo->pEncChannelnfo = new Enc_Channel_Info_t[pGetCountInfo->nChannelCount];
	//	memset(pGetChannelInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_t)*pGetChannelInfo->nEncChannelChildCount);

	//	nRet = DPSDK_GetDepChannelInfo(m_nDLLHandle, pGetChannelInfo);
	//	if (nRet != 0)
	//	{
	//		SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
	//		SAFE_DELETE(pGetChannelInfo);
	//	}else
	//	{
	//		for ( int nChannel = 0; nChannel < pGetChannelInfo->nEncChannelChildCount; ++ nChannel)
	//		{

	//			char caminfo[512] = {0};
	//			strcpy_s(caminfo, sizeof(caminfo), pGetChannelInfo->pEncChannelnfo[nChannel].szName);
	//			strcat(caminfo,"(");
	//			strcat(caminfo, pGetChannelInfo->pEncChannelnfo[nChannel].szId);
	//			strcat(caminfo, ")");
	//			CUtf8ToWide szName(caminfo);

	//			HTREEITEM hInsertChannelItem = m_treeGroup.InsertItem(szName.wc_str(), hParent);

	//		}
	//		SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
	//		SAFE_DELETE(pGetChannelInfo);
	//	}
	//}

	SAFE_DELETE(pGetCountInfo);
	SAFE_M_DELETE(pGetDepInfo->pDepInfo);
	SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
	SAFE_DELETE(pGetDepInfo);
	if ((realChannelCount + ChildGroupCount) > 0)
	{//�ǿ���֯
		return true;
	}
	else
	{//����֯,ɾ��
		m_treeGroup.DeleteItem(hParent);
		return false;
	}
#endif
	
}

void CDlgDGroup::OnNMDblclkTree1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;

	return;

	HTREEITEM hCurItem = m_treeGroup.GetSelectedItem();
	if(hCurItem == NULL)
	{
		return;
	}

	CPoint  point;
	GetCursorPos(&point);

	m_treeGroup.ScreenToClient(&point);
	UINT uFlags;
	HTREEITEM hItem = m_treeGroup.HitTest(point, &uFlags);
	if ( hItem != hCurItem )
	{
		//ѡ��һ���ڵ㣬��˫����������չ���Ľڵ�ǰ�ġ�+��������ִ��������gaowei 09-01-07
		return;
	}

	HTREEITEM hChildItem =m_treeGroup.GetChildItem(hItem);

	if (hChildItem != NULL)
	{
		// �Ѿ�����
		return;
	}

	RefreshItem(hItem);
}

void CDlgDGroup::RefreshItem(HTREEITEM hItem)
{
	TreeItemMap::iterator itItem = m_mapTreeItem.find(hItem);
	if (itItem == m_mapTreeItem.end() || itItem->second.nType != 1)
	{
		return;
	}

	// HTREEITEM hChildItem =m_treeGroup.GetChildItem(hItem);
	{
		int nLast = 0;
		int nFirst = 0;
		int nRet = -1;

		std::map<int ,HTREEITEM> mapDeptRoot;

		mapDeptRoot[nLast++] = hItem;


		while (mapDeptRoot.size() > 0)
		{
			HTREEITEM hTempItem = mapDeptRoot[nFirst++];
			std::map<int ,HTREEITEM>::iterator it = mapDeptRoot.find(nFirst - 1);

			if (it != mapDeptRoot.end())
			{
				if (hItem != it->second)
				{
					m_treeGroup.DeleteItem(it->second);
					m_mapTreeItem.erase(it->second);
				}
				mapDeptRoot.erase(it);
			}
			HTREEITEM hChildItem = m_treeGroup.GetChildItem(hTempItem);


			if (hChildItem != NULL )
			{	

				while (hChildItem)
				{	
					mapDeptRoot[nLast++] = hChildItem;
					hChildItem =  m_treeGroup.GetNextSiblingItem(hChildItem);
				}
			}
		}

	}
	/*int m_nGroupInfoLen = 0;


	Load_Dep_Info_t* pLoadInfo = new Load_Dep_Info_t;
	memset(pLoadInfo, 0 , sizeof(Load_Dep_Info_t));
	pLoadInfo->nOperation = DPSDK_CORE_GEN_GETGROUP_OPERATION_CHILD;
	memcpy(pLoadInfo->szCoding, itItem->second.strCode.c_str(), itItem->second.strCode.size());

	int nRet = ::ShowCallRetInfo(this, DPSDK_LoadDGroupInfoLayered(m_nDLLHandle, pLoadInfo, m_nGroupInfoLen, 5000), _CS(_T("Load organization structure")));

	SAFE_M_DELETE(pLoadInfo);

	if (nRet != 0)
	{
		return;
	}*/


	Get_Dep_Count_Info_t* pGetCountInfo = new Get_Dep_Count_Info_t;
	memset(pGetCountInfo, 0 , sizeof(Get_Dep_Count_Info_t));
	memcpy(pGetCountInfo->szCoding, itItem->second.strCode.c_str(), itItem->second.strCode.size());

	int nRet = DPSDK_GetDGroupCount( m_nDLLHandle, pGetCountInfo );
	if (nRet != 0)
	{
		SAFE_DELETE(pGetCountInfo);
		return;
	}

	Get_Dep_Info_t* pGetDepInfo = new Get_Dep_Info_t;
	memset(pGetDepInfo, 0 , sizeof(Get_Dep_Info_t));
	memcpy(pGetDepInfo->szCoding, itItem->second.strCode.c_str(), itItem->second.strCode.size());

	pGetDepInfo->nDepCount = pGetCountInfo->nDepCount;
	pGetDepInfo->nDeviceCount = pGetCountInfo->nDeviceCount;

	if (pGetDepInfo->nDepCount > 0)
	{
		pGetDepInfo->pDepInfo = new Dep_Info_t[pGetCountInfo->nDepCount];
		memset(pGetDepInfo->pDepInfo, 0, sizeof(Dep_Info_t)*pGetCountInfo->nDepCount);
	}

	if (pGetDepInfo->nDeviceCount > 0)
	{
		pGetDepInfo->pDeviceInfo = new Device_Info_Ex_t[pGetCountInfo->nDeviceCount];
		memset(pGetDepInfo->pDeviceInfo, 0, sizeof(Device_Info_Ex_t)*pGetCountInfo->nDeviceCount);
	}


	nRet = DPSDK_GetDGroupInfo(m_nDLLHandle, pGetDepInfo);
	if (nRet != 0)
	{
		SAFE_DELETE(pGetCountInfo);
		SAFE_M_DELETE(pGetDepInfo->pDepInfo);
		SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
		SAFE_DELETE(pGetDepInfo);
		return;
	}

	// ��������֯�ڵ�
	for (uint32_t i=0; i< pGetDepInfo->nDepCount; ++i)
	{
		CUtf8ToWide szName(pGetDepInfo->pDepInfo[i].szDepName);
		HTREEITEM hInsertItem = m_treeGroup.InsertItem(szName.wc_str(), hItem);
		Item_Infor_t item;
		item.nType = 1;
		item.strCode = pGetDepInfo->pDepInfo[i].szCoding;

		m_mapTreeItem.insert(std::make_pair(hInsertItem, item));

		CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(item.strCode);
		if (itfind != m_mapCodeItem.end())
		{
			m_mapCodeItem.erase(itfind);
		}
		m_mapCodeItem.insert(std::make_pair(item.strCode, hInsertItem));
	}

	for ( uint32_t i = 0; i< pGetDepInfo->nDeviceCount; ++i )
	{
		CUtf8ToWide szName(pGetDepInfo->pDeviceInfo[i].szName);
		HTREEITEM hInsertItem = m_treeGroup.InsertItem(szName.wc_str(), hItem);
		Item_Infor_t item;
		item.nType = 1;
		item.strCode = pGetDepInfo->pDeviceInfo[i].szId;
		m_mapTreeItem.insert(std::make_pair(hInsertItem, item));
	
		CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(item.strCode);
		if (itfind != m_mapCodeItem.end())
		{
			m_mapCodeItem.erase(itfind);
		}
		m_mapCodeItem.insert(std::make_pair(item.strCode, hInsertItem));

		if ( pGetDepInfo->pDeviceInfo[i].nEncChannelChildCount == 0 )
		{
			continue;
		}
		Get_Channel_Info_t* pGetChannelInfo = new Get_Channel_Info_t;

		memset(pGetChannelInfo, 0 , sizeof(Get_Channel_Info_t));
		memcpy(pGetChannelInfo->szDeviceId, pGetDepInfo->pDeviceInfo[i].szId, DPSDK_CORE_DEV_ID_LEN);
		pGetChannelInfo->nEncChannelChildCount = pGetDepInfo->pDeviceInfo[i].nEncChannelChildCount;
		pGetChannelInfo->pEncChannelnfo = new Enc_Channel_Info_t[pGetChannelInfo->nEncChannelChildCount];
		memset(pGetChannelInfo->pEncChannelnfo, 0, sizeof(Enc_Channel_Info_t)*pGetChannelInfo->nEncChannelChildCount);

		nRet = DPSDK_GetChannelInfo(m_nDLLHandle, pGetChannelInfo);
		if (nRet != 0)
		{
			SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
			SAFE_DELETE(pGetChannelInfo);
			continue;
		}

		for ( int nChannel = 0; nChannel < pGetDepInfo->pDeviceInfo[i].nEncChannelChildCount; ++ nChannel)
		{

			char caminfo[512] = {0};
			strcpy_s(caminfo, sizeof(caminfo), pGetChannelInfo->pEncChannelnfo[nChannel].szName);
			strcat(caminfo,"(");
			strcat(caminfo, pGetChannelInfo->pEncChannelnfo[nChannel].szId);
			strcat(caminfo, ")");
			CUtf8ToWide szName(caminfo);

			HTREEITEM hInsertChannelItem = m_treeGroup.InsertItem(szName.wc_str(), hInsertItem);

			Item_Infor_t item;
			item.nType = 3;
			item.strCode = pGetChannelInfo->pEncChannelnfo[nChannel].szId;
			m_mapTreeItem.insert(std::make_pair(hInsertChannelItem, item));
		
			CodeTreeItemMap::iterator itfind = m_mapCodeItem.find(item.strCode);
			if (itfind != m_mapCodeItem.end())
			{
				m_mapCodeItem.erase(itfind);
			}
			m_mapCodeItem.insert(std::make_pair(item.strCode, hInsertItem));

		}
		SAFE_M_DELETE(pGetChannelInfo->pEncChannelnfo);
		SAFE_DELETE(pGetChannelInfo);
	}

	SAFE_DELETE(pGetCountInfo);
	SAFE_M_DELETE(pGetDepInfo->pDepInfo);
	SAFE_M_DELETE(pGetDepInfo->pDeviceInfo);
	SAFE_DELETE(pGetDepInfo);

}

void CDlgDGroup::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgDGroup::GetWidget() const
{
	return const_cast<CDlgDGroup*>(this);
}

CString CDlgDGroup::GetTestUIName() const
{
	return _T("��֯�ṹ");
}

void CDlgDGroup::OnSize(UINT nType, int cx, int cy)
{
	__super::OnSize(nType, cx, cy);

	if(m_treeGroup.GetSafeHwnd())
	{
		CRect rt;
		GetClientRect(&rt);
		m_treeGroup.MoveWindow(0,0,rt.Width(),rt.Height());
	}
}
