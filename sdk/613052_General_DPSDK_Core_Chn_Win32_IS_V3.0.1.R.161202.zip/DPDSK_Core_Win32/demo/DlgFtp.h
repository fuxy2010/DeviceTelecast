#pragma once
#include "afxcmn.h"
#include "DPSDK_Core_Error.h"
#include "DPSDK_Core.h"
#include "interface/IAbstractUI.h"


// CDlgFtp �Ի���

class CDlgFtp : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgFtp)

public:
	CDlgFtp(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgFtp();

// �Ի�������
	enum { IDD = IDD_DLG_FTP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	virtual BOOL OnInitDialog();

public:
	CListCtrl m_listFtpPic;
	void SetHandle(int nDLLHandle);

private:
	int32_t m_nDLLHandle;
	int32_t		m_nSeq;
public:
	afx_msg void OnBnClickedButtonQueryPicture();
	afx_msg void OnBnClickedButtonDeletePicture();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

};
