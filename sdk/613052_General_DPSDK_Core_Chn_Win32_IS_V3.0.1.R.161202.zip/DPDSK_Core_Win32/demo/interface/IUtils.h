#pragma once

class IUtils
{
public:
	IUtils(){ m_nDLLHandle = 0; }
	virtual ~IUtils() {}

protected:
	int		         m_nDLLHandle;

public:
	virtual void SetHandle(int nDLLHandle) { m_nDLLHandle = nDLLHandle; }
	virtual void Destroy() = 0;

};