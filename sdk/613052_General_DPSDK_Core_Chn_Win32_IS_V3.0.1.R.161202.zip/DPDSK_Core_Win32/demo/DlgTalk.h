#pragma once
#include"DPSDK_Core.h"
#include "interface/IAbstractUI.h"

// CDlgTalk �Ի���

class CDlgTalk : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgTalk)

public:
	CDlgTalk(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgTalk();

// �Ի�������
	enum { IDD = IDD_DLG_TALK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL  OnInitDialog();

	int32_t m_nDLLHandle;
	int32_t		m_nSeq;
	bool bVtCallInvate;
	bool bAcceptInvite;
	unsigned int videosession;
	unsigned int audiosession;

	DECLARE_MESSAGE_MAP()
public:
	InviteVtCallParam_t vtCallParam;
	void SetHandle(int nDLLHandle);
	void CloseWin();
	afx_msg void OnClose();
	afx_msg void OnBnClickedButtonStartTalk();
	afx_msg void OnBnClickedButtonStopTalkBySeq();
	afx_msg void OnBnClickedButtonStopTalkByCameralId();
	afx_msg void OnBnClickedButtonStartTalk2();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnBnClickedButtonReject();
	afx_msg LRESULT OnInviteVtCallMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedButtonAccept();
};
