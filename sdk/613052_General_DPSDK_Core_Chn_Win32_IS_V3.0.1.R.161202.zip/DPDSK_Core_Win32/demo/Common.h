#pragma once

class CWndPlayer;

int ShowCallRetInfo(CWnd* pWnd, int nRet, CString& strInfo);
int PrintfText(CString& strInfo);
int ShowWndPlayer(CWnd* pWnd, CWndPlayer& pWndPlayer);