// FaceRec.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "FaceRec.h"
#include <atlimage.h>
#include <atlconv.h>
// CFaceRec �Ի���

IMPLEMENT_DYNAMIC(CFaceRec, CDialog)

CFaceRec::CFaceRec(CWnd* pParent /*=NULL*/)
	: CDialog(CFaceRec::IDD, pParent)
	, m_strCamId(_T("1000004$1$0$0"))
{

}

CFaceRec::~CFaceRec()
{
}

void CFaceRec::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strCamId);
}


BEGIN_MESSAGE_MAP(CFaceRec, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CFaceRec::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CFaceRec::OnBnClickedButton2)
	ON_WM_PAINT()
END_MESSAGE_MAP()

uint32_t CFaceRec::GetFileData( char*& buffer, const CString strFile )
{
	//��ͼƬ�������±��棬��ʱ���ڽ�������ʽ���⡣modify by mj.

	FILE *pStream = NULL;
	USES_CONVERSION;
	char* s = T2A(strFile);
	pStream = fopen(s, "rb");
	if (NULL == pStream)
	{
		//��ʧ��
		return -1;
	}

	long curpos, length; 
	curpos = ftell(pStream); 
	fseek(pStream, 0L, SEEK_END);
	length = ftell(pStream);
	fseek(pStream, curpos, SEEK_SET);

	if (length > 0)
	{
		buffer = new char[length + 1];
		memset(buffer, 0, length+1);
		fseek(pStream, 0, SEEK_SET);//���ļ�ָ���Ƶ�����ͷλ��
		fread(buffer, 1, length, pStream);//��ȡͼƬ����
	}
	fclose(pStream);
	return length;
}


// CFaceRec ��Ϣ��������

void CFaceRec::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	static TCHAR BASED_CODE szFilter[] = _T("JPG Files (*.jpg)|*.jpg|JPG Files (*.BMP)|*.bmp|JIF Files (*.bmp)|*.jif|All Files (*.*)|*.*||");
	CFileDialog dlg(TRUE,_T("BMP"),NULL,  OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);
	if(dlg.DoModal() != IDOK)
		return;
	pathname = dlg.GetPathName();
//	MessageBox(pathname);
	HWND m_hWnd;
	GetDlgItem(IDC_STATIC_VIEW,&m_hWnd);
	CWnd *pWnd = GetDlgItem(IDC_STATIC_VIEW);
	CDC *pDC = pWnd->GetDC();
	CRect rect;
	pWnd->GetWindowRect(rect);
	DisplayPic(pathname,m_hWnd,rect.Width(), rect.Height());

}

HRESULT CFaceRec::DisplayPic( CString lpImageFile, HWND hWnd, int nScrWidth, int nScrHeight )
{
	HDC hDC_Temp=::GetDC(hWnd);
	IPicture *pPic;
	IStream *pStm;
	BOOL bResult;
	HANDLE hFile=NULL;
	DWORD dwFileSize,dwByteRead;
	//��Ӳ���е�ͼ���ļ�
	//    hFile=CreateFile(lpstrFile,GENERIC_READ,
	//    FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	hFile=CreateFile(lpImageFile,GENERIC_READ,
		FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

	if (hFile!=INVALID_HANDLE_VALUE)
	{
		dwFileSize=GetFileSize(hFile,NULL);//��ȡ�ļ��ֽ���
		if (dwFileSize==0xFFFFFFFF)
			return E_FAIL;
	}
	else
	{
		return E_FAIL;
	}
	//����ȫ�ִ洢�ռ�
	HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, dwFileSize);
	LPVOID pvData = NULL;
	if (hGlobal == NULL)
	{
		AfxMessageBox(_T("ͼ���ļ��������."));
		return E_FAIL;
	}
	if ((pvData = GlobalLock(hGlobal)) == NULL)//���������ڴ��
	{
		AfxMessageBox(_T("�ڴ������������"));
		return E_FAIL;
	}
	ReadFile(hFile,pvData,dwFileSize,&dwByteRead,NULL);//���ļ������ڴ滺����
	GlobalUnlock(hGlobal);
	if(CreateStreamOnHGlobal(hGlobal, TRUE, &pStm) != S_OK)
	{
		AfxMessageBox(_T("����ʼ��ʧ��"));
		return E_FAIL;
	}
	//װ��ͼ���ļ�
	bResult=OleLoadPicture(pStm,dwFileSize,TRUE,IID_IPicture,(LPVOID*)&pPic);
	if(FAILED(bResult))
	{
		AfxMessageBox(_T("ͼ���ļ�װ�س���."));
		return E_FAIL;
	}
	OLE_XSIZE_HIMETRIC hmWidth;//ͼƬ����ʵ����
	OLE_YSIZE_HIMETRIC hmHeight;//ͼƬ����ʵ�߶�
	pPic->get_Width(&hmWidth);
	pPic->get_Height(&hmHeight);
	//��ͼ���������Ļ��
	bResult=pPic->Render(hDC_Temp,0,0,nScrWidth,nScrHeight,
		0,hmHeight,hmWidth,-hmHeight,NULL);
	CloseHandle(hFile);//�رմ򿪵��ļ�

	pPic->Release();
	// Free memory.
	GlobalFree(hGlobal);
	if (SUCCEEDED(bResult))
	{
		return S_OK;
	}
	else
	{
		AfxMessageBox(_T("ͼ���ļ�װ�س���."));
		return E_FAIL;
	}

}

void CFaceRec::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData(TRUE);
	USES_CONVERSION;
	char *fileBuf;
	long len2;
	int len = GetFileData(fileBuf,pathname);
	CImage image;
	image.Load(pathname);
//	JDEC_OUTPUT_PARAM YuvOutput={0};
//	JDEC_INPUT_PARAM stuInputParam = {0};
//
//	//������
//	void*	hJepgdec = JPEG_Dec_Open(NULL);
//	stuInputParam.pBitstream = (void*)fileBuf;
//	stuInputParam.nFlag			= 1;           //�������ͱ�־��h264������ 
//	stuInputParam.nLength		= len;      //��������
//	stuInputParam.nColorspace	= 1;	/* 1:420, 2:422 */ //���������ļ���ʽ��������420
//	stuInputParam.bDeInterlace	= 0;
//	stuInputParam.nPostproclevel = 0;
//	int iBufferSize = 4000*4000;
//	char* pYdata = new char[iBufferSize];
//	char* pUdata = new char[iBufferSize/4];
//	char* pVdata = new char[iBufferSize/4];
//	YuvOutput.pY = (unsigned char*)pYdata;
//	YuvOutput.pU = (unsigned char*)pUdata;
//	YuvOutput.pV = (unsigned char*)pVdata;
//	int nRet = JPEG_Dec_Decode(hJepgdec,&stuInputParam,&YuvOutput);
//
//	char *pdata = new char[4000*4000*3/2];
//	memset(pdata, 0, 4000*4000*3/2); 
//	memcpy(pdata, YuvOutput.pY, YuvOutput.stride[0]*YuvOutput.nHeight); 
//	memcpy(pdata+YuvOutput.stride[0]*YuvOutput.nHeight, YuvOutput.pU, YuvOutput.stride[0]*YuvOutput.nHeight/4); 
//	memcpy(pdata+YuvOutput.stride[0]*YuvOutput.nHeight*5/4, YuvOutput.pV, YuvOutput.stride[0]*YuvOutput.nHeight/4); 
//
//
//	DHFDParam *pFDParam = new DHFDParam;
//	pFDParam->width = YuvOutput.stride[0];
//	pFDParam->height = YuvOutput.nHeight;
//	pFDParam->lefttop.x = 0;
//	pFDParam->lefttop.y = 0;
//	pFDParam->rightbottom.x = YuvOutput.stride[0] - 1;
//	pFDParam->rightbottom.y = YuvOutput.nHeight - 1;
//	pFDParam->minwidth = 20;
//	pFDParam->maxwidth = YuvOutput.stride[0];
//	pFDParam->DTPRE = 8;
//	pFDParam->DTSEN =10;
//
//
//	DHFDHandle *pFDHandle = new DHFDHandle;
//	pFDHandle->BufferLen = DH_FDCalcMemSize(pFDParam);
//	pFDHandle->pBuffer =(dU8*)malloc(pFDHandle->BufferLen);
//
//	int nFdInit = DH_FDInit(pFDHandle, pFDParam); 
//	if (0 == nFdInit) 
//	{ 
//		return;	
//	}
//
//	//�������
//	DHFDResult* pFDResult =  (DHFDResult*)malloc(MAX_DETECTION_COUNT * sizeof(DHFDResult));
//	memset(pFDResult,0,MAX_DETECTION_COUNT*sizeof(DHFDResult)); 
//	for (int i = 0; i< MAX_DETECTION_COUNT; i++)
//	{
//		pFDResult[i].pFDPos = (DHPoint*)malloc(sizeof(DHPoint));
//		memset(pFDResult[i].pFDPos, 0, sizeof(DHPoint));
//	}
//
//	int nFace = 0;
//	int i = 0;
//	while (i < 4)
//	{
//		nFace = DH_FDProcess(pFDHandle, pFDParam, (unsigned char*)pdata, pFDResult);
//		if (nFace <= 0)
//		{
//			i++;
//		}
//		else
//			break;
//	};
//
//	//	��ͼƬ������m_pFDResultת��ΪVecDHFDResult& vecResult����
//	for(int i=0;i<MAX_DETECTION_COUNT && i < nFace;i++)
//	{
//		CRect rect;
//		CWnd *pWnd = GetDlgItem(IDC_STATIC_VIEW);
//		CRect r;
//		pWnd->GetWindowRect(r);
//		rect.SetRect(pFDResult[i].FDReg.x*r.Width()/image.GetWidth(),pFDResult[i].FDReg.y*r.Height()/image.GetHeight(),(pFDResult[i].FDReg.x+pFDResult[i].FDReg.width)*r.Width()/image.GetWidth(),(pFDResult[i].FDReg.y+pFDResult[i].FDReg.height)*r.Height()/image.GetHeight());
////		image.copy()
//		HWND m_hWnd;
//		GetDlgItem(IDC_STATIC_VIEW,&m_hWnd);
//		CDC *pDC = pWnd->GetDC();
//		pDC->Rectangle(rect);
//		
//	}
//	if(NULL != pFDParam)
//	{
//		delete pFDParam;
//		pFDParam = NULL;
//	}
//	if (pFDHandle != NULL)
//	{
//		if (pFDHandle->pBuffer != NULL)
//		{
//			free(pFDHandle->pBuffer);
//			pFDHandle->pBuffer = NULL;
//		}
//		delete pFDHandle;
//		pFDHandle = NULL;
//	}
//	//SAFE_DELETE(pFDHandle);
//	if (pFDResult != NULL)
//	{
//		//�˴���Ҫ���ͷ�(pFDResult[i].pFDPos)���Ѿ�����ͼ��������
//		free (pFDResult);
//	}
//
//	
//	if (hJepgdec != NULL)
//	{
//		JPEG_Dec_Close(hJepgdec);
//	}
//	if (NULL != pYdata)
//	{
//		delete [] pYdata;
//		pYdata = NULL;
//	}
//
//	if (NULL != pUdata)
//	{
//		delete [] pUdata;
//		pUdata = NULL;
//	}
//
//	if (NULL != pVdata)
//	{
//		delete [] pVdata;
//		pVdata = NULL;
//	}
//
//	if (pdata!=NULL)
//	{
//		delete pdata;
//		pdata = NULL;
//	}


	int ret = DPSDK_ExtractFacePicDataLength(m_nDLLHandle, T2A(m_strCamId), 0, fileBuf, len, image.GetWidth(),image.GetHeight(),&len2);
	if (len2>0)
	{
		char *s = new char[len2+1];
		memset(s,0,len2+1);
		ret = DPSDK_ExtractFacePicData(m_nDLLHandle, T2A(m_strCamId), 0, fileBuf, len, image.GetWidth(),image.GetHeight(),s,len2);
	}
	
}

void CFaceRec::SetHandle( int nDLLHandle )
{
	m_nDLLHandle = nDLLHandle;
}

void CFaceRec::OnPaint()
{
	//CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()

	if (IsIconic())
	{
	}
	else
	{  
		HWND m_hWnd;
		GetDlgItem(IDC_STATIC_VIEW,&m_hWnd);
		CWnd *pWnd = GetDlgItem(IDC_STATIC_VIEW);
		CDC *pDC = pWnd->GetDC();
		CRect rect;
		pWnd->GetWindowRect(rect);

		DisplayPic(pathname,m_hWnd,rect.Width(), rect.Height());
		CDialog::OnPaint();
	}

}
