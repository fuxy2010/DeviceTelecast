#pragma once
#include "DPSDK_Core.h"

// CWndPlayer �Ի���

class CWndPlayer : public CDialog
{
	DECLARE_DYNAMIC(CWndPlayer)

public:
	CWndPlayer(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CWndPlayer();

	// �Ի�������
	enum { IDD = IDD_DLG_PLAYER };

	// ʹ��DPSDK_Ext
	int OpenVideo(int nHandle, int& nSeq, Get_RealStream_Info_t* pStreamInfo, int nTimeout = 10000);
	int OpenVideo(int nHandle, int& nSeq, Get_RecordStream_File_Info_t* pStreamInfo, int nTimeout = 10000);
	int OpenVideo(int nHandle, int& nSeq, Get_RecordStream_Time_Info_t* pStreamInfo, int nTimeout = 10000);
	int OpenVideo(int nHandle, int& nSeq, Get_Record_Local_Info_t* pRecordInfo, int nTimeout = 10000);
	int CloseVideo(int nHandle, int nSeq);
	int PauseVideo(int nHandle, int nSeq);
	int SeekVideo(int nHandle, int nSeq,uint64_t nBeginTime,uint64_t nEndTime,bool bLocal = false);
	int ResumeVideo(int nHandle, int nSeq);
	int SetVideoSpeed(int nHandle, int nSeq, dpsdk_playback_speed_e eSpeed);
	int CloseRealStreamByCameraId(int nHandle, const char* szCameraId);
	int CloseRecordStreamByCameraId(int nHandle, const char* szCameraId);

	// ��ʹ��DPSDK_Ext
	fMediaDataCallback GetMediaDataCallbackFunc(void) {return MediaDataCallback;}
	int OpenStream(int nSeq);
	int CloseStream(int nSeq);
	int Capture(int nHandle, int nSeq, int nType, const char* szFilename);
	int GetFrameTime(int nHandle, int nSeq, uint64_t& nFramTime);
	int GetPlayPos(int nHandle, int nSeq,int& nPos);
	int GetColor(int nHandle, int nSeq, Video_Color_Info_t &videoColorInfo);
	int AdjustColor(int nHandle, int nSeq, Video_Color_Info_t videoColorInfo);
	int PlayOneByOne(int nHandle, int nSeq);
	int PlayOneByOneBack(int nHandle, int nSeq);

	int StartRealRecord(int nHandle, int nSeq,  char* szFilename);
	int StopRealRecord(int nHandle, int nSeq);
	int SetOsdTxt(int nHandle, int nSeq,  char* szOsdTxt);
	int CleanUpOsdInfo(int nHandle, int nSeq);
	int GetRecordStreamByFile(int nHandle, int& nSeq,Get_RecordStream_File_Info_t* pRecordInfo,fMediaDataCallback pFun, void* pUser);
	int StopPlayBackLoad(int nHandle, int& nSeq);
	int PauseRecordStreamBySeq(int nHandle, int& nSeq, int nTimeout = DPSDK_CORE_DEFAULT_TIMEOUT );
	int GetRecordStreamByTime( int nHandle,int& nSeq,Get_RecordStream_Time_Info_t* pRecordInfo, fMediaDataCallback pFun, void* pUser, int nTimeout = DPSDK_CORE_DEFAULT_TIMEOUT );
	int QueryRecord(int nHandle,  Query_Record_Info_t* pQueryInfo, int& nRecordCount, int nTimeout = DPSDK_CORE_DEFAULT_TIMEOUT );
	int ResumePlaybackBySeq(int nHandle, int nSeq, int nTimeout = DPSDK_CORE_DEFAULT_TIMEOUT);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	DECLARE_MESSAGE_MAP()

	afx_msg LRESULT OnMediaDataCallback(WPARAM wParam, LPARAM lParam);

	int InitFreePort(void);
	int GetFreePort(void);
	int RecycleFreePort(int nPort);

	int PushMediaData(int nSeq, const char* szData, int nLen);
	int ClearMediaData(int nSeq);
	int Play(int nSeq, const char* szMediaData, int nDataLen);
	static int32_t DPSDK_CALLTYPE MediaDataCallback(int32_t nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, char* szData, int32_t nDataLen, void* pUserParam);

protected:
#ifndef USING_DPSDK_EXT
	typedef struct tagPlayerInfo
	{
		int			nPort;
		CVaxPlayer*	pVaxPlayer;
	}PlayerInfo_t;

	typedef struct tagMediaInfo
	{
		char*	pszMediaData;
		int		nDataLen;
	}MediaInfo_t;
#endif

private:
#ifdef USING_DPSDK_EXT
	std::map<int, int>	m_mapMediaType;
#else
	ANA_HANDLE	m_hStreamHandle;

	std::map<int, PlayerInfo_t>				m_mapPlayer;
	std::map<int, std::queue<MediaInfo_t> >	m_mapMedia;
	CMutex	m_mtxMedia;
#endif
};
