#pragma once

#include "interface/IAbstractUI.h"
#include "afxcmn.h"
#include <map>

// CDlgTab �Ի���

class CDlgTab : public CDialog
{
	DECLARE_DYNAMIC(CDlgTab)

public:
	CDlgTab(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgTab();

	// �Ի�������
	enum { IDD = IDD_DLG_TAB };

private:
	CTabCtrl m_tabCtrl;
	std::map<int, IAbstractUI*>  m_mapView;

private:
	void Test();
	void OnTabSelChanged();
	void AppendItem(CString strItemName);
	void AppendItem(CString strItemName,IAbstractUI* pView);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	void AppendItem(IAbstractUI* pView);
	void SetCurSel(int nIndex);

public:
	afx_msg void OnTcnSelchangeTabFun(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);

};
