#pragma once
#include "DPSDK_Core.h"
#include "interface/IAbstractUI.h"

// CDlgPrison �Ի���

class CDlgPrison : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgPrison)

public:
	CDlgPrison(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPrison();
	void SetHandle(int nDLLHandle);

// �Ի�������
	enum { IDD = IDD_DLG_PRISON };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()

public:
	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

private:
	int32_t	m_nDLLHandle;
public:
	afx_msg void OnBnClickedBtnGetDiskInfo();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBtnSetHeader();
	afx_msg void OnBnClickedBtnControlBurner();
};
