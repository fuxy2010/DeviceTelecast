// WndPlayer.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WndPlayer.h"
#include "DPSDK_Core_Error.h"

#define MIN_FREE_PORT	101
#define MAX_FREE_PORT	500
enum
{
	MEDIA_TYPE_REAL		= 1,
	MEDIA_TYPE_PLAYBACK	= 2,
};

std::deque<int>	g_queFreePort;
std::set<int>	g_setFreePort;

// CWndPlayer �Ի���

IMPLEMENT_DYNAMIC(CWndPlayer, CDialog)

CWndPlayer::CWndPlayer(CWnd* pParent /*=NULL*/)
	: CDialog(CWndPlayer::IDD, pParent)
{
#ifndef USING_DPSDK_EXT
	ANA_CreateStream(0, &m_hStreamHandle);
	InitFreePort();
#endif
}

CWndPlayer::~CWndPlayer()
{
#ifndef USING_DPSDK_EXT
	ANA_Destroy(m_hStreamHandle);
	m_hStreamHandle = NULL;
#endif
}

void CWndPlayer::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CWndPlayer, CDialog)
	ON_MESSAGE(WM_MEDIADATA_CB, OnMediaDataCallback)
END_MESSAGE_MAP()

// CWndPlayer ��Ϣ��������
int CWndPlayer::OpenVideo(int nHandle, int& nSeq, Get_RealStream_Info_t* pStreamInfo, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StartRealplay(nHandle, nSeq, pStreamInfo, m_hWnd, nTimeout);//m_hWnd�Ǵ�����CWndPlayer�ľ��,������ʾ��Ƶ
	m_mapMediaType[nSeq] = MEDIA_TYPE_REAL;
#endif

	return nRet;
}

int CWndPlayer::OpenVideo(int nHandle, int& nSeq, Get_RecordStream_File_Info_t* pStreamInfo, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StartPlaybackByFile(nHandle, nSeq, pStreamInfo, m_hWnd, nTimeout);
	m_mapMediaType[nSeq] = MEDIA_TYPE_PLAYBACK;
#endif

	return nRet;
}

int CWndPlayer::OpenVideo(int nHandle, int& nSeq, Get_RecordStream_Time_Info_t* pStreamInfo, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StartPlaybackByTime(nHandle, nSeq, pStreamInfo, m_hWnd, nTimeout);
	m_mapMediaType[nSeq] = MEDIA_TYPE_PLAYBACK;
#endif

	return nRet;
}

int CWndPlayer::OpenVideo(int nHandle, int& nSeq, Get_Record_Local_Info_t* pStreamInfo, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StartPlaybackByLocal(nHandle, nSeq, pStreamInfo, m_hWnd);
	m_mapMediaType[nSeq] = MEDIA_TYPE_PLAYBACK;
#endif

	return nRet;
}


int CWndPlayer::CloseVideo(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	std::map<int, int>::iterator iter = m_mapMediaType.find(nSeq);
	if (iter != m_mapMediaType.end())
	{
		switch ((*iter).second)
		{
		case MEDIA_TYPE_REAL:
			nRet = DPSDK_StopRealplayBySeq(nHandle, nSeq);
			break;
		case MEDIA_TYPE_PLAYBACK:
			nRet = DPSDK_StopPlaybackBySeq(nHandle, nSeq);
			break;
		default:;
		}

		Invalidate(TRUE);
	}
#endif

	return nRet;
}

int CWndPlayer::PauseVideo(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	std::map<int, int>::iterator iter = m_mapMediaType.find(nSeq);
	if (iter != m_mapMediaType.end())
	{
		switch ((*iter).second)
		{
		case MEDIA_TYPE_PLAYBACK:
			nRet = DPSDK_PausePlaybackBySeq(nHandle, nSeq);
			break;
		default:;
		}
	}
#endif

	return nRet;
}


int CWndPlayer::SeekVideo( int nHandle, int nSeq,uint64_t nBeginTime,uint64_t nEndTime,bool bLocal/*= false*/)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	std::map<int, int>::iterator iter = m_mapMediaType.find(nSeq);
	if (iter != m_mapMediaType.end())
	{
		switch ((*iter).second)
		{
		case MEDIA_TYPE_PLAYBACK:
			nRet = DPSDK_SeekPlaybackBySeq(nHandle, nSeq,nBeginTime,nEndTime/*,bLocal*/);
			break;
		default:;
		}
	}
#endif

	return nRet;
}


int CWndPlayer::ResumeVideo(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	std::map<int, int>::iterator iter = m_mapMediaType.find(nSeq);
	if (iter != m_mapMediaType.end())
	{
		switch ((*iter).second)
		{
		case MEDIA_TYPE_PLAYBACK:
			nRet = DPSDK_ResumePlaybackBySeq(nHandle, nSeq);
			break;
		default:;
		}
	}
#endif

	return nRet;
}

int CWndPlayer::SetVideoSpeed(int nHandle, int nSeq, dpsdk_playback_speed_e eSpeed)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	std::map<int, int>::iterator iter = m_mapMediaType.find(nSeq);
	if (iter != m_mapMediaType.end())
	{
		switch ((*iter).second)
		{
		case MEDIA_TYPE_PLAYBACK:
			nRet = DPSDK_SetPlaybackSpeed(nHandle, nSeq, eSpeed);
			break;
		default:;
		}
	}
#endif

	return nRet;
}

int CWndPlayer::CloseRealStreamByCameraId(int nHandle, const char* szCameraId)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

	return nRet;
}

int CWndPlayer::CloseRecordStreamByCameraId(int nHandle, const char* szCameraId)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StopPlaybackByCameraId(nHandle, szCameraId);
	Invalidate(TRUE);
#endif

	return nRet;
}


int CWndPlayer::OpenStream(int nSeq)
{
#ifndef USING_DPSDK_EXT
	std::map<int,PlayerInfo_t>::iterator iter = m_mapPlayer.find(nSeq);
	if (iter != m_mapPlayer.end())
	{
		return -1;
	}

	int nPort = GetFreePort();
	if (nPort == -1)
	{
		return -1;
	}
	
	PlayerInfo_t stuPlayerInfo = {0};
	stuPlayerInfo.nPort = nPort;
	stuPlayerInfo.pVaxPlayer = new CVaxPlayer(nPort, 1);
	m_mapPlayer[nSeq] = stuPlayerInfo;
	
	if (stuPlayerInfo.pVaxPlayer != NULL)
	{
		stuPlayerInfo.pVaxPlayer->setStreamOpenMode(STREAME_REALTIME);
		stuPlayerInfo.pVaxPlayer->openStream(NULL, 0, 900*1024);
		stuPlayerInfo.pVaxPlayer->play(m_hWnd);
	}
#endif
	
	return 0;
}

int CWndPlayer::CloseStream(int nSeq)
{
#ifndef USING_DPSDK_EXT
	std::map<int,PlayerInfo_t>::iterator iter = m_mapPlayer.find(nSeq);
	if (iter == m_mapPlayer.end())
	{
		return -1;
	}

	RecycleFreePort((*iter).second.nPort);
	if ((*iter).second.pVaxPlayer != NULL)
	{
		(*iter).second.pVaxPlayer->stop();
		(*iter).second.pVaxPlayer->closeStream();
		delete (*iter).second.pVaxPlayer;
		(*iter).second.pVaxPlayer = NULL;
	}
	m_mapPlayer.erase(iter);

	ClearMediaData(nSeq);
	Invalidate(TRUE);
#endif
	
	return 0;
}

int CWndPlayer::Capture(int nHandle, int nSeq, int nType, const char* szFilename)
{
#ifdef USING_DPSDK_EXT
	return DPSDK_PicCapture(nHandle, nSeq, (dpsdk_pic_type_e)nType, szFilename);
#else
	std::map<int,PlayerInfo_t>::iterator iter = m_mapPlayer.find(nSeq);
	if (iter == m_mapPlayer.end())
	{
		return -1;
	}

	int nPort = iter->second.nPort;
	CVaxPlayer* pVaxPlayer = iter->second.pVaxPlayer;
	LONG nWidth = 0, nHeight = 0;
	pVaxPlayer->getPictureSize(&nWidth, &nHeight);

	DWORD nBufSize = (nType == DPSDK_CORE_PIC_FORMAT_BMP) ? sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+nWidth*nHeight*4 : nWidth*nHeight*3/2;
	DWORD nPicSize = 0;
	BYTE* pszBuffer = new BYTE[nBufSize];
	memset(pszBuffer, 0, sizeof(BYTE)*nBufSize);
	pVaxPlayer->getPic(pszBuffer, nBufSize, &nPicSize, (VaxtPicFormats)nType);

	FILE* fp = NULL;
	fopen_s(&fp, szFilename, "wb");
	if (fp != NULL)
	{
		fwrite(pszBuffer, sizeof(BYTE), nPicSize, fp);
		fclose(fp);
	}
	delete[] pszBuffer;
	return 0;
#endif	
}

 int CWndPlayer::GetFrameTime(int nHandle, int nSeq, uint64_t& nFramTime)
 {
	 int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	 nRet = DPSDK_GetFrameTime(nHandle, nSeq, nFramTime);
#endif

	 return nRet;
 }


 int CWndPlayer::GetPlayPos(int nHandle, int nSeq,int& nPos)
 {
	 int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	 nRet = DPSDK_GetPlayPos(nHandle, nSeq, nPos);
#endif

	 return nRet;
 }


int CWndPlayer::StartRealRecord(int nHandle, int nSeq,  char* szFileName)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StartRecord(nHandle, nSeq, szFileName);
#endif

	return nRet;
}

int CWndPlayer::StopRealRecord(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StopRecord(nHandle, nSeq);
#endif

	return nRet;
}

int CWndPlayer::GetColor(int nHandle, int nSeq, Video_Color_Info_t &videoColorInfo)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_GetColor(nHandle, nSeq, videoColorInfo);
#endif

	return nRet;
}

int CWndPlayer::AdjustColor(int nHandle, int nSeq, Video_Color_Info_t videoColorInfo)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_AdjustColor(nHandle, nSeq, videoColorInfo);
#endif

	return nRet;
}

int CWndPlayer::PlayOneByOne(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_PlayOneByOne(nHandle, nSeq);
#endif

	return nRet;
}

int CWndPlayer::PlayOneByOneBack(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_PlayOneByOneBack(nHandle, nSeq);
#endif

	return nRet;
}

int CWndPlayer::SetOsdTxt(int nHandle, int nSeq, char* szOsdTxt)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_SetOsdTxt(nHandle, nSeq, szOsdTxt);
#endif

	return nRet;
}


int CWndPlayer::CleanUpOsdInfo(int nHandle, int nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_CleanUpOsdInfo(nHandle, nSeq);
#endif

	return nRet;
}

int  CWndPlayer::GetRecordStreamByFile(int nHandle, int& nSeq,Get_RecordStream_File_Info_t* pRecordInfo,fMediaDataCallback pFun, void* pUser)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_GetRecordStreamByFile(nHandle, nSeq, pRecordInfo, pFun, pUser);
#endif

	return nRet;
}

int CWndPlayer::StopPlayBackLoad(int nHandle, int& nSeq)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_StopDownloadRecord(nHandle, nSeq);
#endif

	return nRet;

}

int CWndPlayer:: PauseRecordStreamBySeq(int nHandle, int& nSeq, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet = DPSDK_PauseRecordStreamBySeq(nHandle, nSeq,nTimeout);
#endif

	return nRet;
}

int CWndPlayer::QueryRecord(int nHandle,  Query_Record_Info_t* pQueryInfo, int& nRecordCount, int nTimeout)
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet =DPSDK_QueryRecord(nHandle,pQueryInfo,nRecordCount,nTimeout);
#endif

	return nRet;

}

int CWndPlayer::ResumePlaybackBySeq(int nHandle, int nSeq, int nTimeout )
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet =DPSDK_ResumePlaybackBySeq(nHandle,nSeq,nTimeout);
#endif

	return nRet;
}


int CWndPlayer::GetRecordStreamByTime( int nHandle,int& nSeq,Get_RecordStream_Time_Info_t* pRecordInfo, fMediaDataCallback pFun, void* pUser, int nTimeout )
{
	int nRet = DPSDK_RET_SYNC_FAIL;

#ifdef USING_DPSDK_EXT
	nRet =  DPSDK_GetRecordStreamByTime(  nHandle, nSeq, pRecordInfo,  pFun,  pUser,  nTimeout );
#endif
	return nRet;

}

LRESULT CWndPlayer::OnMediaDataCallback(WPARAM wParam, LPARAM lParam)
{
#ifndef USING_DPSDK_EXT
	int nSeq = (int)wParam;

	m_mtxMedia.Lock();
	std::map<int, std::queue<MediaInfo_t> >::iterator iter = m_mapMedia.find(nSeq);
	if (iter != m_mapMedia.end() && !(*iter).second.empty())
	{
		const MediaInfo_t* pMediaInfo = &(*iter).second.front();
		Play(nSeq, pMediaInfo->pszMediaData, pMediaInfo->nDataLen);
		delete[] pMediaInfo->pszMediaData;
		(*iter).second.pop();
	}
	m_mtxMedia.Unlock();
#endif

	return 0;
}

int CWndPlayer::InitFreePort(void)
{
#ifndef USING_DPSDK_EXT
	for (int i=MIN_FREE_PORT; i<=MAX_FREE_PORT; i++)
	{
		g_queFreePort.push_back(i);
	}
	g_setFreePort.clear();
#endif

	return 0;
}

int CWndPlayer::GetFreePort(void)
{
	int nPort = -1;

#ifndef USING_DPSDK_EXT
	if (!g_queFreePort.empty())
	{
		nPort = g_queFreePort.front();
		g_queFreePort.pop_front();
		g_setFreePort.insert(nPort);
	}
#endif

	return nPort;
}

int CWndPlayer::RecycleFreePort(int nPort)
{
#ifndef USING_DPSDK_EXT
	if (nPort<MIN_FREE_PORT || nPort>MAX_FREE_PORT)
	{
		return -1;
	}
	std::set<int>::iterator iter = g_setFreePort.find(nPort);
	if (iter != g_setFreePort.end())
	{
		g_setFreePort.erase(iter);
		g_queFreePort.push_front(nPort);
	}
#endif

	return 0;
}

int CWndPlayer::PushMediaData(int nSeq, const char* szData, int nLen)
{
#ifndef USING_DPSDK_EXT
	MediaInfo_t	stuMediaInfo = {0};
	stuMediaInfo.pszMediaData = new char[nLen + 1];
	memcpy(stuMediaInfo.pszMediaData, szData, nLen);
	stuMediaInfo.nDataLen = nLen;

	m_mtxMedia.Lock();
	m_mapMedia[nSeq].push(stuMediaInfo);
	m_mtxMedia.Unlock();
#endif

	return 0;
}

int CWndPlayer::ClearMediaData(int nSeq)
{
#ifndef USING_DPSDK_EXT
	m_mtxMedia.Lock();
	std::map<int, std::queue<MediaInfo_t> >::iterator iter = m_mapMedia.find(nSeq);
	if (iter != m_mapMedia.end())
	{
		while (!(*iter).second.empty())
		{
			const MediaInfo_t* pMediaInfo = &(*iter).second.front();
			delete[] pMediaInfo->pszMediaData;
			(*iter).second.pop();
		}
		m_mapMedia.erase(iter);
	}
	m_mtxMedia.Unlock();
#endif

	return 0;
}

int CWndPlayer::Play(int nSeq, const char* szMediaData, int nDataLen)
{
#ifndef USING_DPSDK_EXT
	std::map<int,PlayerInfo_t>::iterator iter = m_mapPlayer.find(nSeq);
	if (iter == m_mapPlayer.end())
	{
		return -1;
	}

	if ((*iter).second.pVaxPlayer == NULL)
	{
		return -1;
	}

	int nLen = ANA_InputData(m_hStreamHandle, (uint8*)szMediaData, nDataLen);
	if (nDataLen != nLen)
	{
		return -1;
	}

	ANA_FRAME_INFO frame;
	while(ANA_GetMediaFrame(m_hStreamHandle, &frame) == 0)
	{
		if (frame.nType != FRAME_TYPE_UNKNOWN)
		{
			(*iter).second.pVaxPlayer->inputData((unsigned char*)frame.pHeader, frame.nLength);
		}
	}
#endif
	
	return 0;
}

int32_t DPSDK_CALLTYPE CWndPlayer::MediaDataCallback(int32_t nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, char* szData, int32_t nDataLen, void* pUserParam)
{
#ifndef USING_DPSDK_EXT
	// �ص��߳��в��������ݣ����͸����̴߳���
	CWndPlayer* pDlg = (CWndPlayer*)pUserParam;

	pDlg->PushMediaData(nSeq, szData, nDataLen);
	pDlg->PostMessage(WM_MEDIADATA_CB, nSeq, 0);
#endif

	return 0;
}

