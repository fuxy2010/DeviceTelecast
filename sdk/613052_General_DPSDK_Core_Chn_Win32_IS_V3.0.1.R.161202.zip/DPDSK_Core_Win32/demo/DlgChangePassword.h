#pragma once
#include "DPSDK_Core_Error.h"
#include "DPSDK_Core.h"


// CDlgChangePassword �Ի���

class CDlgChangePassword : public CDialog
{
	DECLARE_DYNAMIC(CDlgChangePassword)

public:
	CDlgChangePassword(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgChangePassword();

// �Ի�������
	enum { IDD = IDD_DLG_CHANGE_PASSWORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();

public:
	void SetHandle(int nDLLHandle);

private:
	int32_t m_nDLLHandle;
};
