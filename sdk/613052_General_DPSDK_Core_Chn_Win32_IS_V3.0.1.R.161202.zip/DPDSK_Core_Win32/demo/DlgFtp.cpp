// DlgFtp.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgFtp.h"


// int __stdcall DPSDKGetDPSDKFtpPicCallback(int32_t nPDLLHandle,
// 											Ftp_Pic_Info_t* pFtpPicInfo, 
// 											void* pUserParam )
// {
// 	int nSize = pFtpPicInfo->nSize;
// 
// 	return 0;
// }

// CDlgFtp �Ի���

IMPLEMENT_DYNAMIC(CDlgFtp, CDialog)

CDlgFtp::CDlgFtp(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFtp::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_FTP)
	, m_nDLLHandle(NULL)
	, m_nSeq(-1)
{

}

CDlgFtp::~CDlgFtp()
{
}

void CDlgFtp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_PICTURE_INFO, m_listFtpPic);
}


BEGIN_MESSAGE_MAP(CDlgFtp, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_QUERY_PICTURE, &CDlgFtp::OnBnClickedButtonQueryPicture)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_PICTURE, &CDlgFtp::OnBnClickedButtonDeletePicture)
END_MESSAGE_MAP()


// CDlgFtp ��Ϣ��������

BOOL CDlgFtp::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

	SYSTEMTIME st;
	GetLocalTime(&st);
	CTime tm1(st.wYear, st.wMonth, st.wDay, 0, 0, 0);
	CTime tm2(st.wYear, st.wMonth, st.wDay, 23, 59, 59);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->SetTime(&tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->SetTime(&tm2);

	m_listFtpPic.SetExtendedStyle(m_listFtpPic.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_listFtpPic.InsertColumn(1, _CS(_T("No.")), LVCFMT_CENTER, 50);
	m_listFtpPic.InsertColumn(2, _CS(_T("Device no.")), LVCFMT_CENTER, 130);
	m_listFtpPic.InsertColumn(3, _CS(_T("Channel no.")), LVCFMT_CENTER, 80);
	m_listFtpPic.InsertColumn(4, _CS(_T("Snapshot time")), LVCFMT_CENTER, 130);
	m_listFtpPic.InsertColumn(5, _CS(_T("FTP path")), LVCFMT_CENTER, 250);

	SetDlgItemText(IDC_EDIT_CAMERAID,_T("1000001$1$0$0"));


	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgFtp::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgFtp::OnBnClickedButtonQueryPicture()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	m_listFtpPic.DeleteAllItems();

	CString strCameraId;
	GetDlgItem(IDC_EDIT_CAMERAID)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());

	uint64_t nBeginTime = tmStart.GetTime();
	uint64_t nEndTime = tmEnd.GetTime();

	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryFtpPic(m_nDLLHandle, szCameraId.c_str(), nBeginTime, nEndTime), _CS(_T("Search FTP picture")));

	if(DPSDK_RET_SUCCESS == nRet)
	{
		Ftp_Pic_Info_t ftpPicInfo;
		nRet = ::ShowCallRetInfo(this, DPSDK_GetFtpPicInfo(m_nDLLHandle, ftpPicInfo), _CS(_T("Get FTP picture")));

		if ( DPSDK_RET_SUCCESS == nRet)
		{
			for(int i = 0; i < ftpPicInfo.nSize; i++)
			{
				int nSeq = m_listFtpPic.GetItemCount();
				CString strSeq;
				strSeq.Format(_T("%d"), nSeq+1);
				m_listFtpPic.InsertItem(nSeq, strSeq); // ���

				CMultiToWide wDevID(ftpPicInfo.oneFtpPicInfo[i].szDevId);
				CString strDevID = wDevID.wc_str();
				m_listFtpPic.SetItemText(nSeq, 1, strDevID);// �豸���

				CString strChanNo;
				strChanNo.Format(_T("%d"), ftpPicInfo.oneFtpPicInfo[i].nChlNo);
				m_listFtpPic.SetItemText(nSeq, 2, strChanNo);// ͨ����

				CMultiToWide wCapTime(ftpPicInfo.oneFtpPicInfo[i].szCapTime);
				CString strCapTime = wCapTime.wc_str();
				m_listFtpPic.SetItemText(nSeq, 3, strCapTime);// ץͼʱ��

				CMultiToWide wFtpPath(ftpPicInfo.oneFtpPicInfo[i].szFtpPath);
				CString strFtpPath = wFtpPath.wc_str();
				m_listFtpPic.SetItemText(nSeq, 4, strFtpPath);// ͼƬ����·��
			}
		}
	}	
}

void CDlgFtp::OnBnClickedButtonDeletePicture()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	POSITION pos = m_listFtpPic.GetFirstSelectedItemPosition();
	if (pos != NULL) 
	{
		int nItem = m_listFtpPic.GetNextSelectedItem(pos);

		CString strFtpPath = m_listFtpPic.GetItemText(nItem, 4);
		CWideToUtf8 szFtpPath(strFtpPath.GetString());

		int nRet = ::ShowCallRetInfo(this, DPSDK_DelFtpPic(m_nDLLHandle, szFtpPath.c_str()), _CS(_T("Delete FTP picture")));		
	}

	OnBnClickedButtonQueryPicture();
}

void CDlgFtp::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgFtp::GetWidget() const
{
	return const_cast<CDlgFtp*>(this);
}

CString CDlgFtp::GetTestUIName() const
{
	return _T("FTP operation");//Ftp  FTP operation
}
