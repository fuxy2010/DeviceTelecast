#include "StdAfx.h"
#include "UtilsLogin.h"
#include "DPSDK_Core.h"

CUtilsLogin::CUtilsLogin(void)
{
	SetLoginStatus(LOGIN_STATUS_OFFLINE);
}

CUtilsLogin::~CUtilsLogin(void)
{
}

void CUtilsLogin::Destroy()
{
	
}

void CUtilsLogin::SetLoginStatus(login_status_e eStatus)
{
	m_eLoginStatus = eStatus;
}

login_status_e CUtilsLogin::GetLoginStatus()
{
	return m_eLoginStatus;
}

int CUtilsLogin::Login(CString strIp, CString strPort, CString strUsername, CString strPassword)
{
	CWideToUtf8 szIp(strIp.GetString());
	CWideToUtf8 szPort(strPort.GetString());
	CWideToUtf8 szUsername(strUsername.GetString());
	CWideToUtf8 szPassword(strPassword.GetString());

	Login_Info_t stuLoginInfo = {0};
	strcpy_s(stuLoginInfo.szIp, sizeof(stuLoginInfo.szIp), szIp.c_str());
	stuLoginInfo.nPort = atoi(szPort.c_str());
	strcpy_s(stuLoginInfo.szUsername, sizeof(stuLoginInfo.szUsername), szUsername.c_str());
	strcpy_s(stuLoginInfo.szPassword, sizeof(stuLoginInfo.szPassword), szPassword.c_str());
	stuLoginInfo.nProtocol = DPSDK_PROTOCOL_VERSION_II;
	stuLoginInfo.iType = 2;

	int nRet = DPSDK_Login(m_nDLLHandle, &stuLoginInfo);
	if(nRet == 0)
	{
		SetLoginStatus(LOGIN_STATUS_ONLINE);
		//DPSDK_QueryServerList(m_nDLLHandle);
	}

	return nRet;
}

int CUtilsLogin::Logout()
{
	int nRet = DPSDK_Logout(m_nDLLHandle);

	if(nRet == 0)
	{
		SetLoginStatus(LOGIN_STATUS_OFFLINE);
	}
	return nRet;
}
