#pragma once

#include "UtilsLogin.h"

class CUtilsMain
{
public:
	CUtilsMain(void);
	~CUtilsMain(void);

private:
	static CUtilsMain* m_instance;

public:
	CUtilsLogin        m_LoginUtils;

public:
	static CUtilsMain* GetInstance();
	static void DestroyInstance();

public:
	void Init();
	void Destroy();
	void SetHandle(int nDLLHandle);
};
