#include "StdAfx.h"
#include "UtilsMain.h"

CUtilsMain* CUtilsMain::m_instance = NULL;

CUtilsMain* CUtilsMain::GetInstance()
{
	if(!m_instance)
	{
		m_instance = new CUtilsMain();
		m_instance->Init();
	}
	return m_instance;
}

void CUtilsMain::DestroyInstance()
{
	if(m_instance)
	{
		m_instance->Destroy();
		delete m_instance;
		m_instance = NULL;
	}
}

CUtilsMain::CUtilsMain(void)
{
}

CUtilsMain::~CUtilsMain(void)
{
}

void CUtilsMain::Init()
{

}

void CUtilsMain::Destroy()
{
	m_LoginUtils.Destroy();
}

void CUtilsMain::SetHandle(int nDLLHandle)
{
	m_LoginUtils.SetHandle(nDLLHandle);
}
