#pragma once

#include "../interface/IUtils.h"

typedef enum
{
	LOGIN_STATUS_OFFLINE = 0,  //����
	LOGIN_STATUS_ONLINE,       //����
}login_status_e;

class CUtilsLogin: public IUtils
{
public:
	CUtilsLogin(void);
	~CUtilsLogin(void);

private:
	login_status_e  m_eLoginStatus;

public:
	virtual void Destroy();
	void SetLoginStatus(login_status_e eStatus);
	login_status_e GetLoginStatus();
	int Login(CString strIp, CString strPort, CString strUsername, CString strPassword);
	int Logout();
};
