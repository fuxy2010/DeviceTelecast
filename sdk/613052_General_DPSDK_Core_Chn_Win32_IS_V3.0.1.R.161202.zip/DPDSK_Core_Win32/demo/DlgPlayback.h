#pragma once
#include "DPSDK_Core.h"
#include "WndPlayer.h"
#include "afxcmn.h"
#include "SliderCtrlEx.h"
#include "interface/IAbstractUI.h"

// CDlgPlayback �Ի���

struct RecordInfo
{
	std::string strCameraId;
	int nFileIndex;
	int nSourceType;
	int nRecordType;
	ULONGLONG nBeginTime;
	ULONGLONG nEndTime;
	ULONGLONG nFileLength;
};

struct DownloadRecordInfo
{
	DownloadRecordInfo()
	{
		strCameraId = "";
		strFileName = "";
		fp = NULL;
		nFileLength = 0;
		nDownLength = 0;
		nPos = 0;
		bPlatformByTime = false;
	}
	std::string strCameraId;
	std::string strFileName;
	FILE*		fp;

	ULONGLONG	nFileLength;
	ULONGLONG	nDownLength;

	int         nPos;

	bool		bPlatformByTime;
};

//�ط�����
typedef enum
{
	PLAYBACK_BY_FILE					= 0,					// ���ļ��ط�
	PLAYBACK_BY_TIME					= 1,					// ��ʱ��ط�
}playback_type_e;

class CDlgPlayback : public CDialog,public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgPlayback)

public:
	CDlgPlayback(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPlayback();

	void SetHandle(int nDLLHandle);
	void InsertRecordItem(Single_Record_Info_t* pRecordInfo, int nCount);
	void CloseRecordStreamBySeq(void);
	int DoMediaDataCallback(int nSeq, const char* szData, int nLen);
	static int32_t DPSDK_CALLTYPE MediaDataCallback(int nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, char* szData, int32_t nDataLen, void* pUserParam);


// �Ի�������
	enum { IDD = IDD_DLG_PLAYBACK };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
	LRESULT HandleDownloadRecordComplete(WPARAM wParam, LPARAM lParam);
	LRESULT HandleDownloadRecordProgress(WPARAM wParam, LPARAM lParam);
	ULONGLONG QueryDownloadRecord(LPCTSTR szCameraId, LONG nSourceType, ULONGLONG nBeginTime, ULONGLONG nEndTime, std::deque<RecordInfo>& deqInfo);

	afx_msg void OnBnClickedButtonQueryRecord();
	afx_msg void OnBnClickedButtonPlaybackByFile();
	afx_msg void OnBnClickedButtonPlaybackByTime();
	afx_msg void OnBnClickedButtonPausePlayback();
	afx_msg void OnBnClickedButtonResumePlayback();
	afx_msg void OnBnClickedButtonClosePlayback();
	afx_msg void OnBnClickedButtonCloseCamera();
	afx_msg void OnCbnSelchangeComboSelSpeed();
	afx_msg void OnBnClickedButtonCapture();
	afx_msg void OnBnClickedButtonLoadByFile();
	afx_msg void OnBnClickedButtonStopLoad();
	afx_msg void OnClose();
	
protected:
	static int32_t DPSDK_CALLTYPE MediaDataComplete(int nPDLLHandle, int32_t nSeq, int32_t nMediaType, const char* szNodeId, int32_t nParamVal, void* pUserParam);
	static void WINAPI SetPlayPosCallback(void* pUser,int nPos);

private:
	CWndPlayer	m_dlgWndPlayer;
	int32_t		m_nDLLHandle;
	int32_t		m_nSeq;
	char		nCameraId[DPSDK_CORE_CHL_ID_LEN];
	dpsdk_recsource_type_e szSource;
	uint32_t	FileIndex;

	std::map<int, RecordInfo>				m_mapFileRecord;	// �ļ��طš�����ʹ��(nFileIndex-->RecordInfo)
	std::map<int, std::deque<RecordInfo>>	m_mapTimeRecord;	// ʱ������ʹ��(nSeq-->std::deque<RecordInfo>)
	std::map<int, DownloadRecordInfo>		m_mapDownload;		// ����ʹ��(nSeq-->DownloadRecordInfo)
//	dsl::DMutex	m_mtxDownload;
	CRITICAL_SECTION m_cs;

	CListCtrl m_list;

	playback_type_e m_enPlaybackType;							
public:
	afx_msg void OnBnClickedButtonLoadByTime();
	afx_msg void OnBnClickedButtonPauseLoad();
	afx_msg void OnBnClickedButtonResumeLoad();
	afx_msg void OnBnClickedButtonPlaybackLocal();
	afx_msg void OnBnClickedButtonGetFrameTime();
	afx_msg void OnBnClickedButtonAdjustColor();

	void    CloseWin();
private:
	// ����
	int m_nBrightness;
	// �Աȶ�
	int m_nContrast;
	// ���Ͷ�
	int m_nSaturation;
	// ɫ��
	int m_nHue;

	//�طſ�ʼʱ��
	uint64_t m_nBeginTime;
	//�طŽ���ʱ��
	uint64_t m_nEndTime;

	int m_nTimeLen;

	//����
	int m_nPos;
	int m_nTimePos;
	bool m_bSetPos;

	int m_bLocal;
	int m_nVolPlayback;
public:
	//�طŽ���ֵ
	CSliderCtrlEx m_sliderPlaybackPos;
public:
// 	afx_msg void OnBnClickedButtonPlayOnebyone();
// 	afx_msg void OnBnClickedButtonPlayOnebyoneBack();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	void SetPlaybackPos(int nPos);

public:
	afx_msg void OnBnClickedButtonOpenAudio();
	afx_msg void OnBnClickedButtonCloseAudio();

	afx_msg void OnBnClickedButtonSetVolume();
	afx_msg void OnNMReleasedcaptureSliderPlaybckPos(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedButtonGetVolume();
	afx_msg void OnBnClickedButtonGetColor();
	afx_msg void OnBnClickedBtDownloadMp4();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButtonPlatformRecordForAPeriod();
	afx_msg void OnBnClickedButtonStopPlatformRecord();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnBnClickedButtonStartPlaybackRecord();
	afx_msg void OnBnClickedButtonStopPlaybackRecord();
	afx_msg void OnBnClickedButtonPlaybackOnebyone();
	afx_msg void OnBnClickedButtonPlaybackNormol();
};
