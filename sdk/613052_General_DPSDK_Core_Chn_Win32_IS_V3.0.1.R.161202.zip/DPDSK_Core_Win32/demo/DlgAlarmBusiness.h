#pragma once
#include "afxwin.h"
#include "interface/IAbstractUI.h"

// CAlarmBusiness �Ի���

class CAlarmBusiness : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CAlarmBusiness)

public:
	CAlarmBusiness(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CAlarmBusiness();

// �Ի�������
	enum { IDD = IDD_DLG_AlarmBusiness };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	int32_t m_nDLLHandle;
	DECLARE_MESSAGE_MAP()
public:
	void SetHandle(int nDLLHandle);
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedBtNetalarmhostarm();
	afx_msg void OnBnClickedBtAlarminchannelinfo();
	afx_msg void OnBnClickedBtQuerystatus();
	afx_msg void OnBnClickedSubphonealarm();
	afx_msg void OnBnClickedButton2();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	CComboBox m_ComBox_Armed_Disarmed;
};
