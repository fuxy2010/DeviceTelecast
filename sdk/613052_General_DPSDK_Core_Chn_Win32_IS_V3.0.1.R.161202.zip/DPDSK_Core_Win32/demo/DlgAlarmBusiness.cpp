// AlarmBusiness.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgAlarmBusiness.h"
#include "DPSDK_Core.h"

// CAlarmBusiness �Ի���

IMPLEMENT_DYNAMIC(CAlarmBusiness, CDialog)

CAlarmBusiness::CAlarmBusiness(CWnd* pParent /*=NULL*/)
	: CDialog(CAlarmBusiness::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_ALARM_BUSINESS)
{

}

CAlarmBusiness::~CAlarmBusiness()
{
}

void CAlarmBusiness::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CBox_Armed, m_ComBox_Armed_Disarmed);
}
void CAlarmBusiness::SetHandle( int nDLLHandle )
{
	m_nDLLHandle = nDLLHandle;
}


BEGIN_MESSAGE_MAP(CAlarmBusiness, CDialog)
	ON_BN_CLICKED(IDC_BUTTON1, &CAlarmBusiness::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BT_NetAlarmHostArm, &CAlarmBusiness::OnBnClickedBtNetalarmhostarm)
	ON_BN_CLICKED(IDC_BT_ALARMINCHANNELINFO, &CAlarmBusiness::OnBnClickedBtAlarminchannelinfo)
	ON_BN_CLICKED(IDC_BT_QueryStatus, &CAlarmBusiness::OnBnClickedBtQuerystatus)
	ON_BN_CLICKED(IDC_SubPhoneAlarm, &CAlarmBusiness::OnBnClickedSubphonealarm)
	ON_BN_CLICKED(IDC_BUTTON2, &CAlarmBusiness::OnBnClickedButton2)
END_MESSAGE_MAP()


// CAlarmBusiness ��Ϣ��������

void CAlarmBusiness::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strRecType;
	GetDlgItem(IDC_CBox_Armed)->GetWindowText(strRecType);
	int nOpterType = _ttoi(strRecType.GetString());//1:����;2:����;3:�ڼҲ���;4:�������;5:ͨ����·;6:ȡ����·;7:����
	
	int nRet = ::ShowCallRetInfo(this, DPSDK_ControlVideoAlarmHost(m_nDLLHandle,szCameraId.c_str(),-1,nOpterType), _CS(_T("AlarmHostControl")));

	printf("1");
}

void CAlarmBusiness::OnBnClickedBtNetalarmhostarm()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strRecType;
	GetDlgItem(IDC_CBox_Armed)->GetWindowText(strRecType);
	int nOpterType = _ttoi(strRecType.GetString());//1:����;2:����;3:�ڼҲ���;4:�������;5:ͨ����·;6:ȡ����·;7:����

	int nRet = ::ShowCallRetInfo(this, DPSDK_ControlNetAlarmHostCmd(m_nDLLHandle,szCameraId.c_str(),1,nOpterType,0,0), _CS(_T("AlarmHostControl")));

	printf("1");
}

void CAlarmBusiness::OnBnClickedBtAlarminchannelinfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	Get_AlarmInChannel_Info_t* pAlarmInfo = new Get_AlarmInChannel_Info_t;
	memset(pAlarmInfo,0,sizeof(Get_AlarmInChannel_Info_t));
	strcpy(pAlarmInfo->szDeviceId,szCameraId.c_str());
	pAlarmInfo->nAlarmInChannelCount = 5;
	pAlarmInfo->pAlarmInChannelnfo = new AlarmIn_Channel_Info_t[5];
	memset(pAlarmInfo->pAlarmInChannelnfo,0,sizeof(AlarmIn_Channel_Info_t)*5);

	int nRet = ::ShowCallRetInfo(this, DPSDK_GetAlarmInChannelInfo(m_nDLLHandle,pAlarmInfo), _CS(_T("AlarmHostControl")));

}

void CAlarmBusiness::OnBnClickedBtQuerystatus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	dpsdk_AHostDefenceStatus_t* pStatus = new dpsdk_AHostDefenceStatus_t[17];
	memset(pStatus, 0, sizeof(dpsdk_AHostDefenceStatus_t)*17);

	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryNetAlarmHostStatus(m_nDLLHandle,szCameraId.c_str(), 17, pStatus), _CS(_T("AlarmHostControl")));
	TRACE("");

}

void CAlarmBusiness::OnBnClickedSubphonealarm()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	dpsdk_phone_subscribe_alarm_t temParam;
	memset(&temParam,0,sizeof(dpsdk_phone_subscribe_alarm_t));

	temParam.iUserId = 1;
	temParam.iAppId = 123;
	temParam.iDbOper = 3;
	//temParam.iIs_subscribe = 1;


	strcpy(temParam.szPhoneId, "12345");
	strcpy(temParam.szPush_type,  "2345");
	strcpy(temParam.szLanguage,  "english");
	strcpy(temParam.szTimefmt,  "555555");

	int nRet = ::ShowCallRetInfo(this, DPSDK_PhoneSubscribeAlarm(m_nDLLHandle, temParam), _CS(_T("AlarmHostControl")));
	TRACE("");

}

void CAlarmBusiness::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	dpsdk_phone_subscribe_alarm_t temParam;
	memset(&temParam,0,sizeof(dpsdk_phone_subscribe_alarm_t));

	temParam.iUserId = 2;
	temParam.iAppId = 2;
	temParam.iDbOper = 1;
	//temParam.iIs_subscribe = 1;


	strcpy(temParam.szPhoneId, "2");
	strcpy(temParam.szPush_type,  "2");
	strcpy(temParam.szLanguage,  "2");
	strcpy(temParam.szTimefmt,  "2");

	int nRet = ::ShowCallRetInfo(this, DPSDK_PhoneSubscribeAlarm(m_nDLLHandle, temParam), _CS(_T("AlarmHostControl")));
	TRACE("");

}

void CAlarmBusiness::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CAlarmBusiness::GetWidget() const
{
	return const_cast<CAlarmBusiness*>(this);
}

CString CAlarmBusiness::GetTestUIName() const
{
	return _T("AlarmBusiness");
}
