#pragma once
#include "interface/IAbstractUI.h"

// CDlgBay �Ի���

class CDlgBay : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgBay)

public:
	CDlgBay(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgBay();

// �Ի�������
	enum { IDD = IDD_DIALOG_BAY };
	virtual BOOL OnInitDialog();
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	DECLARE_MESSAGE_MAP()

	 int32_t m_nDLLHandle;

	 char m_szRecordId[128];
public:
	void SetHandle(int nDLLHandle);
	afx_msg void OnBnClickedButtonPicWrite();
	afx_msg void OnBnClickedButtonPicRead();
	afx_msg void OnBnClickedButtonSubFlow();
	afx_msg void OnBnClickedButtonDelSubFlow();
	afx_msg void OnBnClickedButtonSubFlowBay();
	afx_msg void OnBnClickedButtonDelSubFlowBay();
	afx_msg void OnBnClickedButtonSubSpeed();
	afx_msg void OnBnClickedButtonDelSubSpeed();
	afx_msg void OnBnClickedButtonSubSpeed2();
	afx_msg void OnBnClickedButtonDelSubFlowBay2();
	afx_msg void OnBnClickedBtAddAreainfo();

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnBnClickedButtonSwitchDecetion();
};
