#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DPSDK_Core.h"
#include "DPSDK_Core_Error.h"
#include "WndPlayer.h"

int ShowCallRetInfo(CWnd* pWnd, int nRet, CString& strInfo)
{
	CString& strRetInfo = strInfo;

	switch (nRet)
	{
	case DPSDK_RET_SUCCESS:
		strRetInfo += _CS(_T(" Successful"));
		break;
	case DPSDK_RET_SYNC_FAIL:
		strRetInfo += _CS(_T(" Failed"));
		break;
	case DPSDK_CORE_ERROR_TIMEOUT:
		strRetInfo += _CS(_T(" Overtime"));
		break;
	default:
		CString strRet;
		strRet.Format(_CS(_T(" ErrorCode = %d")), nRet);
		strRetInfo += strRet;
	}

	//CWnd* pRetWnd = pWnd->GetDlgItem(IDC_STATIC_RET);
	CWnd* pRetWnd = CTest_DPSDK_CoreDlg::GetInstance()->GetDlgItem(IDC_STATIC_RET);
	if (pRetWnd != NULL)
	{
		pRetWnd->SetWindowText(strRetInfo);
	}

	return nRet;
}

int PrintfText(CString& strInfo)
{
	CWnd* pRetWnd = CTest_DPSDK_CoreDlg::GetInstance()->GetDlgItem(IDC_STATIC_RET);
	if (pRetWnd != NULL)
	{
		pRetWnd->SetWindowText(strInfo);
	}

	return 0;
}

int ShowWndPlayer(CWnd* pWnd, CWndPlayer& pWndPlayer)
{
	CRect rc;
	::GetWindowRect(pWnd->GetDlgItem(IDC_VIDEO)->m_hWnd, rc);//��ȡ��ʾ��Ƶ�ؼ�IDC_VIDEO�Ĵ�С��������һ��ͬ����С�ĶԻ�����CWndPlayer
	pWnd->ScreenToClient(rc);
	pWndPlayer.Create(IDD_DLG_PLAYER, pWnd);
	pWndPlayer.MoveWindow(rc);
	pWndPlayer.ShowWindow(SW_SHOW);

	return 0;
}
