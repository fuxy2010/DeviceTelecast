// DlgtTalk.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgTalk.h"
#include "DPSDK_Core_Define.h"
#include "DPSDK_Ext.h"
#include "DPSDK_Core_Error.h"

// CDlgTalk �Ի���

IMPLEMENT_DYNAMIC(CDlgTalk, CDialog)

CDlgTalk::CDlgTalk(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTalk::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_TALK)
	, m_nDLLHandle(NULL)
	, m_nSeq(-1)
	, bVtCallInvate(false)
	, bAcceptInvite(false)
	, videosession(0)
	, audiosession(0)
{
	memset(&vtCallParam, 0 , sizeof(InviteVtCallParam_t));
}

CDlgTalk::~CDlgTalk()
{
}

void CDlgTalk::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgTalk, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_STOP_TALK_BY_SEQ, &CDlgTalk::OnBnClickedButtonStopTalkBySeq)
	ON_BN_CLICKED(IDC_BUTTON_START_TALK, &CDlgTalk::OnBnClickedButtonStartTalk)
	ON_BN_CLICKED(IDC_BUTTON_STOP_TALK_BY_CAMERAL_ID, &CDlgTalk::OnBnClickedButtonStopTalkByCameralId)
	ON_BN_CLICKED(IDC_BUTTON_START_TALK2, &CDlgTalk::OnBnClickedButtonStartTalk2)
	ON_BN_CLICKED(IDC_BUTTON_REJECT, &CDlgTalk::OnBnClickedButtonReject)
	ON_MESSAGE(WM_INVITE_VT_CALL, &CDlgTalk::OnInviteVtCallMsg)
	ON_BN_CLICKED(IDC_BUTTON_ACCEPT, &CDlgTalk::OnBnClickedButtonAccept)
END_MESSAGE_MAP()


BOOL CDlgTalk::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO_DEVICE_TYPE));
	((CComboBox*)GetDlgItem(IDC_COMBO_AUDIO_TYPE))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_BITS_TYPE))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_SAMPLE_TYPE))->SetCurSel(1);
	((CComboBox*)GetDlgItem(IDC_COMBO_TRANS_TYPE))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_DEVICE_TYPE))->SetCurSel(1);
	SetDlgItemText(IDC_EDIT_CAMERAL_ID,_T("1000033$1$0$0"));

	return TRUE;
}

void CDlgTalk::CloseWin()
{
	OnClose();
}

void CDlgTalk::OnClose()
{
	DPSDK_StopTalkBySeq(m_nDLLHandle,m_nSeq);

	CDialog::OnClose();

}


void CDlgTalk::SetHandle( int nDLLHandle )
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgTalk::OnBnClickedButtonStartTalk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Get_TalkStream_Info_t* pSetInfo = new Get_TalkStream_Info_t;
	CString strCameralId;
	CString strAudioType;
	CString strBitType;
	CString strTransType;
	CString strSampleType;
	CString strDeviceType;
	GetDlgItemText(IDC_EDIT_CAMERAL_ID,strCameralId);
	GetDlgItemText(IDC_COMBO_AUDIO_TYPE,strAudioType);
	GetDlgItemText(IDC_COMBO_BITS_TYPE,strBitType);
	GetDlgItemText(IDC_COMBO_DEVICE_TYPE,strDeviceType);
	GetDlgItemText(IDC_COMBO_SAMPLE_TYPE,strSampleType);
	GetDlgItemText(IDC_COMBO_TRANS_TYPE,strTransType);
	CWideToMulti szCameralID(strCameralId);
	strcpy_s(pSetInfo->szCameraId,64,szCameralID.c_str());
	pSetInfo->nAudioType = (dpsdk_audio_type_e)_ttoi(strAudioType.GetString());
	pSetInfo->nBitsType = (dpsdk_talk_bits_e)_ttoi(strBitType.GetString());
	pSetInfo->nSampleType = (Talk_Sample_Rate_e)_ttoi(strSampleType.GetString());
	pSetInfo->nTalkType = (dpsdk_talk_type_e)_ttoi(strDeviceType.GetString());
	pSetInfo->nTransType = (dpsdk_trans_type_e)_ttoi(strTransType.GetString());

	int nRet = DPSDK_StartTalk(m_nDLLHandle,m_nSeq,pSetInfo);
	::ShowCallRetInfo(this,nRet,_CS(_T("Start talk")));

	delete pSetInfo;
}

void CDlgTalk::OnBnClickedButtonStopTalkBySeq()
{
	int nRet =  ::ShowCallRetInfo(this,DPSDK_StopTalkBySeq(m_nDLLHandle,m_nSeq),_CS(_T("Stop audio talk")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		m_nSeq = -1;
	}
}

void CDlgTalk::OnBnClickedButtonStopTalkByCameralId()
{
 	CString strCameralId;
 	GetDlgItemText(IDC_EDIT_CAMERAL_ID,strCameralId);
 	CWideToMulti szCameralId(strCameralId);
 	 ::ShowCallRetInfo(this,DPSDK_StopTalkByCameraId(m_nDLLHandle,szCameralId.c_str()),_CS(_T("Stop audio talk")));

}

//void CDlgTalk::OnBnClickedButtonSetVolume()
//{
//	CString strVolume;
//	GetDlgItemText(IDC_EDIT_VOLUME,strVolume);
//	CWideToMulti szVolume(strVolume);
//	int nVol = _ttoi(strVolume.GetString());
//
//	::ShowCallRetInfo(this,DPSDK_SetVolume(m_nDLLHandle,m_nSeq,nVol),_CS(_T("Adjust audio")));
//
//	
//}

void CDlgTalk::OnBnClickedButtonStartTalk2()
{
	::ShowCallRetInfo(this, DPSDK_OpenAudio(m_nDLLHandle, m_nSeq,true), _CS(_T("Start audio")));
}

void CDlgTalk::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgTalk::GetWidget() const
{
	return const_cast<CDlgTalk*>(this);
}

CString CDlgTalk::GetTestUIName() const
{
	return _T("Talk");
}

void CDlgTalk::OnBnClickedButtonReject()
{
	if (bVtCallInvate)
	{
		::ShowCallRetInfo(this, DPSDK_SendRejectVtCall(m_nDLLHandle, vtCallParam.szUserId, vtCallParam.callId, vtCallParam.dlgId, vtCallParam.tid, 10*1000), _CS(_T("Reject VtCall Invite")));
		bVtCallInvate = false;
	}
	if(bAcceptInvite && audiosession > 0 && videosession > 0)
	{
		int nRet = DPSDK_StopVtCall(m_nDLLHandle, vtCallParam.szUserId, audiosession, videosession, vtCallParam.callId, vtCallParam.dlgId, 10*1000);
		::ShowCallRetInfo(this, nRet, _CS(_T("Stop VtCall Invite")));
		if (nRet == 0)
		{
			bAcceptInvite = false;
			audiosession = 0;
			videosession = 0;
		}
	}
}

LRESULT CDlgTalk::OnInviteVtCallMsg(WPARAM wParam, LPARAM lParam)
{
	bVtCallInvate = true;
	MessageBox(_T("���ӶԽ���������...."));

	return 0L;
}

int __stdcall fMediaCB( IN int32_t nPDLLHandle,
					   IN int32_t nSeq, 
					   IN int32_t nMediaType, 
					   IN const char* szNodeId, 
					   IN int32_t nParamVal, 
					   IN char* szData, 
					   IN int32_t nDataLen,
					   IN void* pUserParam )
{
	int len = 0;
	len += nDataLen;
	return len;
}

void CDlgTalk::OnBnClickedButtonAccept()
{
	if (bVtCallInvate)
	{
		bVtCallInvate = false;
		int nRet = DPSDK_InviteVtCall(m_nDLLHandle,audiosession,videosession,&vtCallParam,vtCallParam.nCallType, (fMediaDataCallback)fMediaCB, NULL, 10*1000);
		::ShowCallRetInfo(this, nRet, _CS(_T("Accept VtCall Invite")));
		if (nRet == 0)
		{
			bAcceptInvite = true;
		}
	}
	
}
