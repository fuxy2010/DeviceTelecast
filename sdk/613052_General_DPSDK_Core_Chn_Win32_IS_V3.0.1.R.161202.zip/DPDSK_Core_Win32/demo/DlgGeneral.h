#pragma once
#include "DPSDK_Core.h"
#include "interface/IAbstractUI.h"
#include "afxwin.h"
#define DPSDK_FUNC_ENABLE_IVSPCSTAT
// CDlgGeneral �Ի���

class CDlgGeneral : public CDialog, public IAbstractUI
{	
	DECLARE_DYNAMIC(CDlgGeneral)

public:
	CDlgGeneral(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgGeneral();

// �Ի�������
	enum { IDD = IDD_DIALOG_GENERAL };
	int32_t m_nDLLHandle;

protected:
	

	int m_type;
	//static int32_t GetDataCallback( int32_t nPDLLHandle, uint32_t nChangeType, uint32_t nCount, Org_Info_t* pOrgInfo,void* pUserParam );
	
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonSaveOptLog();
	void SetHandle(int nDLLHandle);
	afx_msg void OnBnClickedButtonLoadInfo();
	afx_msg void OnBnClickedButtonGetOrgCount();
	afx_msg void OnBnClickedButtonGetOrgInfo();
	afx_msg void OnBnClickedButtonLoadDepRalation();
	afx_msg void OnBnClickedButtonLoadInfoPerson();
	afx_msg void OnBnClickedButtonLoadPersonCountByDep();
	afx_msg void OnBnClickedButtonLoadInfoPersonByDep();
	afx_msg void OnBnClickedButtonGetChanelId();
	//afx_msg void OnBnClickedButtonLog();
	afx_msg void OnBnClickedButtonLoadChanelInfo();
	afx_msg void OnBnClickedButtonGetPeopleCount();
	afx_msg void OnBnClickedButtonQuerynvrstatus();
	afx_msg void OnBnClickedButtonGeneralSendmsg();
	afx_msg void OnBnClickedButtonGeneralRemoteSnap();
	afx_msg void OnBnClickedButtonTestJson();

	void OnDPSDKGeneralJsonTransportCallback(int32_t nPDLLHandle, const char* szJson);

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnBnClickedBtnQueryBySite();
	afx_msg void OnBnClickedBtnPlatformCurTime();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedBtnLoadDgroupInfoLayered();
	afx_msg void OnBnClickedButtonTimeOpen();
	afx_msg void OnBnClickedButtonTimeClose();
	afx_msg void OnBnClickedBtnReconnnectToCms();
};
