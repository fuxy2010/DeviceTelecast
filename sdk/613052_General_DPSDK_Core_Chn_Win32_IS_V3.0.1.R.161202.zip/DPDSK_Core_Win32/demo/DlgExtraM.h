class CDlgExtraM : public CDialog
{
	DECLARE_DYNAMIC(CDlgExtraM)

public:
	CDlgExtraM(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgExtraM();

	void SetHandle(int nDLLHandle);

	// �Ի�������
	enum { IDD = IDD_DLG_EXTRAM };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()

	afx_msg void OnBnClickedGetOSDTemp();

	//afx_msg LRESULT OnExtraMDataCallback(WPARAM wParam, LPARAM lParam);
private:
	int32_t		m_nDLLHandle;
public:
	afx_msg void OnBnClickedBtnOpetemp();
	afx_msg void OnBnClickedBtnSearchosd();
	afx_msg void OnBnClickedBtnSendosd();
	afx_msg void OnBnClickedBtnSendsms();
};