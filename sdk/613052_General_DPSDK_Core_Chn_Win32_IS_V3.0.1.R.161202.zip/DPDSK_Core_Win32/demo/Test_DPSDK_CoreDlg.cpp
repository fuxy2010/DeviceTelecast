// Test_PlatformDLLDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "Test_DPSDK_CoreDlg.h"
#include "DPSDK_Core_Error.h"
#include <iostream>
#include <fstream>
#include <sstream>


#define  ID_TIMER_LOGIN_SUCCESS  10000


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CTest_DPSDK_CoreDlg* CTest_DPSDK_CoreDlg::m_instance = NULL;

CTest_DPSDK_CoreDlg* CTest_DPSDK_CoreDlg::GetInstance()
{
	return m_instance;
}

// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


int __stdcall DPSDKDeviceChangeCallback(int nPDLLHandle, 
							int nChangeType,
							const char* szDeviceId,
							const char* szDepCode,
							const char* szNewDepCode, 
							void* pUserParam )
{


	CTest_DPSDK_CoreDlg* pDlg = (CTest_DPSDK_CoreDlg*)pUserParam;
	device_change_info_t* pChangeInfo = new device_change_info_t;
	memset(pChangeInfo, 0, sizeof(device_change_info_t));

	pChangeInfo->changeType = (dpsdk_change_type_e)nChangeType;
	memcpy(pChangeInfo->szDevId, szDeviceId, strlen(szDeviceId));
	memcpy(pChangeInfo->szDepCode, szDepCode, strlen(szDepCode));
	memcpy(pChangeInfo->szNewDepCode, szNewDepCode, strlen(szNewDepCode));

	pDlg->m_dlgDGroup.PostMessage(WM_DEVICE_CHANGE, (WPARAM)pChangeInfo);

	return 0;
}

int __stdcall DPSDKOrgDevChangeNewCallback(int nPDLLHandle, 
										 int nOrgChangeType,
										 void* pUserParam )
{
	CTest_DPSDK_CoreDlg* pDlg = (CTest_DPSDK_CoreDlg*)pUserParam;
	/*org_dev_change_info_t* pChangeInfo = new org_dev_change_info_t;
	memset(pChangeInfo, 0, sizeof(org_dev_change_info_t));
	pChangeInfo->orgchangetype = (dpsdk_org_change_type_e)nOrgChangeType;
	pDlg->PostMessage(WM_ORG_DEV_CHANGE, (WPARAM)pChangeInfo);*/

	return 0;
}

int __stdcall DPSDKDeviceStatusCallback(IN int32_t nPDLLHandle, 
										IN const char* szDeviceId,
										IN int32_t nStatus, 
										IN void* pUserParam )
{
	//��ʱ�ò����������õ�ʱ����ע�ͼ����á�
	CTest_DPSDK_CoreDlg* pDlg = (CTest_DPSDK_CoreDlg*)pUserParam;
	device_status_info_t* pStatusInfo = new device_status_info_t;
	memset(pStatusInfo, 0, sizeof(device_status_info_t));

	pStatusInfo->statusType = (dpsdk_device_status_type_e)nStatus;
	strncpy(pStatusInfo->szDevId,szDeviceId,sizeof(pStatusInfo->szDevId)-1);
	
	pDlg->PostMessage(WM_DEVICE_STATUS, (WPARAM)pStatusInfo);
	TRACE("Device Status Changed!\n");
	return 0;
}

int __stdcall DPSDKNVRChnlStatusCallback(IN int32_t nPDLLHandle, 
										IN const char* szDeviceId,
										IN int32_t nStatus, 
										IN void* pUserParam )
{
	//��ʱ�ò����������õ�ʱ����ע�ͼ����á�
// 	CTest_PlatformDLLDlg* pDlg = (CTest_PlatformDLLDlg*)pUserParam;
// 	chnl_status_info_t* pStatusInfo = new chnl_status_info_t;
// 	memset(pStatusInfo, 0, sizeof(chnl_status_info_t));
// 
// 	pStatusInfo->statusType = (dpsdk_device_status_type_e)nStatus;
// 	strncpy(pStatusInfo->szChnlId,szDeviceId,sizeof(pStatusInfo->szChnlId)-1);
// 	
// 	pDlg->PostMessage(WM_NVRCHNL_STATUS, (WPARAM)pStatusInfo);

	return 0;
}

int __stdcall DPSDKStatusCallback(IN int32_t nPDLLHandle, 
								  IN int32_t nStatus, 
								  IN void* pUserParam )
{
	//��ʱ�ò���������
	
    CTest_DPSDK_CoreDlg* pDlg = (CTest_DPSDK_CoreDlg*)pUserParam;
	pDlg->PostMessage(WM_STATUS, (WPARAM)nStatus);

	return 0;
}

int __stdcall DPSDKTrafficAlarmCallback(IN int32_t nPDLLHandle, 
										IN Traffic_Alarm_Info_t* pRetInfo, 
										IN void* pUserParam)
{
	Traffic_Alarm_Info_t* pRetInfo1 = new Traffic_Alarm_Info_t();
	memcpy(pRetInfo1,pRetInfo,sizeof(Traffic_Alarm_Info_t));

	FILE *fp = fopen("D:\\BayTrafficAlarmInfo.txt", "a+b");
	if (fp)
	{
		CUtf8ToWide	szCarNum(pRetInfo1->szCarNum);
		CWideToMulti szCarNumM(szCarNum.wc_str());//������������
		CUtf8ToWide	szImg0Path(pRetInfo1->szPicUrl[0]);
		CWideToMulti Img0Path(szImg0Path.wc_str());//������������
		CUtf8ToWide	szImg1Path(pRetInfo1->szPicUrl[1]);
		CWideToMulti Img1Path(szImg1Path.wc_str());//������������
		CUtf8ToWide	szImg2Path(pRetInfo1->szPicUrl[2]);
		CWideToMulti Img2Path(szImg2Path.wc_str());//������������
		CUtf8ToWide	szImg3Path(pRetInfo1->szPicUrl[3]);
		CWideToMulti Img3Path(szImg3Path.wc_str());//������������
		CUtf8ToWide	szImg4Path(pRetInfo1->szPicUrl[4]);
		CWideToMulti Img4Path(szImg4Path.wc_str());//������������
		CUtf8ToWide	szImg5Path(pRetInfo1->szPicUrl[5]);
		CWideToMulti Img5Path(szImg5Path.wc_str());//������������
		CUtf8ToWide	szDeviceName(pRetInfo1->szDeviceName);
		CWideToMulti DeviceName(szDeviceName.wc_str());//������������
		CUtf8ToWide	szDeviceChnName(pRetInfo1->szDeviceChnName);
		CWideToMulti DeviceChnName(szDeviceChnName.wc_str());//������������
		fprintf(fp, "Υ������ %d\n", pRetInfo1->type);
		fprintf(fp, "ͨ��ID %s\n", pRetInfo1->szCameraId);
		fprintf(fp, "�豸ID %s\n", pRetInfo1->szDeviceId);
		fprintf(fp, "�豸���� %s\n", DeviceName.c_str());
		fprintf(fp, "ͨ������ %s\n", DeviceChnName.c_str());
		fprintf(fp, "���� %s\n", szCarNumM.c_str());
		fprintf(fp, "PTS����ip %s\n", pRetInfo1->nPtsIp);
		fprintf(fp, "PTS����port %d\n", pRetInfo1->nPicPort);
		fprintf(fp, "PTS����ip %s\n", pRetInfo1->nPtsIpy);
		fprintf(fp, "PTS����port %d\n", pRetInfo1->nPicPorty);
		fprintf(fp, "ͼƬURL1 %s\n", Img0Path.c_str());
		fprintf(fp, "ͼƬURL2 %s\n", Img1Path.c_str());
		fprintf(fp, "ͼƬURL3 %s\n", Img2Path.c_str());
		fprintf(fp, "ͼƬURL4 %s\n", Img3Path.c_str());
		fprintf(fp, "ͼƬURL5 %s\n", Img4Path.c_str());
		fprintf(fp, "ͼƬURL6 %s\n", Img5Path.c_str());

		fclose(fp);
	}

	delete pRetInfo1;

	return 0;
}
int __stdcall DPSDKGetBayCarInfoCallback(IN int32_t nPDLLHandle, 
										 IN Bay_Car_Info_t* pRetInfo, 
										 IN void* pUserParam)
{
	Bay_Car_Info_t* pRetInfo1 = new Bay_Car_Info_t;
	memcpy(pRetInfo1,pRetInfo,sizeof(Bay_Car_Info_t));

	FILE *fp = fopen("D:\\BayCarInfo.txt", "a+b");
	if (fp)
	{
		CUtf8ToWide	szCarNum(pRetInfo1->szCarNum);
		CWideToMulti szCarNumM(szCarNum.wc_str());//������������
		CUtf8ToWide	szImg0Path(pRetInfo1->szImg0Path);
		CWideToMulti Img0Path(szImg0Path.wc_str());//������������
		CUtf8ToWide	szImg1Path(pRetInfo1->szImg1Path);
		CWideToMulti Img1Path(szImg1Path.wc_str());//������������
		CUtf8ToWide	szImg2Path(pRetInfo1->szImg2Path);
		CWideToMulti Img2Path(szImg2Path.wc_str());//������������
		CUtf8ToWide	szImg3Path(pRetInfo1->szImg3Path);
		CWideToMulti Img3Path(szImg3Path.wc_str());//������������
		CUtf8ToWide	szImg4Path(pRetInfo1->szImg4Path);
		CWideToMulti Img4Path(szImg4Path.wc_str());//������������
		CUtf8ToWide	szImg5Path(pRetInfo1->szImg5Path);
		CWideToMulti Img5Path(szImg5Path.wc_str());//������������
		CUtf8ToWide	szImgPlatePath(pRetInfo1->szImgPlatePath);
		CWideToMulti ImgPlatePath(szImgPlatePath.wc_str());//������������
		fprintf(fp, "ͨ���� %d\n", pRetInfo1->nDevChnId);
		fprintf(fp, "ͨ��ID %s\n", pRetInfo1->szChannelId);
		fprintf(fp, "���� %s\n", szCarNumM.c_str());
		fprintf(fp, "ץ��ʱ�� %d\n", pRetInfo1->lCaptureTime);	
		fprintf(fp, "ͼƬURL1 %s\n", Img0Path.c_str());
		fprintf(fp, "ͼƬURL2 %s\n", Img1Path.c_str());
		fprintf(fp, "ͼƬURL3 %s\n", Img2Path.c_str());
		fprintf(fp, "ͼƬURL4 %s\n", Img3Path.c_str());
		fprintf(fp, "ͼƬURL5 %s\n", Img4Path.c_str());
		fprintf(fp, "ͼƬURL6 %s\n", Img5Path.c_str());
		fprintf(fp, "С����ͼƬURL %s\n", ImgPlatePath.c_str());
		
		fclose(fp);
	}

	delete pRetInfo1;

	return 0;

}

int __stdcall DPSDKGetBayCarInfoCallbackEx(int32_t nPDLLHandle,
										   const char*	szDeviceId,
										   int32_t	nDeviceIdLen,
										   int32_t	nDevChnId,
										   const char* szChannelId,
										   int32_t nChannelIdLen,
										   const char*	szDeviceName,
										   int32_t	nDeviceNameLen,
										   const char*	szDeviceChnName,
										   int32_t	nChanNameLen,
										   const char*	szCarNum,
										   int32_t nCarNumLen,
										   int32_t	nCarNumType,
										   int32_t	nCarNumColor,
										   int32_t	nCarSpeed,
										   int32_t	nCarType,
										   int32_t	nCarColor,
										   int32_t	nCarLen,
										   int32_t	nCarDirect,
										   int32_t	nWayId,
										   uint64_t	lCaptureTime,
										   unsigned long	lPicGroupStoreID,
										   int32_t	nIsNeedStore,
										   int32_t	nIsStoraged,
										   const char*	szCaptureOrg,
										   int32_t	nCaptureOrgLen,
										   const char*	szOptOrg,
										   int32_t	nOptOrgLen,
										   const char*	szOptUser,
										   int32_t	nOptUserLen,
										   const char*	szOptNote,
										   int32_t	nOptNoteLen,
										   const char*	szImg0Path,
										   int32_t	nImg0PathLen,
										   const char*	szImg1Path,
										   int32_t	nImg1PathLen,
										   const char*	szImg2Path,
										   int32_t	nImg2PathLen,
										   const char*	szImg3Path,
										   int32_t	nImg3PathLen,
										   const char*	szImg4Path,
										   int32_t	nImg4PathLen,
										   const char*	szImg5Path,
										   int32_t	nImg5PathLen,
										   const char*	szImgPlatePath,
										   int32_t	nImgPlatePathLen,
										   int32_t	icarLog,
										   int32_t	iPlateLeft,
										   int32_t	iPlateRight,
										   int32_t	iPlateTop,
										   int32_t	iPlateBottom, 
										   void* pUserParam )
{
	FILE *fp = fopen("D:\\BayCarInfo.txt", "a+b");
	if (fp)
	{
		CUtf8ToWide	szCarNum(szCarNum);
		CWideToMulti szCarNumM(szCarNum.wc_str());//������������
		CUtf8ToWide	szImg0Path(szImg0Path);
		CWideToMulti Img0Path(szImg0Path.wc_str());//������������
		CUtf8ToWide	szImg1Path(szImg1Path);
		CWideToMulti Img1Path(szImg1Path.wc_str());//������������
		CUtf8ToWide	szImg2Path(szImg2Path);
		CWideToMulti Img2Path(szImg2Path.wc_str());//������������
		CUtf8ToWide	szImg3Path(szImg3Path);
		CWideToMulti Img3Path(szImg3Path.wc_str());//������������
		CUtf8ToWide	szImg4Path(szImg4Path);
		CWideToMulti Img4Path(szImg4Path.wc_str());//������������
		CUtf8ToWide	szImg5Path(szImg5Path);
		CWideToMulti Img5Path(szImg5Path.wc_str());//������������
		CUtf8ToWide	szImgPlatePath(szImgPlatePath);
		CWideToMulti ImgPlatePath(szImgPlatePath.wc_str());//������������
		fprintf(fp, "ͨ���� %d\n", nDevChnId);
		fprintf(fp, "ͨ��ID %s\n", szChannelId);
		fprintf(fp, "���� %s\n", szCarNumM.c_str());
		fprintf(fp, "ץ��ʱ�� %d\n", lCaptureTime);	
		fprintf(fp, "ͼƬURL1 %s\n", Img0Path.c_str());
		fprintf(fp, "ͼƬURL2 %s\n", Img1Path.c_str());
		fprintf(fp, "ͼƬURL3 %s\n", Img2Path.c_str());
		fprintf(fp, "ͼƬURL4 %s\n", Img3Path.c_str());
		fprintf(fp, "ͼƬURL5 %s\n", Img4Path.c_str());
		fprintf(fp, "ͼƬURL6 %s\n", Img5Path.c_str());
		fprintf(fp, "С����ͼƬURL %s\n", ImgPlatePath.c_str());

		fclose(fp);
	}

	return 0;
}

int __stdcall DPSDKGetTrafficFlowCallback(IN int32_t nPDLLHandle, 
										  IN TrafficFlow_Info_t* pRetInfo,
										  IN void* pUserParam)
{
	TrafficFlow_Info_t* pRetInfo1 = new TrafficFlow_Info_t;
	memcpy(pRetInfo1,pRetInfo,sizeof(TrafficFlow_Info_t));


	delete pRetInfo1;
	return 0;

}

int __stdcall DPSDKGetDevTrafficFlowCallback(IN int32_t nPDLLHandle, 
										  IN TrafficFlow_Info_t* pRetInfo,
										  IN void* pUserParam)
{
	TrafficFlow_Lane_State* pRetInfo1 = new TrafficFlow_Lane_State;
	memcpy(pRetInfo1,pRetInfo,sizeof(TrafficFlow_Lane_State));

	delete pRetInfo1;
	return 0;

}

int __stdcall DPSDKGetDPSDKIssueCallback(int32_t nPDLLHandle, 
										 Issue_Info_t* pIssueInfo,
										 void* pUserParam)
{
	int nSize = pIssueInfo->nSize;

	return 0;
}


int __stdcall DPSDKBayWantedAlarmCallback(IN int32_t nPDLLHandle, 
										  IN Bay_WantedAlarm_Info_t* pRetInfo, 
										  IN void* pUserParam)
{
	if (NULL == pRetInfo)
	{
		return -1;
	}

	FILE *fp = fopen("BayWantedAlarm.txt", "a+b");
	if (fp)
	{
		fprintf(fp, "�յ����ظ澯��Ϣ\n");
		fprintf(fp, "ͨ��ID %s\n", pRetInfo->szCameraId);
		fprintf(fp, "���� %s\n", pRetInfo->szCarNum);
		fprintf(fp, "����ʱ�� %d\n", pRetInfo->ulAlarmTime);
		fprintf(fp, "���̵�״̬ %d\n", pRetInfo->nLightColor);
		fprintf(fp, "ʱ��� %d\n", time(NULL));
		fclose(fp);
	}

	return 0;
}

int __stdcall DPSDKTalkParamCallback(IN int32_t nPDLLHandle, 
									 IN dpsdk_talk_type_e nTalkType,
									 IN dpsdk_audio_type_e nAudioType, 
									 IN dpsdk_talk_bits_e nAudioBit,
									 IN Talk_Sample_Rate_e nSampleRate, 
									 IN dpsdk_trans_type_e nTransMode,
									 IN void* pUserParam)
{

	CString strParam;
	strParam.Format(_T("audioBit=%d,audioType=%d,sampleRate=%d"),nAudioBit,nAudioType,nSampleRate);

	AfxMessageBox(strParam);
	//MessageBox(NULL,"","",MB_OK);
	//FILE *fp = fopen("TalkParam.txt", "a+b");
	//if (fp)
	//{
	//	//fprintf(fp, "�յ����ظ澯��Ϣ\n");
	//	//fprintf(fp, "ͨ��ID %s\n", pTalkParam);
	//	//fprintf(fp, "���� %s\n", pTalkParam->szCarNum);
	//	//fprintf(fp, "����ʱ�� %d\n", pTalkParam->ulAlarmTime);
	//	//fprintf(fp, "���̵�״̬ %d\n", pTalkParam->nLightColor);
	//	//fprintf(fp, "ʱ��� %d\n", time(NULL));
	//	fclose(fp);
	//}

	return 0;
}

int __stdcall DPSDKVideoAlarmHostStatusCallback(  IN int32_t nPDLLHandle,
												IN char*   szDeviceId,
												IN int32_t nChannelNO, 
												IN int32_t nStatus,
												IN void* pUserParam )
{

	CString strParam;
	strParam.Format(_T("szDeviceId=%s,nChannelNO=%d,nStatus=%d"),szDeviceId,nChannelNO,nStatus);

	//AfxMessageBox(strParam);
	return 0;
}

int __stdcall DPSDKNetAlarmHostStatusCallback(  IN int32_t nPDLLHandle,
												IN char*   szDeviceId,
												IN int32_t nRtype, 
												IN int32_t nOperType,
												IN int32_t nStatus,
												IN void* pUserParam )
{

	CString strParam;
	strParam.Format(_T("audioBit=%s,nRtype=%d,nOperType=%d,nStatus=%d"),szDeviceId,nRtype,nOperType,nStatus);

	AfxMessageBox(strParam);

	return 0;
}

int __stdcall DPSDKPtzSitAlarmCallback(int32_t nPDLLHandle, Ptz_Sit_Alarm_Info* pRetInfo, void* pUserParam)
{
	CTest_DPSDK_CoreDlg* pDlg = (CTest_DPSDK_CoreDlg*)pUserParam;
	if(pDlg)
	{

	}
	return 0;
}

int __stdcall DPSDKInviteVtCallParamCallBack(int32_t nPDLLHandle, InviteVtCallParam_t* param, void* pUserParam)
{
	CDlgTalk* pDlg = (CDlgTalk*)pUserParam;
	if(pDlg)
	{
		memcpy(&(pDlg->vtCallParam), param, sizeof(InviteVtCallParam_t));
		pDlg->PostMessage(WM_INVITE_VT_CALL, (WPARAM)param);
	}
	return 0;
}

int __stdcall DPSDKChannelViewInfoCallback(int32_t nPDLLHandle, const char* szCamearId, int nDistance, int nAngelH, int nAzimuthH, int nInclinationH, void* pUserParam)
{
	int angle = nAngelH;
	int Distance = nDistance;
	int AzimuthH = nAzimuthH;
	int nInclination = nInclinationH;
	std::string CameraID = szCamearId;
	return 0;
}

LRESULT CTest_DPSDK_CoreDlg::OnDeviceStatusCallback( WPARAM wParam, LPARAM lParam )
{
    device_status_info_t* pStatusInfo  = (device_status_info_t*)wParam;
	CString strDeviceStatus;
	CString strId(pStatusInfo->szDevId);

	if(DPSDK_CORE_DEVICE_STATUS_ONLINE == pStatusInfo->statusType)
	{
		CString strStatus(_CS(_T("Device online!")));
		strDeviceStatus.Format(_CS(_T("Device:%s, Status:%s")),strId ,strStatus);
	}
	else
	{
		CString strStatus(_CS(_T("Device offline!")));
		strDeviceStatus.Format(_CS(_T("Device:%s, Status:%s")),strId ,strStatus);
	}
	
	//SetDlgItemText(IDC_STATIC_RET,strDeviceStatus);
	PrintfText(strDeviceStatus);
	Invalidate(TRUE);
	return S_OK;
}

LRESULT CTest_DPSDK_CoreDlg::OnDpsdkStatusCallback( WPARAM wParam, LPARAM lParam )
{

	dpsdk_status_type_e status = (dpsdk_status_type_e)wParam;
	CString strStatus;

	if(status == DPSDK_CORE_STATUS_SERVER_ONLINE)
	{
		strStatus = _CS(_T("Server online!"));     
	}
	else
	{
		strStatus = _CS(_T("Server offline!"));
	}

	//SetDlgItemText(IDC_STATIC_RET,strStatus);
	PrintfText(strStatus);
	m_nGroupInfoLen = 0;
	int nRet = ::ShowCallRetInfo(this, DPSDK_LoadDGroupInfo(m_nDLLHandle, m_nGroupInfoLen, 1000*180), _CS(_T("Load organization structure")));
	return S_OK;

}

LRESULT CTest_DPSDK_CoreDlg::OnOrgDevChangeCallback( WPARAM wParam, LPARAM lParam )
{
	org_dev_change_info_t* pChangeInfo = (org_dev_change_info_t*) wParam;
	if(pChangeInfo)
	{
		OnBnClickedButtonLoadAllGroup();
		delete pChangeInfo;
	}
	return 1L;
}

// CTest_PlatformDLLDlg �Ի���
CTest_DPSDK_CoreDlg::CTest_DPSDK_CoreDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTest_DPSDK_CoreDlg::IDD, pParent)
	, m_nDLLHandle(NULL)
	, m_nGroupInfoLen(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_instance = this;
}

void CTest_DPSDK_CoreDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTest_DPSDK_CoreDlg, CDialog)
	//}}AFX_MSG_MAP
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_LOADALLGROUP, &CTest_DPSDK_CoreDlg::OnBnClickedButtonLoadAllGroup)
	ON_BN_CLICKED(IDC_BUTTON_GET_GROUP_STRING, &CTest_DPSDK_CoreDlg::OnBnClickedButtonGetGroupString)	
	
	ON_MESSAGE(WM_DEVICE_STATUS,OnDeviceStatusCallback)
	ON_MESSAGE(WM_STATUS,OnDpsdkStatusCallback)
	ON_MESSAGE(WM_LOGIN_SUCCESS,OnMsgLoginSuccess)
	ON_MESSAGE(WM_ORG_DEV_CHANGE,OnOrgDevChangeCallback)
	ON_MESSAGE(WM_MOD_TRANS_MSG, OnModTransMsg)
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(IDC_COMBO1, &CTest_DPSDK_CoreDlg::OnCbnSelchangeCombo1)
	ON_BN_CLICKED(IDC_BTN_GENERAL2, &CTest_DPSDK_CoreDlg::OnBnClickedBtnGeneral2)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE_PASSWORD, &CTest_DPSDK_CoreDlg::OnBnClickedButtonChangePassword)
	ON_BN_CLICKED(IDC_BUTTON_SetLog, &CTest_DPSDK_CoreDlg::OnBnClickedButtonSetlog)
	ON_BN_CLICKED(IDC_BUTTON1, &CTest_DPSDK_CoreDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BT_TestJson, &CTest_DPSDK_CoreDlg::OnBnClickedBtTestjson)
	ON_BN_CLICKED(IDC_BT_GetUserInfo, &CTest_DPSDK_CoreDlg::OnBnClickedBtGetuserinfo)
	ON_BN_CLICKED(IDC_BUTTON2, &CTest_DPSDK_CoreDlg::OnBnClickedButton2)
	ON_WM_SYSCOMMAND()
	ON_WM_SIZE()
	ON_COMMAND(IDC_MENU_LOAD_OS, &CTest_DPSDK_CoreDlg::OnMenuLoadOs)
	ON_COMMAND(ID_MENU_GET_OS, &CTest_DPSDK_CoreDlg::OnMenuGetOs)
	ON_COMMAND(IDC_MENU_MODIFY_PW, &CTest_DPSDK_CoreDlg::OnMenuModifyPw)
	ON_COMMAND(IDC_MENU_SET_LOG, &CTest_DPSDK_CoreDlg::OnMenuSetLog)
	ON_COMMAND(IDC_DMS_GET_PIC, &CTest_DPSDK_CoreDlg::OnDmsGetPic)
	ON_COMMAND(IDC_MENU_GET_BY_CWH, &CTest_DPSDK_CoreDlg::OnMenuGetByCwh)
	ON_COMMAND(IDC_MENU_STRTOBINARY, &CTest_DPSDK_CoreDlg::OnMenuStrtobinary)
	ON_BN_CLICKED(IDC_CHECK_Compressed, &CTest_DPSDK_CoreDlg::OnBnClickedCheckCompressed)
	ON_COMMAND(IDM_SYS_MENU_LOGIN, &CTest_DPSDK_CoreDlg::OnMenuLogin)
	ON_WM_TIMER()
END_MESSAGE_MAP()

// CTest_PlatformDLLDlg ��Ϣ��������
BOOL CTest_DPSDK_CoreDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO1));

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}

		/*CString strMenu;
		strMenu.LoadString(IDS_MENU_LOGIN);
		if (!strMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_SYS_MENU_LOGIN, strMenu);
		}*/
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������


	_CMenuCS(this);

	SetWindowPos(NULL,0,0,LAYOUT_CLIENT_WIDTH,LAYOUT_CLIENT_HEIGHT,SWP_NOZORDER|SWP_NOMOVE);

	CUtilsMain::GetInstance()->SetHandle(m_nDLLHandle);

	m_dlgDGroup.Create(IDD_DLG_DGROUP, this);
	m_dlgDGroup.SetHandle(m_nDLLHandle);
	m_dlgDGroup.SetWindowPos(NULL,LAYOUT_DGROUP_POSX,LAYOUT_DGROUP_POSY,LAYOUT_DGROUP_WIDTH,LAYOUT_DGROUP_HEIGHT,SWP_NOZORDER);
	m_dlgDGroup.ShowWindow(SW_SHOW);

	((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);

	m_dlgChangePassword.Create(IDD_DLG_CHANGE_PASSWORD,this);
	m_dlgChangePassword.SetHandle(m_nDLLHandle);
	
	((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);

	m_dlgTab.Create(IDD_DLG_TAB,this);
	m_dlgTab.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_TAB_HEIGHT,SWP_NOZORDER);
	m_dlgTab.ShowWindow(SW_SHOW);

	m_dlgReal.Create(IDD_DLG_REAL, this);
	m_dlgReal.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgReal);
	m_dlgReal.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	//m_dlgPtz.Create(IDD_DLG_PTZ, this);
	m_dlgReal.m_dlgPtz.SetHandle(m_nDLLHandle);
	//m_dlgTab.AppendItem(&m_dlgPtz);
	//m_dlgPtz.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgPlayback.Create(IDD_DLG_PLAYBACK, this);
	m_dlgPlayback.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgPlayback);
	m_dlgPlayback.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgAlarm.Create(IDD_DLG_ALARM, this);
	m_dlgAlarm.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgAlarm);
	m_dlgAlarm.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgTalk.Create(IDD_DLG_TALK,this);
	m_dlgTalk.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgTalk);
	m_dlgTalk.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgTvWall.Create(IDD_DLG_TVWALL, this);
	m_dlgTvWall.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgTvWall);
	m_dlgTvWall.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgGeneral.Create(IDD_DIALOG_GENERAL,this);
	m_dlgGeneral.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgGeneral);
	m_dlgGeneral.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgBay.Create(IDD_DIALOG_BAY,this);
	m_dlgBay.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgBay);
	m_dlgBay.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);
	
	m_dlgFtp.Create(IDD_DLG_FTP,this);
	m_dlgFtp.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgFtp);
	m_dlgFtp.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgAlarmBusiness.Create(IDD_DLG_AlarmBusiness,this);
	m_dlgAlarmBusiness.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgAlarmBusiness);
	m_dlgAlarmBusiness.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgIntelligent.Create(IDD_DLG_INTELLIGENT,this);
	m_dlgIntelligent.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgIntelligent);
	m_dlgIntelligent.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);
	
	m_dlgPrison.Create(IDD_DLG_PRISON, this);
	m_dlgPrison.SetHandle(m_nDLLHandle);
	m_dlgTab.AppendItem(&m_dlgPrison);
	m_dlgPrison.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY+LAYOUT_TAB_HEIGHT,LAYOUT_CLIENT_WIDTH - LAYOUT_TAB_POSX - 18,LAYOUT_FUN_HEIGHT,SWP_NOZORDER);

	m_dlgTab.SetCurSel(0);


	DPSDK_SetDPSDKDeviceChangeCallback(m_nDLLHandle, (fDPSDKDeviceChangeCallback)DPSDKDeviceChangeCallback, this);
	DPSDK_SetDPSDKDeviceStatusCallback(m_nDLLHandle,(fDPSDKDevStatusCallback)DPSDKDeviceStatusCallback,this);
	DPSDK_SetDPSDKNVRChnlStatusCallback(m_nDLLHandle,(fDPSDKNVRChnlStatusCallback)DPSDKNVRChnlStatusCallback,this);
    DPSDK_SetDPSDKStatusCallback(m_nDLLHandle,(fDPSDKStatusCallback)DPSDKStatusCallback,this);
	DPSDK_SetDPSDKGetTrafficFlowCallback(m_nDLLHandle,(fDPSDKGetTrafficFlowCallback)DPSDKGetTrafficFlowCallback,this);
	DPSDK_SetDPSDKGetDevTrafficFlowCallback(m_nDLLHandle,(fDPSDKGetDevTrafficFlowCallback)DPSDKGetDevTrafficFlowCallback,this);
	DPSDK_SetDPSDKTrafficAlarmCallback(m_nDLLHandle,(fDPSDKTrafficAlarmCallback)DPSDKTrafficAlarmCallback,this);
	//DPSDK_SetDPSDKGetBayCarInfoCallback(m_nDLLHandle,(fDPSDKGetBayCarInfoCallback)DPSDKGetBayCarInfoCallback,this);
	DPSDK_SetDPSDKGetBayCarInfoCallbackEx(m_nDLLHandle,(fDPSDKGetBayCarInfoCallbackEx)DPSDKGetBayCarInfoCallbackEx,this);
	DPSDK_SetDPSDKIssueCallback(m_nDLLHandle, (fDPSDKIssueCallback)DPSDKGetDPSDKIssueCallback, this);
	DPSDK_SetDPSDKTalkParamCallback(m_nDLLHandle,(fDPSDKTalkParamCallback)DPSDKTalkParamCallback,this);
	DPSDK_SetVideoAlarmHostStatusCallback(m_nDLLHandle, (fDPSDKVideoAlarmHostStatusCallback)DPSDKVideoAlarmHostStatusCallback,this);
	DPSDK_SetNetAlarmHostStatusCallback(m_nDLLHandle, (fDPSDKNetAlarmHostStatusCallback)DPSDKNetAlarmHostStatusCallback,this);
	DPSDK_SetDPSDKPtzSitAlarmInfoCallback(m_nDLLHandle, (fDPSDKPtzSitAlarmInfoCallback)DPSDKPtzSitAlarmCallback, this);
	DPSDK_SetVtCallInviteCallback(m_nDLLHandle, (fDPSDKInviteVtCallParamCallBack)DPSDKInviteVtCallParamCallBack, &m_dlgTalk);
	DPSDK_SetChannelViewInfoCallback(m_nDLLHandle, (fDPSDKChannelViewInfoCallback)DPSDKChannelViewInfoCallback, this);

	//DPSDK_SetDPSDKOrgDevChangeNewCallback(m_nDLLHandle, (fDPSDKOrgDevChangeNewCallback)DPSDKOrgDevChangeNewCallback,this);
	
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

int CTest_DPSDK_CoreDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  �ڴ�������ר�õĴ�������
	int nRet = ::ShowCallRetInfo(this, DPSDK_Create(DPSDK_CORE_SDK_SERVER, m_nDLLHandle), _CS(_T("Create DPSDK_Core")));
	if (nRet != DPSDK_RET_SUCCESS)
	{
		return -1;
	}

	/*DPSDKParam_t pDPSDKParam;
	memset(pDPSDKParam.szUserIdFlag, 0, sizeof(pDPSDKParam.szUserIdFlag));
	std::string strUserIdFlag = "172.7.3.200";
	strcpy_s(pDPSDKParam.szUserIdFlag, sizeof(pDPSDKParam.szUserIdFlag), strUserIdFlag.c_str());
	DPSDK_SetParam(m_nDLLHandle, &pDPSDKParam);*/

	WCHAR szName[512] = {0};
	GetModuleFileName(AfxGetApp()->m_hInstance, szName, 512);
	WCHAR szLongName[512] = {0};
	GetLongPathName(szName, szLongName, 512);

	CWideToMulti szLongNameA(szLongName);
	char szDrive[8] = {0};
	char szDir[500] = {0};
	_splitpath(szLongNameA.c_str(), szDrive, szDir, NULL, NULL);

	char szLogPathA[500] = {0};
	sprintf(szLogPathA, "%s%s%s", szDrive, szDir, "DPSDK_DLL_Demo");

	nRet = DPSDK_SetLog(m_nDLLHandle, DPSDK_LOG_LEVEL_DEBUG, szLogPathA, false, false);

	DPSDK_StartMonitor(m_nDLLHandle, "DPSDK_DLL_Demo");
	//������֯������Ŀ¼
	//DPSDK_SetSaveGroupFilePath(m_nDLLHandle, "D:/");

#ifdef USING_DPSDK_EXT
	DPSDK_InitExt();
#endif

	return 0;
}

void CTest_DPSDK_CoreDlg::OnDestroy()
{
	CDialog::OnDestroy();

	// TODO: �ڴ˴�������Ϣ�����������

	m_dlgReal.DestroyWindow();
	m_dlgPtz.DestroyWindow();
	m_dlgPlayback.DestroyWindow();
	m_dlgDGroup.DestroyWindow();
	m_dlgAlarm.DestroyWindow();
	m_dlgTvWall.DestroyWindow();
	m_dlgGeneral.DestroyWindow();
	m_dlgBay.DestroyWindow();
	m_dlgTalk.DestroyWindow();
	m_dlgFtp.DestroyWindow();
	m_dlgAlarmBusiness.DestroyWindow();
	m_dlgIntelligent.DestroyWindow();

#ifdef USING_DPSDK_EXT
	DPSDK_UnitExt();
#endif

	int nRet = ::ShowCallRetInfo(this, DPSDK_Destroy(m_nDLLHandle), _CS(_T("Destroy DPSDK_Core")));

	CUtilsMain::DestroyInstance();

	m_instance = NULL;
	CTest_PlatformDLLApp* pCoreApp = static_cast<CTest_PlatformDLLApp*>(AfxGetApp());
	if(pCoreApp)
	{
		pCoreApp->ExitDPSDKCoreApp();
	}
}

void CTest_DPSDK_CoreDlg::OnClose()
{
	m_dlgReal.CloseWin();
	m_dlgPlayback.CloseWin();
	m_dlgTalk.CloseWin();
	m_dlgIntelligent.CloseWin();
	CDialog::OnClose();

	PostMessage(WM_DESTROY);
}

void CTest_DPSDK_CoreDlg::OnBnClickedButtonLoadAllGroup()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//::ShowCallRetInfo(this, DPSDK_QueryServerList(m_nDLLHandle), _CS(_T("Query Server List")));
	m_nGroupInfoLen = 0;

	int nRet = ::ShowCallRetInfo(this, DPSDK_LoadDGroupInfo(m_nDLLHandle, m_nGroupInfoLen, 1000*180), _CS(_T("Load organization structure")));

	if(nRet == 0)
	{
		m_dlgDGroup.CreateDSSTree();
	}
}

void CTest_DPSDK_CoreDlg::OnBnClickedButtonGetGroupString()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CFileDialog dlg(FALSE, _T(".xml"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("XML Files (*.xml)|*.xml|"));
	if (dlg.DoModal() == IDOK)
	{
		char* pszGroupInfo = new char[m_nGroupInfoLen + 1];
		int nRet = ::ShowCallRetInfo(this, DPSDK_GetDGroupStr(m_nDLLHandle, pszGroupInfo, m_nGroupInfoLen), _CS(_T("Get organization structure")));
		if (nRet == DPSDK_RET_SUCCESS)
		{
			CString strPathName = dlg.GetPathName();
			CWideToMulti szPathName(strPathName.GetString());

			FILE* fp = NULL;
			fopen_s(&fp, szPathName.c_str(), "wb");
			if (fp != NULL)
			{
				fwrite(pszGroupInfo, sizeof(char), m_nGroupInfoLen, fp);
				fclose(fp);
			}
		}
		delete[] pszGroupInfo;
	}
}

void CTest_DPSDK_CoreDlg::OnCbnSelchangeCombo1()
{
	/*CString strRecSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strRecSource);
	int nRecSource = _ttoi(strRecSource.GetString());
	DPSDK_SetPlatformType(m_nDLLHandle,(dpsdk_core_platform_type_e)nRecSource);*/
}
void CTest_DPSDK_CoreDlg::OnBnClickedBtnGeneral2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CTest_DPSDK_CoreDlg::OnBnClickedButtonChangePassword()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	m_dlgChangePassword.ShowWindow(SW_SHOW);
	m_dlgChangePassword.CenterWindow(this);
}

void CTest_DPSDK_CoreDlg::OnBnClickedButtonSetlog()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CFileDialog dlg(FALSE, _T(""), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T(""));
	if(dlg.DoModal() == IDOK)
	{
		CWideToMulti szFilePath(dlg.GetPathName());
		ShowCallRetInfo(this, DPSDK_SetLog(m_nDLLHandle, (dpsdk_log_level_e)2, szFilePath.c_str(), true, true), _CS(_T("Set log file")));
	}
}

void CTest_DPSDK_CoreDlg::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	dpsdk_dev_type_e iDevType ;
	DPSDK_GetDeviceTypeByDevId(m_nDLLHandle,"1000003",(dpsdk_dev_type_e)iDevType);

	if (DPSDK_HasLogicOrg(m_nDLLHandle))
	{
		Dep_Info_Ex_t pDepinfo = {0};
		DPSDK_GetLogicRootDepInfo(m_nDLLHandle,&pDepinfo);
		int nOrgNum = 0;//����֯����
		DPSDK_GetLogicDepNodeNum(m_nDLLHandle,pDepinfo.szCoding,(dpsdk_node_type_e)0,&nOrgNum);
		for (int i =0;i<nOrgNum;i++)
		{
			Dep_Info_Ex_t outDepInfo = {0};//����֯��Ϣ
			//Camera_Group_Node_t groupNode;
			DPSDK_GetLogicSubDepInfoByIndex(m_nDLLHandle,pDepinfo.szCoding, i, &outDepInfo);

			int nChalNum = 0;//��֯�����ͨ������
			DPSDK_GetLogicDepNodeNum(m_nDLLHandle,outDepInfo.szCoding,(dpsdk_node_type_e)2,&nChalNum);

			char szId[128] = {0};//ĳ��ͨ����Ϣ
			ShowCallRetInfo(this, DPSDK_GetLogicID(m_nDLLHandle, outDepInfo.szCoding, 1, true, szId), _CS(_T("Get logicID")));

			Enc_Channel_Info_Ex_t pChannelInfo ;
			DPSDK_GetChannelInfoById(m_nDLLHandle,szId,&pChannelInfo);
			TRACE("");
		}
		TRACE("");
	}


}

void CTest_DPSDK_CoreDlg::OnBnClickedBtTestjson()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//char* szJson ="{ \"method\":\"alarmhost.getchannelstatus\",\"params\":{\"DeviceId\":\"1000006\",\"Type\":1} }";
	//char szJsonResult[1024*128] = {0};

	char* szJson ="{ \"method\":\"dev.snap\",\"params\":{\"DevID\":\"1000000\",\"DevChannel\":0,\"PicNum\":1,\"SnapType\":2,\"ReqType\":0} }";
	char szJsonResult[1024*512] = {0};
	int iRet = DPSDK_SendCammandToDMSByJson(m_nDLLHandle, szJson,"1000000", szJsonResult);
	TRACE("");
}

void CTest_DPSDK_CoreDlg::OnBnClickedBtGetuserinfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//DPSDK_UserInfo_t pUserInfo = {0};
	//DPSDK_GetUserInfo(m_nDLLHandle, pUserInfo, 10000);

	char* szJson ="{ \"method\":\"encdevice.getchannelinfo\",\"params\":{\"StoreId\":[{\"Id\":\"001011\"},{\"Id\":\"001012\"}]} }";
	char szJsonResult[1024*512] = {0};
	int iRet = DPSDK_SendCammandToCMSByJson(m_nDLLHandle, szJson, szJsonResult);

	TRACE("");
}

void CTest_DPSDK_CoreDlg::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//std::ifstream ifs("1.txt");

	//if (!ifs)
	//{
	//	printf("");
	//}
	//
	//    // ��2��һ���Խ��ļ������ݶ��룬�������ݱ��ֲ��䡣
	//std::ostringstream buffer;
	// buffer << ifs.rdbuf();
	// std::string context(buffer.str());
	// 
	// //cout << context << endl;
	// ifs.close();



	FILE *fp;
	fp = fopen("d://1234.txt", "a+b");
	char* buf = new char[1024*512];
	fread(buf, 1, strlen(buf)+1, fp);
	fclose(fp);



	//char* pFile = "D:\\1.txt";
	//CStdioFile myFile;
	//CFileException  fileExt;
	//if (myFile.Open((LPCTSTR)pFile,CFile::typeText|CFile::modeCreate|CFile::modeReadWrite),&fileExt)
	//{
	//	//myFile.SeekToBegin();
	//	CString str1("");
	//	myFile.ReadString(str1);

	//	int len = str1.GetLength();

	//}
	//myFile.Close();
	//char* pInf = new char[1024*512];
	char* szOut = "D://1234.jpg";
	int iRet = DPSDK_ConvertPicStrToBinary(m_nDLLHandle,buf,szOut);
}

BOOL CTest_DPSDK_CoreDlg::DoLogin()
{
	if(!m_dlgLogin.GetSafeHwnd())
	{
		m_dlgLogin.Create(IDD_DLD_LOGIN,this);
		m_dlgLogin.SetWindowPos(NULL,0,0,400,300,SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
	if (CTest_DPSDK_CoreDlg::GetInstance() && GetSafeHwnd())
	{
		CTest_DPSDK_CoreDlg::GetInstance()->ShowWindow(SW_HIDE);
	}
	m_dlgLogin.SetWindowPos(&CWnd::wndTopMost,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
	m_dlgLogin.CenterWindow();
	m_dlgLogin.ShowWindow(SW_SHOW);

	return TRUE;
}

void CTest_DPSDK_CoreDlg::OnLoginSuccess()
{
	//PostMessage(WM_LOGIN_SUCCESS);
	SetTimer(ID_TIMER_LOGIN_SUCCESS,500,NULL);
}

LRESULT CTest_DPSDK_CoreDlg::OnMsgLoginSuccess(WPARAM wParam, LPARAM lParam)
{
//	OnBnClickedButtonLoadAllGroup();
	return 1L;
}

LRESULT CTest_DPSDK_CoreDlg::OnModTransMsg(WPARAM wParam, LPARAM lParam)
{
	int nMsgType = (int) wParam;
	switch(nMsgType)
	{
	case MSG_IVS_ALARM:
		{
			IVS_Alarm_Info_t* pIvsAlarmInfo = (IVS_Alarm_Info_t*)lParam;
			if(pIvsAlarmInfo)
				::PostMessage(m_dlgReal.GetSafeHwnd(), WM_MOD_TRANS_MSG, MSG_IVS_ALARM, (LPARAM)pIvsAlarmInfo);
		}
		break;
	default:
		break;
	}
	return 0L;
}

void CTest_DPSDK_CoreDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	switch(nID)
	{
	/*case IDM_SYS_MENU_LOGIN:
		DoLogin();
		break;*/
	default:
		CDialog::OnSysCommand(nID, lParam);
		break;
	}
}

void CTest_DPSDK_CoreDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(m_dlgTab.GetSafeHwnd())
	{
		CRect rt;
		GetClientRect(&rt);
		m_dlgTab.SetWindowPos(NULL,LAYOUT_TAB_POSX,LAYOUT_TAB_POSY,rt.Width() - LAYOUT_TAB_POSX - 18,LAYOUT_TAB_HEIGHT,SWP_NOZORDER);
	}
}

void CTest_DPSDK_CoreDlg::OnMenuLoadOs()
{
	OnBnClickedButtonLoadAllGroup();
}

void CTest_DPSDK_CoreDlg::OnMenuGetOs()
{
	OnBnClickedButtonGetGroupString();
}

void CTest_DPSDK_CoreDlg::OnMenuModifyPw()
{
	OnBnClickedButtonChangePassword();
}

void CTest_DPSDK_CoreDlg::OnMenuSetLog()
{
	OnBnClickedButtonSetlog();
}

void CTest_DPSDK_CoreDlg::OnDmsGetPic()
{
	OnBnClickedBtTestjson();
}

void CTest_DPSDK_CoreDlg::OnMenuGetByCwh()
{
	OnBnClickedBtGetuserinfo();
}

void CTest_DPSDK_CoreDlg::OnMenuStrtobinary()
{
	OnBnClickedButton2();
}

void CTest_DPSDK_CoreDlg::OnBnClickedCheckCompressed()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton* pBtn = (CButton*)GetDlgItem(IDC_CHECK_Compressed);
	UINT istatus = pBtn->GetCheck();
	if (istatus == 0)
	{
		DPSDK_SetCompressType(m_nDLLHandle,(dpsdk_get_devinfo_compress_type_e)0);
	} 
	else
	{
		DPSDK_SetCompressType(m_nDLLHandle,(dpsdk_get_devinfo_compress_type_e)1);
	}
}

void CTest_DPSDK_CoreDlg::OnMenuLogin()
{
	DoLogin();
}

void CTest_DPSDK_CoreDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent == ID_TIMER_LOGIN_SUCCESS)
	{
		KillTimer(ID_TIMER_LOGIN_SUCCESS);
		OnMsgLoginSuccess(NULL,NULL);
	}

	CDialog::OnTimer(nIDEvent);
}
