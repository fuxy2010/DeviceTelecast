#pragma once
#include "DPSDK_Core.h"
#include "interface/IAbstractUI.h"
#include <map>
#include <string>

const uint64_t U_RIGHT_MONITOR          = 0x00000001;           // ʵʱ���� 
const uint64_t U_RIGHT_PLAYBACK         = 0x00000002;           // ¼��ط� 
const uint64_t U_RIGHT_DOWNLOAD         = 0x00000004;           // ¼������ 
const uint64_t U_RIGHT_PTZ              = 0x00000008;           // ��̨���� 

// CDlgDGroup �Ի���

typedef struct tagItemInfo
{
	int			nType;  // =1 ��֯ =2 �豸 =3 ͨ��
	std::string	strCode;
}Item_Infor_t;

typedef std::map<HTREEITEM, Item_Infor_t> TreeItemMap;
typedef std::map<std::string, HTREEITEM> CodeTreeItemMap; // ��ͬ�Ľڵ㲻ͬ��ID ��֯��code �豸���豸id ͨ����ͨ��id

class CDlgDGroup : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgDGroup)

public:
	CDlgDGroup(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgDGroup();

// �Ի�������
	enum { IDD = IDD_DLG_DGROUP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CTreeCtrl m_treeGroup;
	virtual BOOL OnInitDialog();

	void SetHandle(int nDLLHandle){m_nDLLHandle = nDLLHandle;}

	TreeItemMap  m_mapTreeItem;
	CodeTreeItemMap m_mapCodeItem;
	int32_t		m_nDLLHandle;
	afx_msg void OnNMDblclkTree1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg LRESULT OnDeviceChangeCallback( WPARAM wParam, LPARAM lParam );
	void RefreshItem(HTREEITEM hItem);
	//�����㣬���hParent�ǿ���֯��ɾ��hParent��return false
	bool CreateNodeDep(HTREEITEM hParent, const char* szDepId, int nType = 1);
	void CreateDSSTree(int nType = 1);

	virtual void ShowUI( BOOL bShow );

	virtual IWidget* GetWidget() const;

	virtual CString GetTestUIName() const;

	afx_msg void OnSize(UINT nType, int cx, int cy);
};
