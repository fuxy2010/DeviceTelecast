// DlgPtz.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgPtz.h"
#include "DPSDK_Core_Error.h"
#include "resource.h"

// CDlgPtz �Ի���

IMPLEMENT_DYNAMIC(CDlgPtz, CDialog)

CDlgPtz::CDlgPtz(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPtz::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_PTZ)
{

}

CDlgPtz::~CDlgPtz()
{
}

void CDlgPtz::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
}

void CDlgPtz::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CDlgPtz, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_DIRECTION_CONTROL, &CDlgPtz::OnBnClickedButtonDirectionControl)
	ON_BN_CLICKED(IDC_BUTTON_CAMERA_CONTROL, &CDlgPtz::OnBnClickedButtonCameraControl)
	ON_BN_CLICKED(IDC_BUTTON_PTZSIT, &CDlgPtz::OnBnClickedButtonPtzSit)
	ON_BN_CLICKED(IDC_BUTTON_LOCK_CAMERA, &CDlgPtz::OnBnClickedPtzLockCamera)
	ON_BN_CLICKED(IDC_BUTTON_QUERY_PREPOINT, &CDlgPtz::OnBnClickedButtonQueryPrePoint)
	ON_BN_CLICKED(IDC_BUTTON_ADD_PREPOINT, &CDlgPtz::OnBnClickedButtonAddPrePoint)
	ON_BN_CLICKED(IDC_BUTTON_DEL_PREPOINT, &CDlgPtz::OnBnClickedButtonDelPrePoint)
	ON_BN_CLICKED(IDC_BUTTON_LOCATION_PREPOINT, &CDlgPtz::OnBnClickedButtonLocationPrePoint)
	ON_BN_CLICKED(IDC_BUTTON_STOP_DIRECTION_CONTROL, &CDlgPtz::OnBnClickedButtonStopDirectionControl)
	ON_BN_CLICKED(IDC_BUTTON_STOP_CAMERA_CONTROL, &CDlgPtz::OnBnClickedButtonStopCameraControl)
END_MESSAGE_MAP()

// CDlgPtz ��Ϣ��������

BOOL CDlgPtz::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	//ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO3));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO4));
	//ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO6));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO8));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO7));

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	//GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1000017$1$0$0"));
	((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(3);
	//((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO4))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO5))->SetCurSel(0);
	//((CComboBox*)GetDlgItem(IDC_COMBO6))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO7))->SetCurSel(4);
	((CComboBox*)GetDlgItem(IDC_COMBO8))->SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgPtz::OnBnClickedButtonDirectionControl()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strDirect;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strDirect);
	int nDirect = _ttoi(strDirect.GetString());

	CString strStep;
	GetDlgItem(IDC_COMBO2)->GetWindowText(strStep);
	int nStep = _ttoi(strStep.GetString());

	//CString strStop;
	//GetDlgItem(IDC_COMBO3)->GetWindowText(strStop);
	//int nStop = _ttoi(strStop.GetString());

	Ptz_Direct_Info_t stuDirectInfo = {0};
	strcpy_s(stuDirectInfo.szCameraId, sizeof(stuDirectInfo.szCameraId), szCameraId.c_str());
	stuDirectInfo.nDirect = (dpsdk_ptz_direct_e)nDirect;
	stuDirectInfo.nStep = nStep;
	stuDirectInfo.bStop = false;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzDirection(m_nDLLHandle, &stuDirectInfo, 60000), _CS(_T("Direction control")));
}

void CDlgPtz::OnBnClickedButtonStopDirectionControl()
{
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strDirect;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strDirect);
	int nDirect = _ttoi(strDirect.GetString());

	CString strStep;
	GetDlgItem(IDC_COMBO2)->GetWindowText(strStep);
	int nStep = _ttoi(strStep.GetString());

// 	CString strStop;
// 	GetDlgItem(IDC_COMBO3)->GetWindowText(strStop);
// 	int nStop = _ttoi(strStop.GetString());

	Ptz_Direct_Info_t stuDirectInfo = {0};
	strcpy_s(stuDirectInfo.szCameraId, sizeof(stuDirectInfo.szCameraId), szCameraId.c_str());
	stuDirectInfo.nDirect = (dpsdk_ptz_direct_e)nDirect;
	stuDirectInfo.nStep = nStep;
	stuDirectInfo.bStop = true;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzDirection(m_nDLLHandle, &stuDirectInfo, 60000), _CS(_T("Stop control")));
}


void CDlgPtz::OnBnClickedButtonCameraControl()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strOper;
	GetDlgItem(IDC_COMBO4)->GetWindowText(strOper);
	int nOper = _ttoi(strOper.GetString());

	CString strStep;
	GetDlgItem(IDC_COMBO5)->GetWindowText(strStep);
	int nStep = _ttoi(strStep.GetString());

// 	CString strStop;
// 	GetDlgItem(IDC_COMBO6)->GetWindowText(strStop);
// 	int nStop = _ttoi(strStop.GetString());

	Ptz_Operation_Info_t stuOperInfo = {0};
	strcpy_s(stuOperInfo.szCameraId, sizeof(stuOperInfo.szCameraId), szCameraId.c_str());
	stuOperInfo.nOperation = (dpsdk_camera_operation_e)nOper;
	stuOperInfo.nStep = nStep;
	stuOperInfo.bStop = false;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzCameraOperation(m_nDLLHandle, &stuOperInfo), _CS(_T("Lens control")));
}


void CDlgPtz::OnBnClickedButtonStopCameraControl()
{
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strOper;
	GetDlgItem(IDC_COMBO4)->GetWindowText(strOper);
	int nOper = _ttoi(strOper.GetString());

	CString strStep;
	GetDlgItem(IDC_COMBO5)->GetWindowText(strStep);
	int nStep = _ttoi(strStep.GetString());

// 	CString strStop;
// 	GetDlgItem(IDC_COMBO6)->GetWindowText(strStop);
// 	int nStop = _ttoi(strStop.GetString());

	Ptz_Operation_Info_t stuOperInfo = {0};
	strcpy_s(stuOperInfo.szCameraId, sizeof(stuOperInfo.szCameraId), szCameraId.c_str());
	stuOperInfo.nOperation = (dpsdk_camera_operation_e)nOper;
	stuOperInfo.nStep = nStep;
	stuOperInfo.bStop = true;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzCameraOperation(m_nDLLHandle, &stuOperInfo), _CS(_T("Lens control")));
}


void CDlgPtz::OnBnClickedButtonPtzSit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strX;
	GetDlgItem(IDC_EDIT2)->GetWindowText(strX);
	int nX = _ttoi(strX.GetString());

	CString strY;
	GetDlgItem(IDC_EDIT3)->GetWindowText(strY);
	int nY = _ttoi(strY.GetString());

	CString strStep;
	GetDlgItem(IDC_COMBO7)->GetWindowText(strStep);
	int nStep = _ttoi(strStep.GetString());

	Ptz_Sit_Info_t stuSitInfo = {0};
	strcpy_s(stuSitInfo.szCameraId, sizeof(stuSitInfo.szCameraId), szCameraId.c_str());
	stuSitInfo.pointX = nX;
	stuSitInfo.pointY = nY;
	stuSitInfo.pointZ = nStep;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzSit(m_nDLLHandle, &stuSitInfo), _CS(_T("3D position:")));
}

void CDlgPtz::OnBnClickedPtzLockCamera()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strLock;
	GetDlgItem(IDC_COMBO8)->GetWindowText(strLock);
	int nLock = _ttoi(strLock.GetString());

	Ptz_Lock_Info_t stuLockInfo = {0};
	strcpy_s(stuLockInfo.szCameraId, sizeof(stuLockInfo.szCameraId), szCameraId.c_str());
	stuLockInfo.nLock = (dpsdk_ptz_locktype_e)nLock;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzLockCamera(m_nDLLHandle, &stuLockInfo), _CS(_T("Lock control")));
}

void CDlgPtz::OnBnClickedButtonQueryPrePoint()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	Ptz_Prepoint_Info_t stuPrepointInfo = {0};
	strcpy_s(stuPrepointInfo.szCameraId, sizeof(stuPrepointInfo.szCameraId), szCameraId.c_str());

	int nRet = ::ShowCallRetInfo(this, DPSDK_QueryPrePoint(m_nDLLHandle, &stuPrepointInfo), _CS(_T("Search preset")));
	if (nRet == DPSDK_RET_SUCCESS)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO10))->ResetContent();
		for (uint32_t i=0; i<stuPrepointInfo.nCount; i++)
		{
			CUtf8ToWide szPrepoint(stuPrepointInfo.pPoints[i].szName);
			CString strPrepoint;
			strPrepoint.Format(_T("%d %s"), stuPrepointInfo.pPoints[i].nCode, szPrepoint.wc_str());
			((CComboBox*)GetDlgItem(IDC_COMBO10))->InsertString(i, strPrepoint);
		}
	}
}

void CDlgPtz::OnBnClickedButtonAddPrePoint()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strCode;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strCode);
	int nCode = _ttoi(strCode);

	CString strName;
	GetDlgItem(IDC_EDIT5)->GetWindowText(strName);
	CWideToUtf8 szName(strName.GetString());

	if (strlen(szName.c_str()) > 30)
	{
		AfxMessageBox(_CS(_T("Preset name must be within 30 characters")));
		return;
	}

	Ptz_Prepoint_Operation_Info_t stuPrepointInfo = {0};
	strcpy_s(stuPrepointInfo.szCameraId, sizeof(stuPrepointInfo.szCameraId), szCameraId.c_str());
	stuPrepointInfo.nCmd = DPSDK_CORE_PTZ_PRESET_ADD;
	stuPrepointInfo.pPoints.nCode = nCode;
	strcpy_s(stuPrepointInfo.pPoints.szName, sizeof(stuPrepointInfo.pPoints.szName), szName.c_str());

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzPrePointOperation(m_nDLLHandle, &stuPrepointInfo), _CS(_T("Set preset")));
}

void CDlgPtz::OnBnClickedButtonDelPrePoint()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strCode;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strCode);
	int nCode = _ttoi(strCode);

	Ptz_Prepoint_Operation_Info_t stuPrepointInfo = {0};
	strcpy_s(stuPrepointInfo.szCameraId, sizeof(stuPrepointInfo.szCameraId), szCameraId.c_str());
	stuPrepointInfo.nCmd = DPSDK_CORE_PTZ_PRESET_DEL;
	stuPrepointInfo.pPoints.nCode = nCode;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzPrePointOperation(m_nDLLHandle, &stuPrepointInfo), _CS(_T("Delete preset")));

}

void CDlgPtz::OnBnClickedButtonLocationPrePoint()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strCameraId;
	CWnd*pPtzWnd = CWnd::FromHandle(GetParent()->GetSafeHwnd());
	pPtzWnd->GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	//GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strCode;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strCode);
	int nCode = _ttoi(strCode);

	Ptz_Prepoint_Operation_Info_t stuPrepointInfo = {0};
	strcpy_s(stuPrepointInfo.szCameraId, sizeof(stuPrepointInfo.szCameraId), szCameraId.c_str());
	stuPrepointInfo.nCmd = DPSDK_CORE_PTZ_PRESET_LOCATION;
	stuPrepointInfo.pPoints.nCode = nCode;

	int nRet = ::ShowCallRetInfo(this, DPSDK_PtzPrePointOperation(m_nDLLHandle, &stuPrepointInfo), _CS(_T("Position preset")));
}

void CDlgPtz::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgPtz::GetWidget() const
{
	return const_cast<CDlgPtz*>(this);
}

CString CDlgPtz::GetTestUIName() const
{
	return _T("PTZ");
}

