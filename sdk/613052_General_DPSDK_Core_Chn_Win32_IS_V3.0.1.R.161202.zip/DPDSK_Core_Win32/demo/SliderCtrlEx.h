#pragma once


typedef void (WINAPI* fSetPlayPosClickCallBack)(void* pUser,int nPos);

#define		WM_SET_PLAY_POS		WM_USER+1000
// CSliderCtrlEx

class CSliderCtrlEx : public CSliderCtrl
{
	DECLARE_DYNAMIC(CSliderCtrlEx)

public:
	CSliderCtrlEx();
	virtual ~CSliderCtrlEx();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
public:
	void SetClickCallBack(fSetPlayPosClickCallBack fSetPlayPos,void* pUser,int nPos);
	fSetPlayPosClickCallBack m_SetPlayPos;
	void* m_pUser;
	int m_nPos;
	BOOL m_bSetPlayPos;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};


