// DlgAlarm.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Test_DPSDK_Core.h"
#include "DlgAlarm.h"
#include "DPSDK_Core_Error.h"
#include "resource.h"
//#include "dhnetsdk.h"
//#include "FaceRec.h"
// CDlgAlarm �Ի���
IMPLEMENT_DYNAMIC(CDlgAlarm, CDialog)

CDlgAlarm::CDlgAlarm(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgAlarm::IDD, pParent)
	, IAbstractUI(TEST_WIDGET_ALARM)
{

}

CDlgAlarm::~CDlgAlarm()
{
}

void CDlgAlarm::SetHandle(int nDLLHandle)
{
	m_nDLLHandle = nDLLHandle;
	DPSDK_SetDPSDKAlarmCallback(m_nDLLHandle, CDlgAlarm::DPSDKAlarmCallback, this);
	DPSDK_SetDPSDKNewAlarmCallback(m_nDLLHandle, CDlgAlarm::DPSDKNewAlarmCallback, this);
}

void CDlgAlarm::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list1);
	DDX_Control(pDX, IDC_LIST2, m_list2);
}

BEGIN_MESSAGE_MAP(CDlgAlarm, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_ALARM_QUERY, &CDlgAlarm::OnBnClickedButtonAlarmQuery)
	ON_BN_CLICKED(IDC_BUTTON_ADD_SOLUTION, &CDlgAlarm::OnBnClickedButtonAddSolution)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_SOLUTION, &CDlgAlarm::OnBnClickedButtonClearSolution)
	ON_BN_CLICKED(IDC_BUTTON_ENABALE_ALARM, &CDlgAlarm::OnBnClickedButtonEnableAlarm)
	ON_BN_CLICKED(IDC_BUTTON_DISABLE_ALARM, &CDlgAlarm::OnBnClickedButtonDisableAlarm)
	ON_MESSAGE(WM_ALARMDATA_CB, OnAlarmDataCallback)
	ON_BN_CLICKED(IDC_BUTTON_ENABLE_ALARM_BY_DEPARTMENT, &CDlgAlarm::OnBnClickedButtonEnableAlarmByDepartment)
	ON_BN_CLICKED(IDC_BUTTON_SEND_ALARM_TO_SERVER, &CDlgAlarm::OnBnClickedButtonSendAlarmToServer)
	ON_CBN_SELCHANGE(IDC_COMBO2, &CDlgAlarm::OnCbnSelchangeCombo2)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgAlarm::OnBnClickedButton1)
END_MESSAGE_MAP()

// CDlgAlarm ��Ϣ��������
BOOL CDlgAlarm::OnInitDialog()
{
	CDialog::OnInitDialog();
	_CWndCS(this);
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO2));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO1));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO3));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO4));
	ConvertComboBox(*(CComboBox*)GetDlgItem(IDC_COMBO9));

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	//GetDlgItem(IDC_EDIT1)->SetWindowText(_T("1000030$1$0$0"));
	((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(0);
	SYSTEMTIME st;
	GetLocalTime(&st);
	CTime tm1(st.wYear, st.wMonth, st.wDay, 0, 0, 0);
	CTime tm2(st.wYear, st.wMonth, st.wDay, 23, 59, 59);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->SetTime(&tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->SetTime(&tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->SetTime(&tm2);
	m_list1.SetExtendedStyle(m_list1.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_list1.InsertColumn(1, _CS(_T("No.")), LVCFMT_CENTER, 60);
	m_list1.InsertColumn(2, _CS(_T("Type")), LVCFMT_CENTER, 100);
	m_list1.InsertColumn(3, _CS(_T("Time")), LVCFMT_CENTER, 150);
	m_list1.InsertColumn(4, _CS(_T("Event")), LVCFMT_CENTER, 80);
	m_list1.InsertColumn(5, _CS(_T("Device ID")), LVCFMT_CENTER, 80);
	m_list1.InsertColumn(6, _CS(_T("Channel no.")), LVCFMT_CENTER, 60);
	m_list1.InsertColumn(7, _CS(_T("Process status")), LVCFMT_CENTER, 100);

	//GetDlgItem(IDC_EDIT2)->SetWindowText(_T("1000030"));
	GetDlgItem(IDC_EDIT3)->SetWindowText(_T("-1"));
	GetDlgItem(IDC_EDIT4)->SetWindowText(_T("-1"));
	((CComboBox*)GetDlgItem(IDC_COMBO9))->SetCurSel(0);
	m_list2.SetExtendedStyle(m_list2.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	m_list2.InsertColumn(1, _CS(_T("No.")), LVCFMT_CENTER, 60);
	m_list2.InsertColumn(2, _CS(_T("Type")), LVCFMT_CENTER, 100);
	m_list2.InsertColumn(3, _CS(_T("Time")), LVCFMT_CENTER, 150);
	m_list2.InsertColumn(4, _CS(_T("Event")), LVCFMT_CENTER, 80);
	m_list2.InsertColumn(5, _CS(_T("Device name")), LVCFMT_CENTER, 120);
	m_list2.InsertColumn(6, _CS(_T("Channel name")), LVCFMT_CENTER, 100);

	GetDlgItem(IDC_EDIT_DEPARTMENT_NAME)->SetWindowText(_T("001"));

	GetDlgItem(IDC_SW_LABEL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_ELEC_LABEL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_SW_LABEL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_EDIT_ELEC_LABEL)->ShowWindow(SW_HIDE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgAlarm::OnBnClickedButtonAlarmQuery()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_list1.DeleteAllItems();

	CString strCameraId;
	GetDlgItem(IDC_EDIT1)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strSource;
	GetDlgItem(IDC_COMBO1)->GetWindowText(strSource);
	int nSource = _ttoi(strSource.GetString());

	CString strAlarm;
	GetDlgItem(IDC_COMBO2)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());
	
	CString strDevice;
	GetDlgItem(IDC_COMBO3)->GetWindowText(strDevice);
	int nDevice = _ttoi(strDevice.GetString());

	CString strDeal;
	GetDlgItem(IDC_COMBO4)->GetWindowText(strDeal);
	int nDeal = _ttoi(strDeal.GetString());
	
	CTime tm1;
	CTime tm2;
	CTime tm3;
	CTime tm4;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER3))->GetTime(tm3);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER4))->GetTime(tm4);
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());
	CTime tmEnd(tm3.GetYear(), tm3.GetMonth(), tm3.GetDay(), tm4.GetHour(), tm4.GetMinute(), tm4.GetSecond());
	
	Alarm_Query_Info_t stuQueryInfo = {0};
	strcpy_s(stuQueryInfo.szCameraId, sizeof(stuQueryInfo.szCameraId), szCameraId.c_str());
	stuQueryInfo.nAlarmType = (dpsdk_alarm_type_e)nAlarm;
	stuQueryInfo.uStartTime = tmStart.GetTime();
	stuQueryInfo.uEndTime = tmEnd.GetTime();

	int nAlarmCount = 500;
	int nRet = -1;
	//int nRet = ::ShowCallRetInfo(this, DPSDK_QueryAlarmCount(m_nDLLHandle, &stuQueryInfo, nAlarmCount), _CS(_T("Search alarm quantity")));
	//if (nRet != DPSDK_RET_SUCCESS)
	//	return;

	if (nAlarmCount > 0)
	{
		Alarm_Info_t stuAlarmInfo = {0};
		stuAlarmInfo.nCount = nAlarmCount;
		stuAlarmInfo.pAlarmInfo = new Single_Alarm_Info_t[stuAlarmInfo.nCount];

		//RFID������ѯ����DPSDK_QueryRFIDAlarmInfo�ӿ�
		if(nAlarm == 658)
		{
			CString strSWLabel, strElecLabel;
			GetDlgItem(IDC_EDIT_SW_LABEL)->GetWindowText(strSWLabel);
			CWideToUtf8 szSWLabel(strSWLabel.GetString());
			GetDlgItem(IDC_EDIT_ELEC_LABEL)->GetWindowText(strElecLabel);
			CWideToUtf8 szElecLabel(strElecLabel.GetString());
			nRet = ::ShowCallRetInfo(this, DPSDK_QueryRFIDAlarmInfo(m_nDLLHandle, &stuQueryInfo, &stuAlarmInfo, 0, nAlarmCount, szSWLabel.c_str(), szElecLabel.c_str()), _CS(_T("Search alarm info")));
		}
		else
		{
			nRet = ::ShowCallRetInfo(this, DPSDK_QueryAlarmInfo(m_nDLLHandle, &stuQueryInfo, &stuAlarmInfo, 0, nAlarmCount), _CS(_T("Search alarm info")));
		}
		if (nRet == DPSDK_RET_SUCCESS)
		{
			InsertAlarmItem(stuAlarmInfo.pAlarmInfo, stuAlarmInfo.nRetCount);
			//nRet = ::ShowCallRetInfo(this, DPSDK_QueryIvsbAlarmPicture(m_nDLLHandle, OP_FTP_TYPE_DOWN, szCameraId.c_str(), stuAlarmInfo.pAlarmInfo[0].szPicUrl, "D:\\1.jpg"), _CS(_T("save alarm pic")));
		}
		delete[] stuAlarmInfo.pAlarmInfo;
	}
}

void CDlgAlarm::OnBnClickedButtonAddSolution()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	/*CString strDevId;
	GetDlgItem(IDC_EDIT2)->GetWindowText(strDevId);
	CWideToUtf8 szDevId(strDevId.GetString());

	CString strInputNum;
	GetDlgItem(IDC_EDIT3)->GetWindowText(strInputNum);
	int nInputNum = _ttoi(strInputNum.GetString());

	CString strNo;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strNo);
	int nNo = _ttoi(strNo.GetString());

	CString strAlarm;
	GetDlgItem(IDC_COMBO9)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());

	Alarm_Single_Enable_Info_t stuAlarmInfo = {0};
	strcpy_s(stuAlarmInfo.szAlarmDevId, sizeof(stuAlarmInfo.szAlarmDevId), szDevId.c_str());
	stuAlarmInfo.nAlarmInput = nInputNum;
	stuAlarmInfo.nVideoNo = nNo;
	stuAlarmInfo.nAlarmType = (dpsdk_alarm_type_e)nAlarm;
	m_vecAlarmScheme.push_back(stuAlarmInfo);
	::ShowCallRetInfo(this, DPSDK_CORE_ERROR_SUCCESS, _T("Add scheme"));*/
}

void CDlgAlarm::OnBnClickedButtonClearSolution()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//m_vecAlarmScheme.clear();
	//::ShowCallRetInfo(this, DPSDK_CORE_ERROR_SUCCESS, _T("Clear scheme"));
}

void CDlgAlarm::OnBnClickedButtonEnableAlarm()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_list2.DeleteAllItems();

	CString strDevId;
	GetDlgItem(IDC_EDIT2)->GetWindowText(strDevId);
	CWideToUtf8 szDevId(strDevId.GetString());

	CString strInputNum;
	GetDlgItem(IDC_EDIT3)->GetWindowText(strInputNum);
	int nInputNum = _ttoi(strInputNum.GetString());

	CString strNo;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strNo);
	int nNo = _ttoi(strNo.GetString());

	CString strAlarm;
	GetDlgItem(IDC_COMBO9)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());

	Alarm_Enable_Info_t stuSchemeInfo = {0};
	stuSchemeInfo.nCount = 1;
	stuSchemeInfo.pSources = new Alarm_Single_Enable_Info_t;
	strcpy_s(stuSchemeInfo.pSources->szAlarmDevId, sizeof(stuSchemeInfo.pSources->szAlarmDevId), szDevId.c_str());
	stuSchemeInfo.pSources->nVideoNo = nNo;
	stuSchemeInfo.pSources->nAlarmInput = nInputNum;
	stuSchemeInfo.pSources->nAlarmType = (dpsdk_alarm_type_e)nAlarm;

	int nRet = ::ShowCallRetInfo(this, DPSDK_EnableAlarm(m_nDLLHandle, &stuSchemeInfo), _CS(_T("Arm")));

	delete stuSchemeInfo.pSources;
}

void CDlgAlarm::OnBnClickedButtonDisableAlarm()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int nRet = ::ShowCallRetInfo(this, DPSDK_DisableAlarm(m_nDLLHandle), _CS(_T("����")));
}

LRESULT CDlgAlarm::OnAlarmDataCallback(WPARAM wParam, LPARAM lParam)
{
	m_mtxAlarmCBInfo.Lock();
	Single_Alarm_CB_Info_t* pAlarmInfo = m_queAlarmCBInfo.front();
	m_mtxAlarmCBInfo.Unlock();

	InsertAlarmItem(pAlarmInfo);

	//���ܱ���������֪ͨ���ù�Ԥ��
	if (pAlarmInfo->nAlarmType > DPSDK_CORE_ALARM_IVS_ALARM_BEGIN && pAlarmInfo->nAlarmType < DPSDK_CORE_ALARM_IVS_ALARM_END)
	{	
		IVS_Alarm_Info_t* pIvsAlarmInfo = new IVS_Alarm_Info_t;
		pIvsAlarmInfo->nAlarmType = pAlarmInfo->nAlarmType;
		pIvsAlarmInfo->pszAlarmData = new char[pAlarmInfo->nAlarmDataLen + 1];
		memcpy(pIvsAlarmInfo->pszAlarmData, pAlarmInfo->pszAlarmData, pAlarmInfo->nAlarmDataLen);
		pIvsAlarmInfo->nAlarmDataLen = pAlarmInfo->nAlarmDataLen;

		::PostMessage(GetParent()->GetSafeHwnd(), WM_MOD_TRANS_MSG, MSG_IVS_ALARM, (LPARAM)pIvsAlarmInfo );
		//DispatchIvsAlarm(pAlarmMsg);
		//return 0;//���ܱ����ַ���ֱ�ӷ���
	}
	delete[] pAlarmInfo->pszAlarmData;
	delete[] pAlarmInfo->pszPicData;
	delete pAlarmInfo;

	m_mtxAlarmCBInfo.Lock();
	m_queAlarmCBInfo.pop();
	m_mtxAlarmCBInfo.Unlock();

	return 0;
}

void CDlgAlarm::InsertAlarmItem(Single_Alarm_Info_t* pAlarmInfo, int nCount)
{
	for (int i=0; i<nCount; i++)
	{
		int nSeq = m_list1.GetItemCount();
		CString strSeq;
		strSeq.Format(_T("%d"), nSeq+1);
		m_list1.InsertItem(nSeq, strSeq); // ���

		m_list1.SetItemText(nSeq, 1, ConvertAlarmType(pAlarmInfo[i].nAlarmType)); // ��������

		CTime tmTime(pAlarmInfo[i].uAlarmTime);
		CString strTime = tmTime.Format(_T("%Y-%m-%d %H:%M:%S"));
		m_list1.SetItemText(nSeq, 2, strTime); // ����ʱ��

		CString strEvent = pAlarmInfo[i].nEventType == ALARM_EVENT_OCCUR ? _CS(_T("Occur")) : _CS(_T("Disappear"));
		m_list1.SetItemText(nSeq, 3, strEvent); // �¼�
		
		m_list1.SetItemText(nSeq, 4, CString(pAlarmInfo[i].szDevId)); // �豸ID

		CString strChannel;
		strChannel.Format(_T("%d"), pAlarmInfo[i].uChannel);
		m_list1.SetItemText(nSeq, 5, strChannel); // ͨ����

		m_list1.SetItemText(nSeq, 6, ConvertDealWith(pAlarmInfo[i].nDealWith)); // ����״̬
	}
}

void CDlgAlarm::InsertAlarmItem(Single_Alarm_CB_Info_t* pAlarmInfo)
{
	int nSeq = m_list2.GetItemCount();
	CString strSeq;
	strSeq.Format(_T("%d"), nSeq+1);
	m_list2.InsertItem(nSeq, strSeq); // ���

	m_list2.SetItemText(nSeq, 1, ConvertAlarmType(pAlarmInfo->nAlarmType)); // ��������

	CTime tmTime(pAlarmInfo->nTime);
	CString strTime = tmTime.Format(_T("%Y-%m-%d %H:%M:%S"));
	m_list2.SetItemText(nSeq, 2, strTime); // ����ʱ��

	CString strEvent = pAlarmInfo->nEventType == ALARM_EVENT_OCCUR ? _CS(_T("Occur")) : _CS(_T("Disappear"));
	m_list2.SetItemText(nSeq, 3, strEvent); // �¼�

	CUtf8ToWide strDeviceName(pAlarmInfo->szDeviceName);
	m_list2.SetItemText(nSeq, 4, strDeviceName.wc_str()); // �豸��

	CUtf8ToWide strChannelName(pAlarmInfo->szChannelName);
	m_list2.SetItemText(nSeq, 5, strChannelName.wc_str()); // ͨ����
}

void CDlgAlarm::PushAlarmCBInfo(Single_Alarm_CB_Info_t* pAlarmInfo)
{
	m_mtxAlarmCBInfo.Lock();
	m_queAlarmCBInfo.push(pAlarmInfo);
	m_mtxAlarmCBInfo.Unlock();
}

CString CDlgAlarm::ConvertAlarmType(int nType)
{
	switch (nType)
	{
	case DPSDK_CORE_ALARM_TYPE_VIDEO_LOST:
		return _CS(_T("Video loss"));
	case DPSDK_CORE_ALARM_TYPE_EXTERNAL_ALARM:
		return _CS(_T("External alarm"));
	case DPSDK_CORE_ALARM_TYPE_MOTION_DETECT:
		return _CS(_T("Motion detection"));
	case DPSDK_CORE_ALARM_TYPE_VIDEO_SHELTER:
		return _CS(_T("Tampering"));
	case DPSDK_CORE_ALARM_TYPE_DISK_FULL:
		return _CS(_T("HDD full"));
	case DPSDK_CORE_ALARM_TYPE_DISK_FAULT:
		return _CS(_T("HDD failure"));
	case DPSDK_CORE_ALARM_GAS_LOWLEVEL:
		return _CS(_T("Oil alarm"));
	case DPSDK_CORE_ALARM_CROSSLINEDETECTION:
		return _CS(_T("����������"));
	case DPSDK_CORE_ALARM_CROSSREGIONDETECTION:
		return _CS(_T("����������"));
	case DPSDK_CORE_ALARM_TRAFFIC_PARKING:
		return _CS(_T("Υ��ͣ��"));

	default:
		CString strType;
		char szType[16]={0};
		itoa(nType,szType,10);
		strType = szType;
		return strType;
	}

	return _T("");
}

CString CDlgAlarm::ConvertDealWith(int nType)
{
	switch (nType)
	{
	case ALARM_DEALWITH_PENDING:
		return _CS(_T("Processing"));
	case ALARM_DEALWITH_RESOLVE:
		return _CS(_T("Solved"));
	case ALARM_DEALWITH_SUGGESTTED:
		return _CS(_T("Miss-alarm"));
	case ALARM_DEALWITH_IGNORED:
		return _CS(_T("Ignored"));
	case ALARM_DEALWITH_UNPROCESSED:
		return _CS(_T("Unsolved"));
	default:;
	}

	return _T("");
}

int DPSDK_CALLTYPE CDlgAlarm::DPSDKAlarmCallback(int32_t nDLLHandle, 
												 const char* szAlarmId, 
												 uint32_t nDeviceType, 
												 const char* szCameraId,//ͨ��ID
												 const char* szDeviceName,
												 const char* szChannelName,
												 const char* szCoding,
												 const char* szMessage,
												 uint32_t nAlarmType,
												 uint32_t nEventType,
												 uint32_t nLevel,
												 int64_t nTime,
												 char* pAlarmData,
												 uint32_t nAlarmDataLen,
												 char* pPicData,
												 uint32_t nPicDataLen,
												 void* pUser)
{
	std::string cameraid = "";
	cameraid = szCameraId;
	return 0;
}



int DPSDK_CALLTYPE CDlgAlarm::DPSDKNewAlarmCallback
(
	int32_t nDLLHandle, 
	const char* szAlarmId, 
	uint32_t nDeviceType, 
	const char* szDevicdId,//�豸ID
	uint32_t nChannelNo,//ͨ����
	const char* szDeviceName,// �豸��
	const char* szChannelName,// ͨ����
	const char* szCoding,
	const char* szMessage,
	uint32_t nAlarmType, // ��������
	uint32_t nEventType, // �¼�����
	uint32_t nLevel,// �����ȼ�
	int64_t nTime, // ʱ��
	char* pAlarmData,
	uint32_t nAlarmDataLen,
	char* pPicData,
	uint32_t nPicDataLen,
	void* pUser
)
{
	Single_Alarm_CB_Info_t* pAlarmInfo = new Single_Alarm_CB_Info_t;
	strcpy_s(pAlarmInfo->szAlarmId, sizeof(pAlarmInfo->szAlarmId), szAlarmId);
	pAlarmInfo->nDeviceType = nDeviceType;
	strcpy_s(pAlarmInfo->strDeviceID, sizeof(pAlarmInfo->strDeviceID), szDevicdId);
	pAlarmInfo->nChannel = nChannelNo;
	strcpy_s(pAlarmInfo->szDeviceName, sizeof(pAlarmInfo->szDeviceName), szDeviceName);
	strcpy_s(pAlarmInfo->szChannelName, sizeof(pAlarmInfo->szChannelName), szChannelName);
	strcpy_s(pAlarmInfo->szCoding, sizeof(pAlarmInfo->szCoding), szCoding);
	strcpy_s(pAlarmInfo->szMessage, sizeof(pAlarmInfo->szMessage), szMessage);
	pAlarmInfo->nAlarmType = nAlarmType;
	pAlarmInfo->nEventType = nEventType;
	pAlarmInfo->nLevel = nLevel;
	pAlarmInfo->nTime = nTime;
	pAlarmInfo->pszAlarmData = new char[nAlarmDataLen + 1];
	memcpy(pAlarmInfo->pszAlarmData, pAlarmData, nAlarmDataLen);
	pAlarmInfo->nAlarmDataLen = nAlarmDataLen;
	pAlarmInfo->pszPicData = new char[nPicDataLen + 1];
	memcpy(pAlarmInfo->pszPicData, pPicData, nPicDataLen);
	pAlarmInfo->nPicDataLen = nPicDataLen;
	pAlarmInfo->pUser = pUser;
	if(nAlarmType == ALARM_FIRE_WARNING && nAlarmDataLen > 0 )
	{//���ƣ����ϱ�����̨�����ǣ����ӽ�
		//dhnetsdk.h
		//DEV_EVENT_SMOKE_INFO* data = (DEV_EVENT_SMOKE_INFO*)pAlarmInfo->pszAlarmData;
		//PTZ_SPACE_UNIT ptzdata;
		//memcpy(&ptzdata, data->stuPtzPosition, sizeof(PTZ_SPACE_UNIT));
	}


	CDlgAlarm* pDlg = (CDlgAlarm*)pUser;
	pDlg->PushAlarmCBInfo(pAlarmInfo);
	pDlg->PostMessage(WM_ALARMDATA_CB, 0, 0);

	return 0;
}
void CDlgAlarm::OnBnClickedButtonEnableAlarmByDepartment()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_list2.DeleteAllItems();

	CString strDevId;
	GetDlgItem(IDC_EDIT_DEPARTMENT_NAME)->GetWindowText(strDevId);
	CWideToUtf8 szDevId(strDevId.GetString());

	CString strInputNum;
	GetDlgItem(IDC_EDIT3)->GetWindowText(strInputNum);
	int nInputNum = _ttoi(strInputNum.GetString());

	CString strNo;
	GetDlgItem(IDC_EDIT4)->GetWindowText(strNo);
	int nNo = _ttoi(strNo.GetString());

	CString strAlarm;
	GetDlgItem(IDC_COMBO9)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());

	Alarm_Enable_By_Dep_Info_t stuSchemeInfo = {0};
	stuSchemeInfo.nCount = 1;
	stuSchemeInfo.pSources = new Alarm_Single_Enable_By_Dep_Info_t;
	strcpy_s(stuSchemeInfo.pSources->szAlarmDepartmentCode, sizeof(stuSchemeInfo.pSources->szAlarmDepartmentCode), szDevId.c_str());
	stuSchemeInfo.pSources->nVideoNo = nNo;
	stuSchemeInfo.pSources->nAlarmInput = nInputNum;
	stuSchemeInfo.pSources->nAlarmType = (dpsdk_alarm_type_e)nAlarm;

	int nRet = ::ShowCallRetInfo(this, DPSDK_EnableAlarmByDepartment(m_nDLLHandle, &stuSchemeInfo), _CS(_T("According to department name arm")));

	delete stuSchemeInfo.pSources;
}

void CDlgAlarm::OnBnClickedButtonSendAlarmToServer()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strDevId;
	GetDlgItem(IDC_EDIT2)->GetWindowText(strDevId);
	CWideToUtf8 szDevId(strDevId.GetString());

	CString strCameraId;
	GetDlgItem(IDC_EDIT3)->GetWindowText(strCameraId);
	CWideToUtf8 szCameraId(strCameraId.GetString());

	CString strAlarm;
	GetDlgItem(IDC_COMBO9)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());

	CTime tm1;
	CTime tm2;
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER1))->GetTime(tm1);
	((CDateTimeCtrl*)GetDlgItem(IDC_DATETIMEPICKER2))->GetTime(tm2);
	
	CTime tmStart(tm1.GetYear(), tm1.GetMonth(), tm1.GetDay(), tm2.GetHour(), tm2.GetMinute(), tm2.GetSecond());

	//Client_Alarm_Info_t
	Client_Alarm_Info_t stuClientAlarmInfo={0};
	stuClientAlarmInfo.enAlarmType= (dpsdk_alarm_type_e)nAlarm;
	stuClientAlarmInfo.enStatus = ALARM_EVENT_OCCUR;
	if(nAlarm==DPSDK_CORE_ALARM_TYPE_EXTERNAL_ALARM)
	{
		sprintf_s(stuClientAlarmInfo.szCameraId,sizeof(stuClientAlarmInfo.szCameraId),"%s$3$0$%s",szDevId.c_str(),szCameraId.c_str());
	}
	else
	{
		sprintf_s(stuClientAlarmInfo.szCameraId,sizeof(stuClientAlarmInfo.szCameraId),"%s$1$0$%s",szDevId.c_str(),szCameraId.c_str());
	}
	
	stuClientAlarmInfo.uAlarmTime=tmStart.GetTime();
	sprintf_s(stuClientAlarmInfo.szMsg,sizeof(stuClientAlarmInfo.szMsg),"%s","test");

	int nRet = ::ShowCallRetInfo(this, DPSDK_SendAlarmToServer(m_nDLLHandle, &stuClientAlarmInfo), _CS(_T("Send alarm info to platform")));

}

void CDlgAlarm::OnCbnSelchangeCombo2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strAlarm;
	GetDlgItem(IDC_COMBO2)->GetWindowText(strAlarm);
	int nAlarm = _ttoi(strAlarm.GetString());
	if(nAlarm == 658)
	{
		GetDlgItem(IDC_SW_LABEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_ELEC_LABEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_SW_LABEL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_ELEC_LABEL)->ShowWindow(SW_SHOW);
	}
	else
	{
		GetDlgItem(IDC_SW_LABEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_ELEC_LABEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_SW_LABEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_EDIT_ELEC_LABEL)->ShowWindow(SW_HIDE);
	}
}

void CDlgAlarm::ShowUI( BOOL bShow )
{
	if(GetSafeHwnd())
	{
		if(bShow)
		{
			ShowWindow(SW_SHOW);
		}else
		{
			ShowWindow(SW_HIDE);
		}
	}
}

IWidget* CDlgAlarm::GetWidget() const
{
	return const_cast<CDlgAlarm*>(this);
}

CString CDlgAlarm::GetTestUIName() const
{
	return _T("Alarm");
}

void CDlgAlarm::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 	CFaceRec frDlg;
// 	frDlg.SetHandle(m_nDLLHandle);
// 	frDlg.DoModal();
}
