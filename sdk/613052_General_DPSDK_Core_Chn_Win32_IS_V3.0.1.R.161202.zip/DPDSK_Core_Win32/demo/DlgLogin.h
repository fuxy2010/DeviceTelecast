#pragma once
#include "interface/IAbstractUI.h"
#include "Resource.h"
// CDlgLogin �Ի���

class CDlgLogin : public CDialog,public IAbstractUI
{
	DECLARE_DYNAMIC(CDlgLogin)

public:
	CDlgLogin(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgLogin();

// �Ի�������
	enum { IDD = IDD_DLD_LOGIN };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

public:
	virtual IWidget* GetWidget() const;
	virtual CString GetTestUIName() const;
	virtual void ShowUI(BOOL bShow);

	afx_msg void OnBnClickedButtonLogin();
	afx_msg void OnBnClickedButtonLogout();
	afx_msg void OnClose();
};
