#pragma once
#include"DPSDK_Core.h"
#include "interface/IAbstractUI.h"
#include "afxwin.h"
#include "afxcmn.h"
#include "Common.h"

// DlgIntelligent �Ի���

class DlgIntelligent : public CDialog, public IAbstractUI
{
	DECLARE_DYNAMIC(DlgIntelligent)

public:
	DlgIntelligent(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~DlgIntelligent();
	void SetHandle(int nDLLHandle);	
	void CloseWin();
	virtual BOOL OnInitDialog();
	void InsertPersonInfoItem(Person_Count_Info_t* info);
	virtual void ShowUI( BOOL bShow );
	virtual IWidget* GetWidget() const;
	virtual CString GetTestUIName() const;
// �Ի�������
	enum { IDD = IDD_DLG_INTELLIGENT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

private:
	int32_t	m_nDLLHandle;
	uint32_t nQuerySeq;
	uint32_t totalCount;
	char szCameraID[DPSDK_CORE_CHL_ID_LEN];
	DECLARE_MESSAGE_MAP()
public:

	CListCtrl m_CountList;
	afx_msg void OnBnClickedButtonGetAllCount();
	afx_msg void OnBnClickedButtonStopCount();
	afx_msg void OnBnClickedButtonGetDitalCount();
};
